##分组双向柱状图
#读入数据，合并数据
plant30 <- read.csv('30days.csv')
plant30$days <- rep('30', nrow(plant30))

plant45 <- read.csv('45days.csv')
plant45$days <- rep('45', nrow(plant45))

plant60 <- read.csv('60days.csv')
plant60$days <- rep('60', nrow(plant60))

plant75 <- read.csv('75days.csv')
plant75$days <- rep('75', nrow(plant75))

plant90 <- read.csv('90days.csv')
plant90$days <- rep('90', nrow(plant90))

plant_all <- rbind(plant30, plant45, plant60, plant75, plant90)

#统计均值、标准差
library(reshape2)
library(doBy)

plant_all <- melt(plant_all, id = c('plant', 'days'))
plant_all_stat <- summaryBy(value~variable+plant+days, plant_all, FUN = c(mean, sd))

#将根长数据转化为负值，便于作图
plant_all_stat[which(plant_all_stat$variable == 'root_length'), c('value.mean', 'value.sd')] <- plant_all_stat[which(plant_all_stat$variable == 'root_length'), c('value.mean', 'value.sd')] * -1

#ggplot2 作图
library(ggplot2)

p1 <- ggplot(plant_all_stat, aes(days, value.mean, fill = plant)) +
geom_col(position = position_dodge(width = 0.5), width = 0.5, size = 0.3, colour = 'black') +
geom_errorbar(aes(ymin = value.mean - value.sd, ymax = value.mean + value.sd), width = 0.3, size = 0.3, position = position_dodge(0.5)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.title = element_blank()) +
labs(x = 'Time (days)', y = 'Length (cm)') +
geom_hline(yintercept = 0, size = 0.3) +
scale_y_continuous(breaks = seq(-45, 45, 15), labels = as.character(abs(seq(-45, 45, 15))), limits = c(-45, 45)) +
annotate('text', label = 'Stem', 1, 43) +
annotate('text', label = 'Root', 1, -43)

#ggsave('plant.pdf', p1, width = 6, height = 4)
ggsave('plant.png', p1, width = 6, height = 4)

##堆叠双向柱状图
#数据来自 https://mp.weixin.qq.com/s?__biz=MzIxNzc1Mzk3NQ==&mid=2247483757&idx=1&sn=e3f6e387d6afef876dbd2af8b34e69dd&chksm=97f5b175a0823863f9bf0ccc3272d1360a0b12869511dc82a0704a9aeeb5f4fb9fdaff8ed89a&token=960915229&lang=zh_CN#rd

#读取数据
phylum_top10 <- read.csv('phylum_top10.csv', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)

#整理成 ggplot2 作图格式
phylum_top10$Taxonomy <- factor(rownames(phylum_top10), levels = rev(rownames(phylum_top10)))
phylum_top10 <- melt(phylum_top10, id = 'Taxonomy')

#添加分组
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE)
names(group)[1] <- 'variable'
phylum_top10 <- merge(phylum_top10, group, by = 'variable')

#将 Control 转为负值
phylum_top10[which(phylum_top10$group == 'Control'), 'value'] <- phylum_top10[which(phylum_top10$group == 'Control'), 'value'] * -1

#ggplot2 作图
p2 <- ggplot(phylum_top10, aes(times, 100 * value, fill = Taxonomy)) +
geom_col(position = 'stack', width = 0.5) +
scale_fill_manual(values =  rev(c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray'))) +
labs(x = '', y = 'Control         Relative Abundance(%)          Treat') +
geom_hline(yintercept = 0, size = 0.3) +
scale_y_continuous(breaks = seq(-100, 100, 25), labels = as.character(abs(seq(-100, 100, 25)))) +
scale_x_continuous(breaks = 1:6, labels = as.character(1:6)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), strip.text = element_text(size = 12)) +
theme(axis.text = element_text(size = 12), axis.title = element_text(size = 13), legend.title = element_blank(), legend.text = element_text(size = 11)) +
coord_flip()

#ggsave('taxonomy.pdf', p2, width = 9, height = 5.5)
ggsave('taxonomy.png', p2, width = 9, height = 5.5)

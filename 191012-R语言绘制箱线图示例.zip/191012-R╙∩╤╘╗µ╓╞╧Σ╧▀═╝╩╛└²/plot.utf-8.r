#读取数据
library(reshape2)

alpha <- read.csv('alpha.csv', stringsAsFactors = FALSE)
alpha$group2 <- factor(alpha$group2)

alpha1 <- melt(alpha, id = c('samples', 'group1', 'group2'))
alpha2 <- subset(alpha1, variable == 'chao1')
alpha3 <- subset(alpha2, group1 == 'c')

##boxplot() 箱线图，详情使用 ?boxplot 查看帮助
par(mfrow = c(1, 2))

#常规样式
boxplot(value~group2, data = alpha3, col = '#f8766d', ylab = 'Chao1 (group c)')

#添加凹槽
boxplot(value~group2, data = alpha3, col = '#f8766d', notch = TRUE, varwidth = TRUE, ylab = 'Chao1 (group c)')

##ggplot2
library(ggplot2)

#单变量箱线图
ggplot(alpha3, aes(x = group2, y = value)) + 
geom_boxplot(outlier.size = 1, fill = '#f8766d') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black')) +
labs(x = '', y = 'Chao1')

#将各数据值以抖动散点的方式添加在箱线图中，同时绘制凹槽
ggplot(alpha3, aes(x = group2, y = value, fill = group1)) + 
geom_boxplot(fill = '#f8766d', notch = TRUE) +
geom_jitter(color = 'red', show.legend = FALSE) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black')) +
labs(x = '', y = 'Chao1 (group c)')

#存在多分组时，多组分开展示的箱线图
ggplot(alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_boxplot(outlier.size = 1) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1') 

#多变量情况，添加分面的箱线图
ggplot(alpha1, aes(x = group2, y = value, fill = group1)) + 
geom_boxplot(outlier.size = 0.5, size = 0.5) +
facet_wrap(~variable, 2, scales = 'free') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')


#带显著性标记“*”的箱线图
#先绘制箱线图主体
p <- ggplot(data = alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_boxplot(outlier.size = 1) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#再手动添加显著性标记
#注意，这里的显著性是提前已经计算好的，我们通过手动输入进来
#本篇只关注作图，不涉及统计分析
library(doBy)

alpha2_stat <- summaryBy(value~group2, alpha2, FUN = max)
names(alpha2_stat) <- c('group2', 'value')
alpha2_stat$group1 <- NA
alpha2_stat$sig <- rep('***', 5)

p + geom_text(data = alpha2_stat, aes(label = sig), vjust = -0.3) +
annotate('text', x = alpha2_stat$group2, y = alpha2_stat$value, label = '———', vjust = -0.3)


#带显著性标记“abc”的箱线图
#先绘制箱线图主体
p <- ggplot(data = alpha1, aes(x = group2, y = value, fill = group1)) + 
geom_boxplot(outlier.size = 0.5, size = 0.5) +
facet_wrap(~variable, 2, scales = 'free') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#再手动添加显著性标记
#同上所述，这里的显著性是提前通过差异分析已经计算好的，我们通过手动输入进来
alpha1_stat <- summaryBy(value~group1+group2+variable, alpha1, FUN = max)
names(alpha1_stat) <- c('group1', 'group2', 'variable', 'value')
alpha1_stat$sig <- c('a', 'a', 'a', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'a', 'b', 'b', 'a', 'b', 'c', 'c', 'b', 'a', 'a', 'b', 'a', 'a', 'a', 'b', 'a', 'a', 'a', 'a', 'a')

p + geom_text(data = alpha1_stat, aes(label = sig, color = group1), position = position_dodge(0.8), vjust = -0.3)

library(ade4)

#查看 R 文档，本篇就按照文档中下方示例过程来
?dudi.acm

#MCA 分析
data(banque)
banque.acm <- dudi.acm(banque, scann = FALSE, nf = 3)

#概要
banque.acm 
summary(banque.acm)

#查看特征值（显示前 4 轴）
banque.acm$eig[1:4]
#查看排序轴解释量（%，显示前 4 轴）
round(banque.acm$eig / sum(banque.acm$eig) * 100, 2)[1:4]
#所有特征值柱形图
scatterutil.eigen(banque.acm$eig, box = TRUE, sub = NA)

#对象和变量坐标
#因为上述 dudi.acm() 中，参数 nf = 3，故默认显示了前三个排序轴
head(banque.acm$li)
head(banque.acm$co)

#查看排序图中，各因子变量的分布
scatter(banque.acm)
#以及 boxplot() 查看 MCA 结果中的因子分布
boxplot(banque.acm)

#s.value()能够以 0 刻度分为分界线，在各排序轴中标记对象，对象分布特征有助于探索数据
par(mfrow = c(2, 2))
s.value(banque.acm$li, banque.acm$li[,1])	#以第一轴区分
s.value(banque.acm$li, banque.acm$li[,2])	#以第二轴区分
s.value(banque.acm$li, banque.acm$li[,3])	#以第三轴区分，但二维排序图仍然默认展示前两轴

#因为上述 dudi.acm() 中，参数 nf = 3，即默认显示了前三个排序轴
#故以第四轴区分时，将会报错
#s.value(banque.acm$li, banque.acm$li[,4])
#可通过修改排序时的 nf 参数解决

#acm.burt()示例，mca and coa of Burt table
bb <- acm.burt(banque, banque)	#若有需要可使用 write.table() 输出
bbcoa <- dudi.coa(bb, scann = FALSE)	#CA 排序

plot(banque.acm$c1[,1], bbcoa$c1[,1])

#acm.disjonctif()示例，mca and coa of disjonctive table
bd <- acm.disjonctif(banque)	 #若有需要可使用 write.table() 输出
bdcoa <- dudi.coa(bd, scann = FALSE)		#CA 排序

par(mfrow = c(1, 2))
plot(banque.acm$li[,1], bdcoa$li[,1], main = '对象') 
plot(banque.acm$co[,1], bdcoa$co[,1], main = '变量')

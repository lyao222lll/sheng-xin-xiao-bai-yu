#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##双因素方差分析（双因素 ANOVA）
#假设所有土壤类型均一致，我们在土壤中分别添加了三种化学物质（a、b、c），并将土壤孵育了不同的时间（10、15、20、25 天），同时关注化学物质类型以及处理时间对土壤细菌群落的影响（关注交互作用）
#同样以 chao1 指数为例，同时将分组列转换为因子变量
chao1 <- soil[ ,c('sample', 'treat', 'times', 'chao1')]
chao1$treat <- factor(chao1$treat)
chao1$times <- factor(chao1$times)

#QQ-plot 检查数据是否符合正态分布
library(car)

par(mfrow = c(1, 2))
qqPlot(lm(chao1~treat, data = chao1), simulate = TRUE, main = 'QQ Plot', labels = FALSE)
qqPlot(lm(chao1~times, data = chao1), simulate = TRUE, main = 'QQ Plot', labels = FALSE)

#使用 Bartlett 检验进行方差齐性检验（p 值大于 0.05 说明方差齐整）
bartlett.test(chao1~treat, data = chao1)
bartlett.test(chao1~times, data = chao1)

#满足假设，双因素方差分析，详情使用 ?aov 查看帮助
fit <- aov(chao1~treat*times, data = chao1)
summary(fit)
#上式等同于
fit <- aov(chao1~treat+times+treat:times, data = chao1)
summary(fit) 

#不满足假设，可使用非参数方法，例如 Scheirer-Ray-Hare Test
#rcompanion 包 scheirerRayHare()

#查看各组均值及标准差
aggregate(chao1$chao1, by = list(chao1$treat, chao1$times), FUN = mean)
aggregate(chao1$chao1, by = list(chao1$treat, chao1$times), FUN = sd)

#交互效应展示示例
interaction.plot(chao1$times, chao1$treat, chao1$chao1)

boxplot(chao1~treat*times, data = chao1, col = c('#B3DE69', '#FDB462', '#80B1D3'))

library(gplots)
plotmeans(chao1~interaction(treat, times), data = chao1, connect = list(c(1, 4, 7, 10), c(2, 5, 8, 11), c(3, 6, 9, 12)))

library(HH)
interaction2wt(chao1~treat*times, data = chao1)

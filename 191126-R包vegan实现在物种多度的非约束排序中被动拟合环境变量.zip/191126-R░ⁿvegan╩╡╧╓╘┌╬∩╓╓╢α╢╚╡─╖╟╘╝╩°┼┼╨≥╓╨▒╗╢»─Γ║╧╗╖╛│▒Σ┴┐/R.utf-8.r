library(vegan)

##读取数据
#读入物种数据
phylum <- read.delim('phylum_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#读取环境数据
env <- read.delim('env_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

##tb-PCA
#物种数据 Hellinger 预转化（处理包含很多 0 值的群落物种数据时，推荐使用）
phylum_hel <- decostand(phylum, method = 'hellinger')

#PCA 排序（vegan 包中 rda() 执行）
tbpca <- rda(phylum_hel, scale = FALSE)

#查看 PCA 结果等，I 型标尺为例
summary(tbpca, scaling = 1)
plot(tbpca, choices = c(1, 2), scaling = 1,  display = c('wa'))

#环境因子与非约束轴的多元回归，999 次置换检验
tbpca_ef <- envfit(tbpca~., data = env, perm = 999, choices = c(1,2), display = 'sites')
tbpca_ef

#p 值校正，bonferroni 方法
tbpca_ef_adj <- tbpca_ef
tbpca_ef_adj$vectors$pvals <- p.adjust(tbpca_ef_adj$vectors$pvals, method = 'bonferroni')
tbpca_ef_adj

#提取样方得分（坐标），I 型标尺为例，前两轴
tbpca_site.scaling1 <- scores(tbpca, choices = 1:2, scaling = 1, display = 'sites')
#或者
tbpca_site.scaling1 <- summary(tbpca, scaling = 1)$sites[ ,1:2]
#若输出在本地，以 csv 格式为例
write.csv(data.frame(tbpca_site.scaling1), 'pca_site.scaling1.csv')

#提取物种得分（坐标），I 型标尺为例，前两轴
tbpca_species.scaling1 <- summary(tbpca, scaling = 1)$species[ ,1:2]

#提取特征根、各轴解释量（各轴特征根占总特征根的比值）
eig <- tbpca$CA$eig
eig_prop <- tbpca$CA$eig / sum(tbpca$CA$eig)

#将环境变量的坐标、多元回归 r2、回归显著性（校正后的 p 值）输出在本地，以 csv 格式为例
tbpca_env <- data.frame(cbind(tbpca_ef_adj$vectors$arrows, tbpca_ef_adj$vectors$r, tbpca_ef_adj$vectors$pvals))
names(tbpca_env) <- c('PC1', 'PC2', 'r2', 'p.adj')
write.csv(tbpca_env, 'pca_env.csv')

#计算环境因子与样方得分的相关性
tbpca_env_cor <- cor(env[ ,c('DOC', 'AP', 'AK', 'NH4')], tbpca_site.scaling1, method = 'pearson')

#或者由排序坐标和 r2 反向推算出环境因子与样方得分的相关性
arrow_heads <- tbpca_ef_adj$vectors$arrows	#提取 env 向量（坐标）矩阵
r2 <- tbpca_ef_adj$vectors$r	#提取 env r2
arrow_heads * sqrt(r2)	#即可得相关性，结果和上述“tbpca_env”是一致的

#简要作图展示 PCA 结果（仅展示样方排序，不展示物种排序）
plot(tbpca, choices = c(1, 2), scaling = 1, type = 'n')
points(tbpca, choices = c(1, 2), scaling = 1, display = 'sites', pch = 20, col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)))

#简要作图展示被动添加环境因子后的 PCA 结果
plot(tbpca_ef_adj, choices = c(1, 2), p.max = 0.05)	#只保留 p.adj < 0.05 的结果

##CA 排序（vegan 包中 cca() 执行）
ca <- cca(phylum)

#被动添加环境变量的过程和上述 PCA 类似，不再演示（envfit()操作方法一致，注意统计细节上有所差别）

##PCoA 排序
#计算相异矩阵，以 Bray-curtis 距离为例（vegan 包中 vegdist() 执行）
bray <- vegdist(phylum, method = 'bray')
#若已经拥有了某个距离矩阵文件（例如文件“bray_distance.txt”），即可直接加载至R中使用
bray <- as.dist(read.delim('bray_distance.txt', row.names = 1, sep = '\t'))

#PCoA 排序（vegan 包中 cmdscale() 执行）
pcoa <- cmdscale(bray, k = (nrow(phylum) - 1), eig = TRUE)

#被动添加环境变量的过程和上述 PCA 类似，简要演示
pcoa_ef <- envfit(pcoa~., data = env, perm = 999, choices = c(1,2), display = 'sites')	#环境因子与非约束轴的多元回归，999 次置换检验
pcoa_ef$vectors$pvals <- p.adjust(pcoa_ef$vectors$pvals, method = 'bonferroni')	#p 值校正
plot(scores(pcoa)[ ,1], scores(pcoa)[ ,2], pch = 20, col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)))	#PCoA 作图
plot(pcoa_ef, choices = c(1, 2), p.max = 0.05)	#将 p.adj < 0.05 的结果投影至 PCoA

##NMDS 排序，以 Bray-curtis 距离为例（vegan 包中 metaMDS() 执行，排序轴设定为 2）
nmds <- metaMDS(phylum, distance = 'bray', k = 2)

#被动添加环境变量的过程和上述 PCA 类似，简要演示
nmds_ef <- envfit(nmds~., data = env, perm = 999, choices = c(1,2), display = 'sites')	#环境因子与非约束轴的多元回归，999 次置换检验
nmds_ef$vectors$pvals <- p.adjust(nmds_ef$vectors$pvals, method = 'bonferroni')	#p 值校正
plot(nmds, choices = c(1, 2), type = 'n')	#NMDS 作图
points(nmds, choices = c(1, 2), pch = 20, col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)))	#仅展示样方排序，不展示物种排序
plot(nmds_ef, choices = c(1, 2), p.max = 0.05)	#将 p.adj < 0.05 的结果投影至 NMDS

##ggplot2 作图示例，以上述 tb-PCA 为例
library(ggplot2)

#提取样方和环境因子排序坐标，前两轴，I 型标尺
tbpca_site.scaling1 <- data.frame(summary(tbpca, scaling = 1)$sites[ ,1:2])
tbpca_env_sign <- tbpca_env[which(tbpca_env$p.adj < 0.05),1:2]

#PCA 前两轴解释量（%）
tbpca_eig <- round(100 * tbpca$CA$eig[1:2] / sum(tbpca$CA$eig), 2)

#读取样本分组数据（附件“group.txt”，第一列为各样本名称，第二列为各样本所对应的分组）
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#合并样本分组信息，构建 ggplot2 作图数据集
tbpca_site.scaling1$sample <- rownames(tbpca_site.scaling1)
tbpca_site.scaling1 <- merge(tbpca_site.scaling1, group, by = 'sample')

tbpca_env_sign$sample <- NA
tbpca_env_sign$group <- rownames(tbpca_env_sign)

#ggplot2 作图
library(ggplot2)

p <- ggplot(tbpca_site.scaling1, aes(PC1, PC2)) +
geom_point(aes(color = group)) +
scale_color_manual(values = c('red', 'orange', 'green3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.title = element_blank(), legend.key = element_rect(fill = 'transparent')) + 
labs(x = paste('PCA1: ', tbpca_eig[1], '%'), y = paste('PCA2: ', tbpca_eig[2], '%')) +
geom_vline(xintercept = 0, color = 'gray', size = 0.5) + 
geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
geom_segment(data = tbpca_env_sign, aes(x = 0,y = 0, xend = PC1/5, yend = PC2/5), arrow = arrow(length = unit(0.1, 'cm')), size = 0.3, color = 'blue') +
geom_text(data = tbpca_env_sign, aes(PC1/5 * 1.1, PC2/5 * 1.1, label = group), color = 'blue', size = 3)

ggsave('pca_env.pdf', p, width = 5, height = 4)
ggsave('pca_env.png', p, width = 5, height = 4)

##将环境变量以非线性曲面的形式投影至排序空间中，可借此探索排序样本沿环境变量的梯度分布
#以两组环境变量（DOC、AK）为例
plot(tbpca, choices = c(1, 2), scaling = 1,  display = c('wa'), main = 'DOC + AK')
gam1 <- ordisurf(tbpca, env[, 'DOC'], add = TRUE, col = 'red3')
gam2 <- ordisurf(tbpca, env[, 'AK'], add = TRUE, col = 'green3')

#可以再把上述 envfit() 的线性拟合结果添进去，只显示环境变量“DOC”和“AK”
select <- which(rownames(tbpca_ef_adj$vectors$arrows) %in% c('DOC', 'AK'))
tbpca_ef_adj_select <- tbpca_ef_adj
tbpca_ef_adj_select$vectors$arrows <- tbpca_ef_adj_select$vectors$arrows[select, ]
tbpca_ef_adj_select$vectors$r <- tbpca_ef_adj_select$vectors$r[select]
tbpca_ef_adj_select$vectors$pvals <- tbpca_ef_adj_select$vectors$pvals[select]

plot(tbpca_ef_adj_select, choices = c(1, 2), add = TRUE, col = c('red3', 'green3'))

#作图结果默认绘制，以下简要查看回归详情
gam1
summary(gam1)

##不能在约束轴中添加补充变量，以下以错误做法展示
#示例一，以 4 个环境变量数据为例
rda_tb <- rda(phylum_hel~., env[ ,c('DOC', 'AP', 'AK', 'NH4')], scale = FALSE)
rda_ef_site <- envfit(rda_tb~., env[ ,c('DOC', 'AP', 'AK', 'NH4')], perm = 999, choices = c(1,2), display = 'sites')	#拟合环境变量（与样方得分）
rda_ef_site$vectors$pvals <- p.adjust(rda_ef_site$vectors$pvals, method = 'bonferroni')	
rda_ef_lc <- envfit(rda_tb~., env[ ,c('DOC', 'AP', 'AK', 'NH4')], perm = 999, choices = c(1,2), display = 'lc')	#拟合环境变量（与物种得分）
rda_ef_lc$vectors$pvals <- p.adjust(rda_ef_lc$vectors$pvals, method = 'bonferroni')	

plot(rda_tb, display = c('wa', 'cn'), col = 'blue')	#RDA
plot(rda_ef_site, col = 'red')	#与 RDA 样方得分的拟合
plot(rda_ef_lc, col = 'green3')	#与 RDA 物种得分的拟合

#示例二
set.seed(123)
random <- runif(27)

tbpca <- rda(phylum_hel)
envfit(tbpca ~ random)	#随机数拟合至 PCA 轴，不显著（正常）

rda_tb <- rda(phylum_hel ~ random)
anova(rda_tb)	#随机数的 RDA 的置换检验，不显著（正常）
 
envfit(rda_tb ~ random)	#随机数拟合至 RDA 轴，显著！！（将产生错误引导）

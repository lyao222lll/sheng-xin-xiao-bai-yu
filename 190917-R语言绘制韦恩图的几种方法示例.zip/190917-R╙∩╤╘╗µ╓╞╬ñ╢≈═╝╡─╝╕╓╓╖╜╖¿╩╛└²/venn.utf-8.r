####韦恩图（VennDiagram 包，适用样本数 2-5）
library(VennDiagram)

#读入作图文件
venn_dat <- read.delim('flower.txt', header = T, sep = '\t', stringsAsFactors = F, check.names = F)
#从中选上 5 个样本作为示例
venn_list <- list(c1 = venn_dat[,1], c2 = venn_dat[,2], c3 = venn_dat[,3], c4 = venn_dat[,4], c5 = venn_dat[,5])

#作图，详情使用 ?venn.diagram 查看帮助
venn.diagram(venn_list, filename = 'venn.png', 
	fill = c('red', 'green', 'blue', 'orange', 'purple'), alpha = 0.50, cat.col = rep('black', 5), 
	col = 'black', cex = 1, fontfamily = 'serif', cat.cex = 1, cat.fontfamily = 'serif', margin = 0.2)

####韦恩图（gplots 包，适用样本数 2-5）
library(gplots)

#读入作图文件
venn_dat <- read.delim('flower.txt', header = T, sep = '\t', stringsAsFactors = F, check.names = F)
#从中选上 5 个样本作为示例
venn_list <- list(c1 = venn_dat[,1], c2 = venn_dat[,2], c3 = venn_dat[,3], c4 = venn_dat[,4], c5 = venn_dat[,5])

#作图，详情使用 ?venn 查看帮助
result <- venn(venn_list)
str(result)

####韦恩图（limma 包，适用样本数 2-5）
library(limma)

#读入作图文件
venn_dat <- read.delim('otu_table.txt', row.names = 1, header = T, sep = '\t', stringsAsFactors = F, check.names = F)
venn_dat[venn_dat > 0] <- 1
#从中选上 5 个样本作为示例
venn_data <- vennCounts(as.matrix(venn_dat[1:5]))

#作图，详情使用 ?vennDiagram 查看帮助（这函数名称起的，咋一看还以为是那个 vennDiagram 包......）
vennDiagram(venn_data, include = 'both', names = c('c1', 'c2', 'c3', 'c4', 'c5'), cex = 1, 
	counts.col = 'black', circle.col = c('red', 'green', 'blue', 'orange', 'purple'))

####韦恩图（venn 包，适用样本数 2-7）
library(venn)

#读入作图文件
venn_dat <- read.delim('flower.txt', header = T, sep = '\t', stringsAsFactors = F, check.names = F)
#从中选上 7 个样本作为示例
venn_list <- list(c1 = venn_dat[,1], c2 = venn_dat[,2], c3 = venn_dat[,3], c4 = venn_dat[,4], c5 = venn_dat[,5], c6 = venn_dat[,6], c7 = venn_dat[,7])

#作图，详情使用 ?venn 查看帮助（注：它的作图函数也是 venn()，和上述 gplots 包存在冲突）
venn(venn_list, zcolor = 'style')

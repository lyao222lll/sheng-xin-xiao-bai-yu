#Bioconductor 安装 EBSeq
BiocManager::install('EBSeq')

#加载 EBSeq
library(EBSeq)

####两组间差异基因
##数据
#测试数据
data(GeneMat)

#手动将测试基因数据集设置为两组，前 5 列为 C1 组，后 5 列 C2 组
group <- factor(rep(c('C1', 'C2'), each = 5), levels = c('C1', 'C2'))

#通过 MedianNorm() 来获取标准化因子，等同于 DESeq 中的中位数标准化（Median Normalization）方法
ls_factor <- MedianNorm(GeneMat)

#其它标准化方法，例如通过 QuantileNorm() 实现上四分位数标准化
#ls_factor <- QuantileNorm(GeneMat, 0.75) 
#等等方法，根据实际情况选择，大家自行了解

##EBSeq 差异基因分析
#EBSeq 计算，本示例迭代 5 次是合适的
EBOut <- EBTest(Data = GeneMat, Conditions = group, sizeFactors = ls_factor, maxround = 5)

summary(EBOut)
#如果这些结果中，最后两个值相差小于 0.01 就表明迭代次数 maxround 合理
EBOut$Alpha
EBOut$Beta
EBOut$P

#鉴定差异基因（FDR < 0.05，其他参数如 Fold Change 等使用默认值）
EBDERes <- GetDEResults(EBOut, FDR = 0.05)

summary(EBDERes)
EBDERes$DEfound	#鉴定的差异基因
head(EBDERes$PPMat)	#EE、DE 后验概率矩阵，若 EE < 0.05 则为差异基因（可以将 EE 列视为 FDR 校正后的 p-value）
head(EBDERes$Status)	#每个基因的判别状态，可参阅 ?GetDEResults

#如上所述，获取每个基因的 FDR p-value
FDR <- EBDERes$PPMat[ ,1]

#获取获取每个基因的 Fold Change (FC) 
gene_FC <- PostFC(EBOut)

str(gene_FC)
head(gene_FC$RealFC)	#raw data 的 FC
head(gene_FC$PostFC)	#normalized data 的 posterior FC

PlotPostVsRawFC(EBOut, gene_FC)	#Plot PostFC vs RealFC

FC_diff <- data.frame(C1_Mean = unlist(EBOut$C1Mean), C2_Mean = unlist(EBOut$C2Mean), FC_diff = abs(gene_FC$RealFC-gene_FC$PostFC))	#不妨直接观察基因表达水平与 |RealFC - PostFC| 值的关系

##模型诊断
#使用 Q-Q 图，拟合经验 q's 和使用 β 先验分布模拟的 q's，评估 β 先验合理性
par(mfrow = c(1, 2))
QQP(EBOut)

#查看经验 q's 和使用 β 先验分布模拟的 q's 的密度图，评估 β 先验合理性
par(mfrow = c(1, 2))
DenNHist(EBOut)

#整合版输出示例
C1_Mean <- unlist(EBOut$C1Mean)	#C1 分组中，各基因标准化后的平均表达量
C2_Mean <- unlist(EBOut$C2Mean)	#C2 分组中，各基因标准化后的平均表达量
FoldChange <- gene_FC$PostFC	#使用 PostFC 获取
log2FoldChange <- log(FoldChange, 2)	#log2 Fold Change

EBSeq_stat <- data.frame(C1_Mean, C2_Mean, FoldChange, log2FoldChange, FDR)
write.table(EBSeq_stat, 'EBSeq_stat_two.txt', sep = '\t', col.names = NA, quote = FALSE)

##火山图示例，以 FC >= 2 和 FDR < 0.05 作为差异/非差异基因的分界点
#随便画一下观测数据，横轴 log2 Fold Change（使用 PostFC 获取），纵轴 -log10 FDR，本人对 plot() 不擅长就不调整细节了
plot(log2FoldChange, -log10(FDR + min(FDR[FDR != 0], na.rm = TRUE)), pch = 20)	#给 FDR 加个小值，避免 0 无法 log 转化的问题
abline(v = 1, lty = 2)	#Fold Change 上调 2 倍的分界线，对应于 log2 Fold Change = 1 的位置
abline(v = -1, lty = 2)	#Fold Change 下调 2 倍的分界线，对应于 log2 Fold Change = -1 的位置
abline(h = -log(0.05, 10), lty = 2)	#p-value = 0.05 的位置

#ggplot2 作图体验更佳
EBSeq_stat <- read.delim('EBSeq_stat_two.txt', sep = '\t')

#例如这里自定义根据 |log2FC| >= 1 和 FDR < 0.05 标记差异类型
EBSeq_stat[which(EBSeq_stat$FDR < 0.05 & EBSeq_stat$log2FoldChange <= -1),'sig'] <- 'down'
EBSeq_stat[which(EBSeq_stat$FDR < 0.05 & EBSeq_stat$log2FoldChange >= 1),'sig'] <- 'rich'
EBSeq_stat[which(EBSeq_stat$FDR >= 0.05 | abs(EBSeq_stat$log2FoldChange) < 1),'sig'] <- 'no diff'

#横轴 log2FC（使用 PostFC 获取），纵轴 log10 转化后的标准化后基因表达量的平均值，颜色表示差异
library(ggplot2)

volcano_plot <- ggplot(EBSeq_stat, aes(log2FoldChange, log10((C1_Mean + C2_Mean)/2))) +
geom_point(aes(color = sig), alpha = 0.6, size = 1) +
scale_colour_manual(values  = c('blue2', 'red2', 'gray'), limits = unique(EBSeq_stat$sig)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.key = element_rect(fill = 'transparent')) +
geom_vline(xintercept = c(-1, 1), color = 'gray', size = 0.25) + 
geom_hline(yintercept = -log(0.05, 10), color = 'gray', size = 0.5) +
xlim(-3, 3) +
labs(x = 'log2 Fold Change (C1 vs C2)', y = 'log10 Mean of Normalized Count', color = '')

#ggsave('volcano_plot.pdf', volcano_plot, width = 5, height = 5)
ggsave('volcano_plot.png', volcano_plot, width = 5, height = 5)

##前 30 个差异基因的热图展示示例
#选择前 30 个差异基因（根据 EBSeq 默认结果 EBDERes）
DEgene_30_name <- head(EBDERes$DEfound, 30)
DEgene_30_count <- GeneMat[DEgene_30_name, ]	#原始表达量
names(DEgene_30_count) <- as.character(1:10)
colgroup <- rep(c('red', 'blue'), each = 5)

#gplots 包 headmap.2()
library(gplots)

colorsChoice <- colorRampPalette(c('red', 'white', 'blue'))
heatmap.2(DEgene_30_count, density.info = c('none'), trace = 'none',col = colorsChoice(20), scale = 'column', srtCol = 0, ColSideColors = colgroup, colCol = colgroup)	#作图时默认对基因表达量标准化

####多组间分析，以三组间差异基因分析为例
##准备
#测试数据
data(MultiGeneMat)

#分组，模拟 3 组
group <- factor(rep(c('C1', 'C2', 'C3'), each = 2), levels = c('C1', 'C2', 'C3'))

#通过 MedianNorm() 来获取标准化因子，等同于 DESeq 中的中位数标准化（Median Normalization）方法
ls_factor <- MedianNorm(MultiGeneMat)

#基因差异模式 Pattern
parti <- GetPatterns(group)
PlotPattern(parti)
#parti_select <- parti[c('Pattern1', 'Pattern5'), ]	#要是不关注这么多情况的话，可以预先选择下（可以节约计算资源）

##EBSeq 计算，本示例迭代 5 次是合适的
MultiOut <- EBMultiTest(Data = MultiGeneMat, Conditions = group, sizeFactors = ls_factor, AllParti = parti, maxround = 5)
summary(MultiOut)

#获得每个基因在每个 Pattern 中的后验概率
MultiPP <- GetMultiPP(MultiOut)

summary(MultiPP)
MultiPP$Patterns	#基因差异模式 Pattern
head(MultiPP$PP)	#各基因在各模式中的后验概率
head(MultiPP$MAP)	#最终划分的各基因的 Pattern（哪个 Pattern 的后验概率高就为哪个）

#整合并输出，一个示例
C1_Mean <- unlist(MultiOut$SPMean[[1]][[1]])	#C1 分组中，各基因标准化后的平均表达量
C2_Mean <- unlist(MultiOut$SPMean[[1]][[2]])	#C2 分组中，各基因标准化后的平均表达量
C3_Mean <- unlist(MultiOut$SPMean[[1]][[3]])	#C3 分组中，各基因标准化后的平均表达量

MAP <- MultiPP$MAP	#Pattern 类型
EBSeq_stat <- data.frame(C1_Mean, C2_Mean, C3_Mean, MAP)
for (i in 1:nrow(EBSeq_stat)) EBSeq_stat[i,'C1_C2_C3'] <- paste(parti[EBSeq_stat[i,'MAP'], ], collapse = '_')

write.table(EBSeq_stat, 'EBSeq_stat_three.txt', sep = '\t', col.names = NA, quote = FALSE)

##三个样本的可视化可以使用三元相图
EBSeq_stat <- read.delim('EBSeq_stat_three.txt', sep = '\t')

#由于多组模式无 Fold Change (FC)，因此我们直接根据各基因在各组中的平均表达量判别组间表达水平高低
#同时结合 Pattern，判别显著性

#计算各基因在哪个分组中的表达最高
EBSeq_stat$max <- apply(EBSeq_stat[2:4], 1, function(x) names(x)[x %in% max(x)])

#根据 Pattern 以及各基因所在表达最高的分组，标记基因富集分组
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern1'),'high_sample'] <- 'none'

EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern2' & EBSeq_stat$max == 'C3_Mean'),'high_sample'] <- 'C3'
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern2' & EBSeq_stat$max %in% c('C1_Mean', 'C2_Mean')),'high_sample'] <- 'C1 & C2'

EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern3' & EBSeq_stat$max == 'C2_Mean'),'high_sample'] <- 'C2'
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern3' & EBSeq_stat$max %in% c('C1_Mean', 'C3_Mean')),'high_sample'] <- 'C1 & C3'

EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern4' & EBSeq_stat$max == 'C1_Mean'),'high_sample'] <- 'C1'
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern4' & EBSeq_stat$max %in% c('C2_Mean', 'C3_Mean')),'high_sample'] <- 'C2 & C3'

EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern5' & EBSeq_stat$max == 'C1_Mean'),'high_sample'] <- 'C1'
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern5' & EBSeq_stat$max == 'C2_Mean'),'high_sample'] <- 'C2'
EBSeq_stat[which(EBSeq_stat$MAP == 'Pattern5' & EBSeq_stat$max == 'C3_Mean'),'high_sample'] <- 'C3'

#这里计算了各基因在所有样本中表达量的均值的平方根，用于作图时定义点的大小......
EBSeq_stat$size <- apply(EBSeq_stat[2:4], 1, function(x) sqrt(mean(x)))

#ggtern 三元相图示例
library(ggtern)

tern_plot <- ggtern(EBSeq_stat, aes(C1_Mean, C2_Mean, C3_Mean)) +
geom_mask() +
geom_point(aes(color = high_sample, size = size), alpha = 0.6) +
scale_size(range = c(0, 4)) +
scale_colour_manual(values  = c('red', 'blue', 'green3', 'purple', 'orange', 'skyblue', 'gray'), limits = c('C1', 'C2', 'C3', 'C1 & C2', 'C1 & C3', 'C2 & C3', 'none')) +
theme_bw() +
theme(axis.text = element_blank(), axis.ticks = element_blank()) +
labs(x = 'C1', y = 'C2', z = 'C3', color = 'en-riched') +
guides(size = FALSE)

#ggsave('tern_plot.pdf', tern_plot, width = 6.5, height = 5)
ggsave('tern_plot.png', tern_plot, width = 6.5, height = 5)

##关于更多的分组
#其实不建议设置很多分组了，分组越多越不利于解读

####附：这是一个不错的帖子，帮助了解 EBSeq 的工作原理，有兴趣可以自行查看
#https://www.biostars.org/p/227474/

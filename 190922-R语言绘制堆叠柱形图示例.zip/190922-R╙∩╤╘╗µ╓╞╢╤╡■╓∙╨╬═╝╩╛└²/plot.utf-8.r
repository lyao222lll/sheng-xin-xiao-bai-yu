#读取数据
phylum_top10 <- read.csv('phylum_top10.csv', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)

#barplot() 作图，可使用 ?barplot 查看该命令详情
png('barplot_plot.png', width = 1000, height = 700)
par(xpd = TRUE, mar = par()$mar + c(1, 3, 1, 16))

barplot(as.matrix(100 * phylum_top10), col = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray'),
	legend = rownames(phylum_top10), 
	cex.axis = 2, cex.names = 2, ylim = c(0, 100), las = 1, width = 0.5, space = 0.5, beside = FALSE,
	args.legend = list(x = 'right', bty = 'n', inset = -0.18, cex = 2, y.intersp = 1.2, x.intersp = 0.7, text.width = 1))

mtext('Relative Abundance(%)', cex = 2, side = 2, line = 4)

dev.off()

####ggplot2 作图（一个简单示例）
library(reshape2)
library(ggplot2)

#整理成 ggplot2 作图格式
phylum_top10$Taxonomy <- factor(rownames(phylum_top10), levels = rev(rownames(phylum_top10)))
phylum_top10 <- melt(phylum_top10, id = 'Taxonomy')

#添加分组，这次我们根据样本分组绘制分面
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE)
names(group)[1] <- 'variable'
phylum_top10 <- merge(phylum_top10, group, by = 'variable')

#绘制带分面的柱状图
p <- ggplot(phylum_top10, aes(variable, 100 * value, fill = Taxonomy)) +
geom_col(position = 'stack', width = 0.6) +
facet_wrap(~group, scales = 'free_x', ncol = 2) +
scale_fill_manual(values =  rev(c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray'))) +
labs(x = '', y = 'Relative Abundance(%)') +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), strip.text = element_text(size = 12)) +
theme(axis.text = element_text(size = 12), axis.title = element_text(size = 13), legend.title = element_blank(), legend.text = element_text(size = 11))

ggsave('ggplot2_plot.png', p, width = 8, height = 6)

##响应变量是连续变量时，用于回归
library(gbmplus)

#读取软珊瑚属丰富度及环境和空间因素数据
softcorals <- read.csv('softcorals.csv', check.names = FALSE)

#将软珊瑚属丰富度作为响应变量，环境和空间因素作为自变量，构建 ABT 执行回归
#详情 ?gbm，该示例生成 500 个随机树用作 boosting，并使用 5 折交叉验证估计误差，其余使用默认值
set.seed(123)
fit_softcorals <- gbm(Richness~Across+Along+Visibility+Slope+Flow+Wave+Sediment, 
    data = softcorals, n.trees = 100, cv.folds = 5)

par(las = 1)
summary(fit_softcorals)

#将变量重要性的结果信息提取后输出
softcorals_var_influence <- summary(fit_softcorals)
write.csv(softcorals_var_influence, 'softcorals.var_influence.csv', row.names = FALSE, quote = FALSE)

#然后打开一个已经安装 ggplot2 的较新的 R 版本
#加载 ggplot2，读取数据后重新绘制变量重要性的柱形图
library(ggplot2)

softcorals_var_influence <- read.csv('softcorals.var_influence.csv', stringsAsFactors = FALSE)
softcorals_var_influence <- softcorals_var_influence[order(softcorals_var_influence$rel.influence), ]
softcorals_var_influence$var <- factor(softcorals_var_influence$var, levels = softcorals_var_influence$var)

#颜色代表不同的变量
p <- ggplot(softcorals_var_influence, aes(var, rel.influence)) +
coord_flip() +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(colour = 'black')) +
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Relative influence(%)', title = '')

p + geom_col(aes(fill = var), width = 0.7, show.legend = FALSE) +
scale_fill_manual(values = c('#8DD3C7', '#FFFFB3', '#BEBADA', 
    '#FB8072', '#80B1D3', '#FDB462', '#B3DE69'))

#或者颜色以渐变色表示变量的重要性
p + geom_col(aes(fill = rel.influence), width = 0.7, show.legend = FALSE) +
scale_fill_gradientn(colours = colorRampPalette(c('#86CEF7', '#0000F6'))(10))

##响应变量是类别变量时，用于分类
library(gbmplus)

#读取鱼鳞数据及其元素组成含量数据
barramundi <- read.csv('barramundi.csv', check.names = FALSE)
barramundi$Fresh <- as.factor(barramundi$Fresh)

#将鱼鳞样本来源（淡水或河口）作为响应变量，鱼鳞元素组成含量为解释变量，构建 ABT 执行分类
#详情 ?gbm，该示例生成 500 个随机树用作 boosting，并使用 5 折交叉验证估计误差，其余使用默认值
set.seed(123)
fit_barramundi <- gbm(Fresh~Sr+Ba+Mn+Mg+Fe+Zn+K+P+S, 
    data = barramundi, n.trees = 100, cv.folds = 5)

par(las = 1)
summary(fit_barramundi)

pretty.gbm.tree(fit_softcorals)

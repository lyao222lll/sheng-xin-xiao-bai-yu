library(pls)

#示例数据，详情 ?yarn
data(yarn)
head(yarn)

#选择训练集和测试集
yarn_train <- subset(yarn, train)
yarn_test <- subset(yarn, !train)

##使用训练集数据构建 PLS 回归模型，详情 ?plsr
#例如这里设定成分数 4（结果中展示前 4 个主要的成分），并执行交叉验证
pls_mod <- plsr(density~NIR, data = yarn_train, scale = TRUE, ncomp = 4, validation = 'CV')

summary(pls_mod)  #回归统计概要

##查看成分的重要性，确定保留哪些成分是合适的
#详情 ?validationplot
par(mfrow = c(1, 2))
validationplot(pls_mod, val.type = 'MSEP')
validationplot(pls_mod, val.type = 'R2')

#模型预测值和响应变量实际观测值的比较简图
#ncomp 指定预测使用的成分数量
par(mfrow = c(1, 3))
plot(pls_mod, ncomp = 1, line = TRUE)  #使用第一成分的预测
plot(pls_mod, ncomp = 2, line = TRUE)  #使用前两成分的预测
plot(pls_mod, line = TRUE)  #使用全部成分的预测

##查看结果中包含的各类统计信息，可通过“pls_mod$XXX”之类的语句提取查看
names(pls_mod)

#例如，提取对象得分（可以理解为，样本投影在成分轴上的坐标）
yarn_site <- pls_mod$scores

#合并涤纶纱密度数值信息
yarn_site <- data.frame(yarn_site[ , ])
yarn_density <- yarn_train$density
yarn_site <- cbind(yarn_site, yarn_density)

#绘制得分图
library(ggplot2)

ggplot(yarn_site, aes(Comp.1, Comp.2, color = yarn_density)) +
geom_point() +
scale_color_gradientn(colors = c('green', 'orange', 'red')) +
theme_bw()

##将该 PLS 回归应用至测试集数据
#进一步比较模型预测值和响应变量观测值的一致性
par(mfrow = c(1, 2))

#使用前两成分的预测
fit_test_2 <- predict(pls_mod, yarn_test, ncomp = 2)
plot(yarn_test$density, fit_test_2, main = 'density, 2 comps, validation', 
    xlab = 'measured', ylab = 'predicted')
abline(0, 1, col = 'red')

#使用全部四个成分的预测
fit_test_4 <- predict(pls_mod, yarn_test, ncomp = 4)
plot(yarn_test$density, fit_test_4, main = 'density, 4 comps, validation', 
    xlab = 'measured', ylab = 'predicted')
abline(0, 1, col = 'red')

##变量的重要性
#这次直接使用全部的数据集（不区分训练集或测试集）构建 PLS 回归
#plsr() 中重新设定成分数 2
pls_mod2 <- plsr(density~NIR, data = yarn, scale = TRUE, ncomp = 2, validation = 'CV')

#由于变量在 PLS 回归时已经过 scale 参数执行了标准化处理
#因此可将回归系数的绝对值大小作为评估变量的相对重要性的依据
coefficients <- coef(pls_mod2)
coef_weight <- abs(coefficients)  #回归系数的绝对值

coef_sum <- sum(coef_weight)
importance <- coef_weight * 100 / coef_sum  #根据回归系数的绝对值计算的各变量的百分比重要性
importance <- sort(importance[ ,1,1], decreasing = TRUE)  #按重要性排序
importance <- cbind(importance, coefficients = coefficients[ ,1,1][names(importance)])

write.table(importance, 'NIR_importance.txt', col.names = NA, sep = '\t', quote = FALSE)

#查看前 10 种重要的光谱
coef_top10 <- head(importance, 10)
coef_top10

par(las = 1)
barplot(coef_top10[ ,1], horiz = TRUE, width = 0.6, xlab = 'importance (%)', 
    col = ifelse(coef_top10[ ,2] > 0, 'red', 'blue'))


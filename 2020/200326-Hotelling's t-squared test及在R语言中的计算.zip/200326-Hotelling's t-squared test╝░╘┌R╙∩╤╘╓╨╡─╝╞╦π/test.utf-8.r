#加载 R 包
library(mvtnorm)  #用于生成模拟数据
library(ICSNP)  #用于 Hotelling's t-squared test

##两独立样本
#Simulate data
set.seed(123)
Nj <- c(15, 25)
Sigma <- matrix(c(16, -2, -2, 9), byrow = TRUE, ncol = 2)

mu1 <- c(-4, 4)
Y1 <- round(rmvnorm(Nj[1], mean = mu1, sigma = Sigma))
mu2 <- c(3, 3)
Y2 <- round(rmvnorm(Nj[2], mean = mu2, sigma = Sigma))
Y12 <- rbind(Y1, Y2)
IV <- factor(rep(1:2, Nj))

#QQ-plot 检验多元正态性（尽可能沿直线分布）
coord <- qqplot(qchisq(ppoints(nrow(Y12)), df = ncol(Y12)), mahalanobis(Y12, colMeans(Y12), cov(Y12)))
abline(a = 0, b = 1)

#Box's M 检验验证方差-协方差矩阵同质性（p>0.05 说明各组的协方差矩阵相同）
library(biotools)
boxM(Y12, IV)

#Hotelling's T2-test for two independent samples
ht2 <- HotellingsT2(Y12 ~ IV, test = 'f')
ht2

ht2$statistic  #T2 统计量
ht2$parameter  #自由度
ht2$p.value  #p 值

#MANOVA
summary(manova(Y12 ~ IV))

#Comparisons between Multivariate Linear Models
anova(lm(Y12 ~ IV), test = 'Hotelling-Lawley')

##两相关样本
#Simulate data
set.seed(123)
N <- 20
P <- 2
muJK <- c(90, 100, 85, 105)
Sig <- 15

Y1t0 <- rnorm(N, mean = muJK[1], sd = Sig)
Y1t1 <- rnorm(N, mean = muJK[2], sd = Sig)
Y2t0 <- rnorm(N, mean = muJK[3], sd = Sig)
Y2t1 <- rnorm(N, mean = muJK[4], sd = Sig)
Ydf <- data.frame(id = factor(rep(1:N, times = P)),
    Y1 = c(Y1t0, Y1t1),
    Y2 = c(Y2t0, Y2t1),
    IV = factor(rep(1:P, each = N), labels = c('t0', 't1')))

dfDiff <- aggregate(cbind(Y1, Y2) ~ id, data = Ydf, FUN = diff)
DVdiff <- data.matrix(dfDiff[ ,-1])
muH0 <- c(0, 0)

#Hotelling's T2-test for two dependent samples
HotellingsT2(DVdiff, mu = muH0, test = 'f')

#Comparisons between Multivariate Linear Models
anova(lm(DVdiff ~ 1), test='Hotelling-Lawley')

##单样本
#Simulate data
set.seed(123)

Nj <- c(15, 25)
Sigma <- matrix(c(16, -2, -2, 9), byrow = TRUE, ncol = 2)
mu1 <- c(-4, 4)
Y1 <- round(rmvnorm(Nj[1], mean = mu1, sigma = Sigma))

#One-sample Hotelling's T2-test
muH0 <- c(-1, 2)
HotellingsT2(Y1, mu = muH0, test = 'f')

#Comparisons between Multivariate Linear Models
Y1ctr <- sweep(Y1, 2, muH0, '-')
anova(lm(Y1ctr ~ 1), test = 'Hotelling-Lawley')

# 测试数据的来源
# https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4845060/

####
##根据经纬度计算采样点的地理距离
#读取采样点的地理位置数据
site <- read.delim('site.txt', sep = '\t', row.names = 1, check.names = FALSE)

#计算采样点间的地理距离
#geosphere 包 distm() 根据经纬度计算地理距离（默认距离单位，米）
#distm() 要求两列数据，第一列是经度，第二列是纬度
site_dis <- geosphere::distm(site[c('Lon (°W)', 'Lat (°N)')]) 
rownames(site_dis) <- rownames(site)
colnames(site_dis) <- rownames(site)

#将采样点地理距离矩阵转换为两两对应数值的数据框结构
site_dis <- reshape2::melt(site_dis)
site_dis <- subset(site_dis, value != 0)
head(site_dis)

##计算群落间物种组成相似度
#浮游细菌群落物种组成数据，首先以 85_120 为例，140_200 替换文件即可
spe <- read.delim('FL_North.depth85_120.otu_table.txt', sep = '\t', row.names = 1, check.names = FALSE)
spe <- data.frame(t(spe))

#vegan 包 vegdist() 计算群落间物种组成 Bray-curtis 相异度矩阵
#并通过 1-Bray-curtis 获得群落物种组成相似度矩阵
comm_sim <- 1 - as.matrix(vegan::vegdist(spe, method = 'bray'))

#将矩阵转换为两两群落对应数值的数据框结构
diag(comm_sim) <- 0  #去除群落相似度矩阵中的对角线值，它们是样本的自相似度
comm_sim[upper.tri(comm_sim)] <- 0  #群落相似度矩阵是对称的，因此只选择半三角（如下三角）区域的数值即可
comm_sim <- reshape2::melt(comm_sim)
comm_sim <- subset(comm_sim, value != 0)
head(comm_sim)

#采样点距离和群落相似度数据合并
comm_dis <- merge(comm_sim, site_dis, by = c('Var1', 'Var2'))
names(comm_dis) <- c('site1', 'site2', 'comm_sim', 'site_dis')
comm_dis$depth <- '85-120'  #这里以 85_120 为例，140_200 注意替换
head(comm_dis)

#write.table(comm_dis, 'comm_dis.depth85_120.txt', sep = '\t', row.names = FALSE, quote = FALSE)

##一个简单的线性回归
#lm() 拟合线性回归
fit <- lm(comm_sim~site_dis, data = comm_dis)
summary(fit)

#标识与最北部地区 NADR 中采样地点有关的距离对
#文献原图中，涉及 NADR 中采样地点的距离关系都使用红色点标出
site_edge <- rownames(subset(site, Province == 'NADR'))
comm_dis[which(as.character(comm_dis$site1) %in% site_edge | as.character(comm_dis$site2) %in% site_edge),'color'] <- 'red'
comm_dis[which(! comm_dis$color %in% 'red'),'color'] <- 'black'

#简单作图
plot(comm_dis$site_dis/1000, comm_dis$comm_sim, pch = 20, col = comm_dis$color, 
    xlab = 'Distance (km)', ylab = 'Bray-curtis similarity')
lines(comm_dis$site_dis/1000, fitted(fit))
text(4000, 0.7, expression(R^2==0.47))

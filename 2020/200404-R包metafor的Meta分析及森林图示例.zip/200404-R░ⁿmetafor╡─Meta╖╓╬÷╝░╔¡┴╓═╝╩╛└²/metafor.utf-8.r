library(metafor)

#示例数据集，详情 ?dat.bcg
data(dat.bcg)
head(dat.bcg)

#拟合随机效应模型（random-effects model），详情 ?rma
res <- rma(ai = tpos, bi = tneg, ci = cpos, di = cneg, data = dat.bcg, 
    measure = 'RR', slab = paste(author, year, sep = ', '), method = 'REML')
res

#查看结果中包含的各项统计量概要，并可从中提取想要的信息
#详见 ?rma 中对各项统计量的描述
names(res)
res$pval  #如 p 值

#绘制森林图
#可自定义设置坐标轴刻度、文本范围、字体大小等，详情 ?forest
forest(res, xlim = c(-16, 6), at = log(c(0.05, 0.25, 1, 4)), atransf = exp,
    ilab = cbind(dat.bcg$tpos, dat.bcg$tneg, dat.bcg$cpos, dat.bcg$cneg),
    ilab.xpos = c(-9.5, -8, -6, -4.5), cex = 0.75, ylim = c(-1, 27),
    order = order(dat.bcg$alloc), rows = c(3:4, 9:15, 20:23),
    xlab = 'Risk Ratio', mlab = '', psize = 1, header = 'Author(s) and Year')

#添加 Q 值、自由度、p 值等统计量
text(-16, -1, pos = 4, cex = 0.75, bquote(paste('RE Model for All Studies (Q = ',
    .(formatC(res$QE, digits = 2, format = 'f')), ', df = ', .(res$k - res$p),
    ', p = ', .(formatC(res$QEp, digits = 2, format = 'f')), '; ', I^2, ' = ',
    .(formatC(res$I2, digits = 1, format = 'f')), '%)')))

#继续为子组添加文本
op <- par(cex = 0.75, font = 4)  #定义字体尺寸

text(-16, c(24,16,5), pos = 4, c('Systematic Allocation', 'Random Allocation', 'Alternate Allocation'))

#将列标题添加到绘图中
par(font = 2)  #定义字体加粗
text(c(-9.5, -8, -6, -4.5), 26, c('TB+', 'TB-', 'TB+', 'TB-'))
text(c(-8.75, -5.25), 27, c('Vaccinated', 'Control'))

#继续拟合三个亚组的随机效应模型（random-effects model），并将结果添加到森林图中
res.s <- rma(ai = tpos, bi = tneg, ci = cpos, di = cneg, data = dat.bcg, measure = 'RR',
    subset = (alloc == 'systematic'), method = 'REML')
res.r <- rma(ai = tpos, bi = tneg, ci = cpos, di = cneg, data = dat.bcg, measure = 'RR',
    subset = (alloc == 'random'), method = 'REML')
res.a <- rma(ai = tpos, bi = tneg, ci = cpos, di = cneg, data = dat.bcg, measure = 'RR',
    subset = (alloc == 'alternate'), method = 'REML')

#将计算结果继续添加到上述森林图中
par(op)  #返回默认字体样式

addpoly(res.s, row = 18.5, cex = 0.75, atransf = exp, mlab = '')
addpoly(res.r, row =  7.5, cex = 0.75, atransf = exp, mlab = '')
addpoly(res.a, row =  1.5, cex = 0.75, atransf = exp, mlab = '')

#添加 Q 值、自由度、p 值等统计量
text(-16, 18.5, pos = 4, cex = 0.75, bquote(paste('RE Model for Subgroup (Q  =  ',
    .(formatC(res.s$QE, digits = 2, format = 'f')), ', df  =  ', .(res.s$k - res.s$p),
    ', p  =  ', .(formatC(res.s$QEp, digits = 2, format = 'f')), '; ', I^2, '  =  ',
    .(formatC(res.s$I2, digits = 1, format = 'f')), '%)')))
text(-16, 7.5, pos = 4, cex = 0.75, bquote(paste('RE Model for Subgroup (Q  =  ',
    .(formatC(res.r$QE, digits = 2, format = 'f')), ', df  =  ', .(res.r$k - res.r$p),
    ', p  =  ', .(formatC(res.r$QEp, digits = 2, format = 'f')), '; ', I^2, '  =  ',
    .(formatC(res.r$I2, digits = 1, format = 'f')), '%)')))
text(-16, 1.5, pos = 4, cex = 0.75, bquote(paste('RE Model for Subgroup (Q  =  ',
    .(formatC(res.a$QE, digits = 2, format = 'f')), ', df  =  ', .(res.a$k - res.a$p),
    ', p  =  ', .(formatC(res.a$QEp, digits = 2, format = 'f')), '; ', I^2, '  =  ',
    .(formatC(res.a$I2, digits = 1, format = 'f')), '%)')))

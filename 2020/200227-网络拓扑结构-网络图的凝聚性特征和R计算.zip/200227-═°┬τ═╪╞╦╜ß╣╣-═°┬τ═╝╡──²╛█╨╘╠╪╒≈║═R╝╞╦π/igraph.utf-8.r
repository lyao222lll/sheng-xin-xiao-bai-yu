library(igraph)

#输入数据示例，邻接矩阵
#这是一个微生物互作网络，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adjacency_unweight <- read.delim('adjacency_unweight.txt', row.names = 1, sep = '\t', check.names = FALSE)
head(adjacency_unweight)[1:6]    #邻接矩阵类型的网络文件

#邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
igraph = graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
igraph    #igraph 的邻接列表

##网络拓扑结构
#所有尺寸的团的普查可以提供一个快照，将显示各尺寸的团的数量
census <- table(sapply(cliques(igraph), length))
census
plot(census)

#k 核
cores <- graph.coreness(igraph)
cores
sna::gplot.target(adjacency_unweight, cores, usearrows = FALSE, vertex.col = cores)

#二元组（dyad）和三元组（triad）
dyad.census(simplify(igraph))
triad.census(simplify(igraph))

#节点数量（number of nodes）和边数量（number of edges）
nodes_num <- length(V(igraph))
nodes_num

edges_num <- length(E(igraph))
edges_num

#平均度（average degree）
average_degree <- mean(degree(igraph))
#或者，2x边数量/节点数量
average_degree <- 2*edges_num/nodes_num
average_degree

#平均加权度（average weighted degree），仅适用于含权网络
#average_weight_degree <- mean(strength(igraph))

#节点和边连通度（connectivity）
nodes_connectivity <- vertex.connectivity(igraph)
nodes_connectivity

edges_connectivity <- edge.connectivity(igraph)
edges_connectivity

#平均路径长度（average path length）
average_path_length <- average.path.length(igraph, directed = FALSE)
average_path_length

#网络直径（diameter）
graph_diameter <- diameter(igraph, directed = FALSE)
graph_diameter

#图密度（density）
graph_density <- graph.density(igraph)
graph_density

#聚类系数（clustering coefficient）
clustering_coefficient <- transitivity(igraph)
clustering_coefficient

#介数中心性（betweenness centralization)
betweenness_centralization <- centralization.betweenness(igraph)$centralization 
betweenness_centralization

#度中心性（degree centralization）
degree_centralization <- centralization.degree(igraph)$centralization
degree_centralization

#模块性（modularity），详见 ?cluster_fast_greedy，?modularity，有多种模型
fc <- cluster_fast_greedy(igraph)
modularity <- modularity(igraph, membership(fc))

#同配混合（assortative mixing），例如
otu_class <- read.delim('node_attribute.txt', row.names = 1, stringsAsFactors = FALSE)
V(igraph)$group <- otu_class[V(igraph)$name,'group']
assortativity.nominal(igraph, (V(igraph)$group == 'class2')+1, directed = FALSE)

#互惠性（reciprocity），仅适用于有向网络
#reciprocity(igraph, mode = 'default')
#reciprocity(igraph, mode = 'ratio')

#选择部分做个汇总输出
igraph_character <- data.frame(
    nodes_num,    #节点数量（number of nodes）
    edges_num,    #边数量（number of edges）
    average_degree,    #平均度（average degree)
    nodes_connectivity,    #节点连通度（vertex connectivity）
    edges_connectivity,    #边连通度（edges connectivity）
    average_path_length,    #平均路径长度（average path length）
    graph_diameter,    #网络直径（diameter）
    graph_density,    #图密度（density）
    clustering_coefficient,    #聚类系数（clustering coefficient）
    betweenness_centralization,    #介数中心性（betweenness centralization)
    degree_centralization,    #度中心性
    modularity    #模块性（modularity）
)
igraph_character

write.table(igraph_character, 'igraph_character.txt', sep = '\t', row.names = FALSE, quote = FALSE)

library(tidyLPA)
library(dplyr)

#数据集，详情 ?pisaUSA15
data(pisaUSA15)
head(pisaUSA15)

##LPA 分析，详情 ?estimate_profiles
#选择了部分数据演示，一是作为示例减少运行时间，二是展示这种管道符操作示例方法
#这里选择了前 100 行的观测对象，以及 3 种观测变量执行 LPA；划分 3 个潜在特征（类，class），并使用模型 1
#本示例未执行变量标准化
m3 <- pisaUSA15[1:100, ] %>%
    select(broad_interest, enjoyment, self_efficacy) %>%
    single_imputation() %>%
    #scale() %>%
    estimate_profiles(n_profiles = 3, variances = 'equal', covariances = 'zero', package = 'mclust')

##若不习惯使用管道符，以上就是这样的结构
#选择演示用的数据子集
pisaUSA15_select <- pisaUSA15[1:100,c('broad_interest', 'enjoyment', 'self_efficacy')]

#填补数据中的缺失值
pisaUSA15_select <- single_imputation(pisaUSA15_select)

#数据标准化，视实际情况而定；标准化方法可使用 scale()、poms() 等
#pisaUSA15_select <- scale(pisaUSA15_select)

#LPA 分析
m3 <- estimate_profiles(df = pisaUSA15_select, n_profiles = 3, variances = 'equal', covariances = 'zero', package = 'mclust')

##查看关键统计量
#获取参数估计
m3_est <- get_estimates(m3)
m3_est

#查看拟合统计量
m3_fit <- get_fit(m3)
m3_fit

#对象响应估计剖面的后验概率
m3_class <- get_data(m3)
m3_class

#绘制剖面图展示对象聚类
plot_profiles(m3)

##多模型比较运行，管道符操作示例
#例如分别设置 1、2、3 个潜在特征，并选择两种模型运行
#最后通过 AIC、BIC 等值，评估拟合优度，并选择最适方法
pisaUSA15[1:100, ] %>%
    select(broad_interest, enjoyment, self_efficacy) %>%
    single_imputation() %>%
    estimate_profiles(n_profiles = 1:3, variances = c('equal', 'varying'), covariances = c('zero', 'varying')) %>%
    compare_solutions(statistics = c('AIC', 'BIC'))

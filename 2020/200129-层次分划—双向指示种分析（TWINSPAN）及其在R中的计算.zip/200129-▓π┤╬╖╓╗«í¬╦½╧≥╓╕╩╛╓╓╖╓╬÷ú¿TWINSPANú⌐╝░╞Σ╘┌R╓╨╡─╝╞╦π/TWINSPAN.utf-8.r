#install twinspanR packages
#https://github.com/zdealveindy/twinspanR/blob/master/README.md
install.packages('devtools') # if you don't have it installed yet
devtools::install_github('nsj3/riojaExtra')
devtools::install_github('zdealveindy/twinspanR')

# Modified TWINSPAN on traditional Ellenberg's Danube meadow dataset,
# projected on DCA and compared with original classification into
# three vegetation types made by tabular sorting:
library(twinspanR)
library(vegan)
data(danube)
res <- twinspan(danube$spe, modif = TRUE, clusters = 4)
k <- cut(res)
 
dca <- decorana(danube$spe)
par(mfrow = c(1,2))
ordiplot(dca, type = 'n', display = 'si', main = 'Modified TWINSPAN')
points(dca, col = k)
for (i in c(1,2,4)) ordihull(dca, groups = k, show.group = i, col = i, draw = 'polygon', label = TRUE)
ordiplot(dca, type = 'n', display = 'si', main = 'Original assignment\n (Ellenberg 1954)')
points(dca, col = danube$env$veg.type)
for (i in c(1:3)) ordihull(dca, groups = danube$env$veg.type,
 show.group = unique (danube$env$veg.type)[i], col = i,
 draw = 'polygon', label = TRUE)
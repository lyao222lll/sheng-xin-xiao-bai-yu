##读取度频数分布文件
dat <- read.delim('degree.txt')

##如若没有，通过 igraph 包计算获得节点的度频数分布
library(igraph)

#输入数据示例，邻接矩阵
#这是一个微生物互作网络，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adjacency_unweight <- read.delim('adjacency_unweight.txt', row.names = 1, sep = '\t', check.names = FALSE)
head(adjacency_unweight)[1:6]    #邻接矩阵类型的网络文件

#邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
igraph <- graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
igraph    #igraph 的邻接列表

#计算节点度
V(igraph)$degree <- degree(igraph)
head(V(igraph)$degree)

#度分布统计
degree_dist <- table(V(igraph)$degree)
degree_num <- as.numeric(names(degree_dist))
degree_count <- as.numeric(degree_dist)

dat <- data.frame(degree = degree_num, count = degree_count)
head(dat)

#查看度分布
#可观察到微生物相关网络通常服从幂律分布
par(mfrow = c(1, 3))
hist(V(igraph)$degree, xlab = 'Degree', ylab = 'Frequency', 
    main = 'Degree distribution')
plot(degree_count, degree_num, xlab = 'Degree', ylab = 'Count', 
    main = 'Degree distribution')
plot(degree_count, degree_num, log = 'xy', xlab = 'Log-degree', 
    ylab = 'Log-count', main = 'Log-log degree distribution')

####幂律分布
#拟合，a 和 b 的初始值手动指定，数据不同需要多加尝试
mod <- nls(count ~ a*degree^b, data = dat, start = list(a = 2, b = 1.5))
summary(mod)

#提取关键值
a <- round(coef(mod)[1], 3)
b <- round(coef(mod)[2], 3)
a; b

#使用构建好的方程，通过预测变量拟合响应变量，再根据和观测值的差异，获得 R2
#SSre：the sum of the squares of the distances of the points from the fit
#SStot：the sum of the squares of the distances of the points from a horizontal line through the mean of all Y values
fit <- fitted(mod)
SSre <- sum((dat$count-fit)^2)
SStot <- sum((dat$count-mean(dat$count))^2)
R2 <- round(1 - SSre/SStot, 3)
R2

#p 值可以根据置换检验的原理获得
#将 count 的值分别随机置换 N 次（例如 999 次），通过随机置换数据后数据获取 R2（R2'）
#比较随机置换后值的 R2' 大于观测值的 R2 的频率，即为 p 值
p_num <- 1
dat_rand <- dat
for (i in 1:999) {
    dat_rand$count <- sample(dat_rand$count)
    SSre_rand <- sum((dat_rand$count-fit)^2)
    SStot_rand <- sum((dat_rand$count-mean(dat_rand$count))^2)
    R2_rand <- 1 - SSre_rand/SStot_rand
    if (R2_rand > R2) p_num <- p_num + 1
}
p_value <- p_num / (999+1)
p_value

#作图展示
library(ggplot2)

p <- ggplot(dat, aes(x = degree, y = count)) +
geom_point(color = 'blue') +
theme(panel.grid.major = element_line(color = 'gray'), panel.background = element_rect(color = 'black', fill = 'transparent')) +
stat_smooth(method = 'nls', formula = y ~ a*x^b, method.args = list(start = list(a = 2, b = 1.5)), se = FALSE) +
labs(x = 'Degree', y = 'Count')

#添加公式拟合的注释
label <- data.frame(
    formula = sprintf('italic(Y) == %.3f*italic(X)^%.3f', a, b),
    R2 = sprintf('italic(R^2) == %.3f', R2),
    p_value = sprintf('italic(P) < %.3f', p_value)
)

p + geom_text(x = 13, y = 210, aes(label = formula), data = label, parse = TRUE, hjust = 0) +
geom_text(x = 13, y = 190, aes(label = R2), data = label, parse = TRUE, hjust = 0) +
geom_text(x = 13, y = 170, aes(label = p_value), data = label, parse = TRUE, hjust = 0)

####一个多网络的分面图
#数据
dat2 <- read.csv('degree2.csv', stringsAsFactors = FALSE)

#构建计算函数
lm_labels <- function(dat) {
    #拟合
    mod <- nls(count ~ a*degree^b, data = dat, start = list(a = 2, b = 1.5))
    a <- round(coef(mod)[1], 3)
    b <- round(coef(mod)[2], 3)
    
    #计算R2
    fit <- fitted(mod)
    SSre <- sum((dat$count-fit)^2)
    SStot <- sum((dat$count-mean(dat$count))^2)
    R2 <- round(1 - SSre/SStot, 3)
    
    #计算 p 值（置换检验原理）
    p_num <- 1
    dat_rand <- dat
    for (i in 1:999) {
        dat_rand$count <- sample(dat_rand$count)
        SSre_rand <- sum((dat_rand$count-fit)^2)
        SStot_rand <- sum((dat_rand$count-mean(dat_rand$count))^2)
        R2_rand <- 1 - SSre_rand/SStot_rand
        if (R2_rand > R2) p_num <- p_num + 1
    }
    p_value <- p_num / (999+1)
    
    #方程式值的列表
    data.frame(formula = sprintf('italic(Y) == %.3f*italic(X)^%.3f', a, b),
        R2 = sprintf('italic(R^2) == %.3f', R2),
        p_value = sprintf('italic(P) < %.3f', p_value))
}

#计算及作图
library(plyr)
library(ggplot2)

label <- ddply(dat2, 'Type', lm_labels)

p <- ggplot(dat2, aes(x = degree, y = count, color=Type)) +
geom_point() +
facet_wrap(~Type, nrow = 1) +
stat_smooth(method = 'nls', formula = y ~ a*x^b, method.args = list(start = list(a = 2, b = 1.5)), se = FALSE, show.legend = FALSE) +
labs(x = 'Degree', y = 'Count')

p + geom_text(x = 40, y = 180, aes(label = formula), data = label, parse = TRUE, hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 40, y = 160, aes(label = R2), data = label, parse = TRUE, hjust = 0, color = 'black', show.legend = FALSE) +
geom_text(x = 40, y = 140, aes(label = p_value), data = label, parse = TRUE, hjust = 0, color = 'black', show.legend = FALSE)



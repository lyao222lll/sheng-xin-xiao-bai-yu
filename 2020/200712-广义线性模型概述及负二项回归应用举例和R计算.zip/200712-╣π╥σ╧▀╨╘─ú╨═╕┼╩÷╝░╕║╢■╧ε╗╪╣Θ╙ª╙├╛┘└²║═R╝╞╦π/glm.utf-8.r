library(mvabund)

#读取数据
worm <- read.csv('Lab_exp.csv', stringsAsFactors = FALSE)

######一元回归示例
#首先来看最简单的一元回归示例，假如关注试验条件对寄生虫丰度的独立效应

#拟合广义线性模型，详情 ?manyglm
#这里通过 family 参数指定了负二项回归，其它参数直接使用默认值
fit_glm <- manyglm(Diplo_intensity~Treatment, data = worm,  
    family = 'negative.binomial')

#基于 9999 次自举的 Wald 统计量估计 p 值，其它参数直接使用默认值
summary_fit <- summary.manyglm(fit_glm, test = 'wald', nBoot = 9999)
summary_fit

#可以通过 contrasts() 查看名义变量的编码过程
contrasts(factor(worm$Treatment))

#简单地作图查看试验条件对寄生虫丰度的关系
#感觉蜂群图比抖动点图好看
library(ggplot2)
library(ggbeeswarm)

Diplo_intensity_mean <- aggregate(worm$Diplo_intensity, by = list(worm$Treatment), FUN = mean)
names(Diplo_intensity_mean) <- c('Treatment', 'Diplo_intensity')

ggplot(worm, aes(Treatment, log2(Diplo_intensity+1), color = Treatment)) +
geom_beeswarm(cex = 1.5, alpha = 0.6) +
scale_color_manual(values = c('#4C4C4C', '#688A21', '#3F68E1', '#B02121'), 
    limits = c('Control', 'Uninfected', 'Infected LG', 'Infected HG')) +
scale_x_discrete(limits = c('Control', 'Uninfected', 'Infected LG', 'Infected HG')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black'), legend.position = 'none') +
geom_point(data = Diplo_intensity_mean, size = 3) +
stat_summary(fun.data = function(x) median_hilow(x, 0.5), 
    geom = 'errorbar', width = 0.2, size = 1) +
labs(x = '')

######多元回归示例
#原数据中，鱼类别（Fish_family）是用数字代指的，实际上需要修改为因子变量
worm$Fish_family <- as.character(worm$Fish_family)

#拟合广义线性模型，详情 ?manyglm
#这里通过 family 参数指定了负二项回归，其它参数直接使用默认值
fit_glm <- manyglm(Diplo_intensity~Treatment+Fish_family+Fish_sex+Initial_weight_g, data = worm,  
    family = 'negative.binomial')

#基于 9999 次自举的 Wald 统计量估计 p 值，其它参数直接使用默认值
summary_fit <- summary.manyglm(fit_glm, test = 'wald', nBoot = 9999)
summary_fit

######考虑交互效应
#拟合广义线性模型，详情 ?manyglm
#这里通过 family 参数指定了负二项回归，其它参数直接使用默认值
#Treatment*Plerocercoid_weight_mg 代表了考虑试验条件和寄生虫重量的交互效应
fit_glm <- manyglm(Diplo_intensity~Fish_family+Treatment*Plerocercoid_weight_mg, data = worm,  
    family = 'negative.binomial')

#基于 9999 次自举的 Wald 统计量估计 p 值，其它参数直接使用默认值
summary_fit <- summary.manyglm(fit_glm, test = 'wald', nBoot = 9999)
summary_fit

#在结果中查看变量的回归系数
#names(fit_glm)
fit_glm$coefficients

######评估模型是否是合适的
#上文 S. solidus 试验条件和 D. pseudospathaceum 丰度的一元关系
fit_glm <- manyglm(Diplo_intensity~Treatment, data = worm,  
    family = 'negative.binomial')
plot(fit_glm)

#上文 S. solidus 试验条件、三刺鱼体重、性别、类别和 D. pseudospathaceum 丰度的多元关系
fit_glm <- manyglm(Diplo_intensity~Treatment+Fish_family+Fish_sex+Initial_weight_g, data = worm,  
    family = 'negative.binomial')
plot(fit_glm)

##比较差异
#合理的模型，残差分布均匀（如上文示例，应用的是负二项回归）
mod1 <- manyglm(Diplo_intensity~Treatment+Fish_family+Fish_sex+Initial_weight_g, data = worm,  
    family = 'negative.binomial')
plot(mod1)

#如果是不合理的模型，则残差分布就不均匀（将上文示例中的模型更改为二项式回归）
mod2 <- manyglm(Diplo_intensity~Treatment+Fish_family+Fish_sex+Initial_weight_g, data = worm,  
    family = binomial())
plot(mod2)

argv <- commandArgs(T)

library(doBy)

#替换 OTU id
gg <- read.table(argv[1], sep = '\t', header = FALSE)[9:10]
otu <- read.table(argv[2], sep = '\t', header = TRUE, comment.char = '')
names(gg) <- c('otu', 'gg_id')
names(otu)[1] <- 'otu'
otu <- merge(gg, otu, by = 'otu')[-1]

#合并重复 GreenGene id
otu$gg_id <- as.character(otu$gg_id)
otu <- summaryBy(.~gg_id, data = otu, FUN = sum)
names(otu) <- gsub('[.sum]', '', names(otu))

write.table(otu, argv[3], sep = '\t', row.names = FALSE, quote = FALSE)

#R 语言操作

#读取 COG 二级分类统计
#把“cog_L2.txt”第一行的“# Constructed from biom file”删除再读取
cog <- read.delim('cog_L2.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
cog <- cog[-ncol(cog)]

#整理分类注释
cog$category <- apply(cog[1], 1, function(x) substr(x, 2, 2))
names(cog)[1] <- 'description'
cog <- reshape2::melt(cog, id = c('category', 'description'))

#合并样本分组文件
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(group)[1] <- 'variable'
cog <- merge(cog, group, by = 'variable')

#ggplot2 作图，细节就不调整了
library(ggplot2)

ggplot(cog, aes(x = category, y = value)) +
geom_boxplot(aes(color = group))

#使用 bioconda 安装 PICRUSt 环境
#参考：http://picrust.github.io/picrust/install.html#install
conda create -n picrust1 -c bioconda -c conda-forge picrust

#激活使用
source activate picrust1
#用完记得退出
source deactivate picrust1

#下载 PICRUSt 的预先计算的文件
#source activate picrust1 后才可使用
download_picrust_files.py

#加载

#安装 qiime
conda create -n qiime1 qiime
source activate qiime1
source deactivate qiime1

##OTU 序列注释
#（1）首先解压 gg_13_5_otus.tar.gz，这个是 GreenGene 数据库 13.5 版本
#（2）借助 qiime 程序实现 OTU 序列注释

#如果没安装 qiime，在 linux 中，通过 conda 安装 qiime 环境
#conda create -n qiime1 qiime
#激活使用
#source activate qiime1
#用完记得退出
#source deactivate qiime1

#qiime 的 OTU 序列注释过程
source activate qiime1
assign_taxonomy.py -i otu.fasta -r gg_13_5_otus/rep_set/97_otus.fasta -t gg_13_5_otus/taxonomy/97_otu_taxonomy.txt --uclust_max_accepts 1 -o gg97 

#根据具体的注释细节，对应 greengene id（这里用了一个手写的 R 脚本实现转换，在网盘附件中）
grep 'H' gg97/otu_tax_assignments.log > gg97/otu_tax_assignments2.log
Rscript replace_id.r gg97/otu_tax_assignments2.log otu_table.txt otu_table2.txt

#转为 biom 格式
sed -i '1i\# Constructed from biom file' otu_table2.txt
biom convert -i otu_table2.txt -o otu_table2.biom --table-type="OTU table" --to-json

##预测
#http://picrust.github.io/picrust/tutorials/metagenome_prediction.html#metagenome-prediction-tutorial
#http://picrust.github.io/picrust/picrust_precalculated_files.html#id1
source activate picrust1

#校正 16S 拷贝数
normalize_by_copy_number.py -i otu_table2.biom -o normalized_otus.biom
#转为 txt 表格
biom convert -i normalized_otus.biom -o normalized_otus.txt --to-tsv

#预测 KEGG 功能
predict_metagenomes.py -i normalized_otus.biom -o ko.biom -a nsti_ko.txt
#转为 txt 表格（分别为 KO 层级和 KO 功能描述）
biom convert -i ko.biom -o ko_pathways.txt --to-tsv --header-key KEGG_Pathways
biom convert -i ko.biom -o ko_description.txt --to-tsv --header-key KEGG_Description

#预测 COG 功能
predict_metagenomes.py -i normalized_otus.biom -o cog.biom -a nsti_cog.txt --type_of_prediction cog
#转为 txt 表格（分别为 COG 层级和 COG 功能描述）
biom convert -i cog.biom -o cog_category.txt --to-tsv --header-key COG_Category
biom convert -i cog.biom -o cog_description.txt --to-tsv --header-key COG_Description

#预测 Rfam 功能
predict_metagenomes.py -i normalized_otus.biom -o rfam.biom -a nsti_rfam.txt --type_of_prediction rfam
#转为 txt 表格
biom convert -i rfam.biom -o rfam_description.txt --to-tsv --header-key RFAM_Description


#分解 KO，比方说在 KO 第 2 级或第 3 级功能上统计
categorize_by_function.py -f -i ko.biom -c KEGG_Pathways -l 3 -o ko_L3.txt
categorize_by_function.py -f -i ko.biom -c KEGG_Pathways -l 2 -o ko_L2.txt

#分解 COG，比方说在 COG 第 2 级功能上统计
categorize_by_function.py -f -i cog.biom -c COG_Category -l 2 -o cog_L2.txt

#OTU 对功能的贡献，需指定特定 KO 功能分类 id 或 COG 功能分类 id
metagenome_contributions.py -i normalized_otus.biom -l K00001,K00002,K00004 -o ko_metagenome_contributions.txt
metagenome_contributions.py -i normalized_otus.biom -l COG0001,COG0002 -t cog -o cog_metagenome_contributions.txt

#退出
source deactivate picrust1

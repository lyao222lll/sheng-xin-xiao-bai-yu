library(igraph)

#模拟小世界网络，详情 ?watts.strogatz.game
set.seed(123)
par(mfrow = c(2, 2))

#生成具有 Nv=25 个节点，r=5 个邻居，重连概率 p=0 的网络（p 越小，聚集性越高）
g_rand <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0)
plot(g_rand, layout = layout.circle)

#更改重连概率 p=0.01
g_rand <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0.01)
plot(g_rand, layout = layout.circle)

#更改重连概率 p=0.05
g_rand <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0.05)
plot(g_rand, layout = layout.circle)

#更改重连概率 p=0.1
g_rand <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0.1)
plot(g_rand, layout = layout.circle)

##在固定节点和边数量前提下，逐步增加重连概率 p 值的模拟
#模拟网络，并计算聚类系数和平均路径长度
clustering_coefficient <- c()
average_path_length <- c()

set.seed(123)
for (p in seq(0, 1, 0.01)) {
	g_rand <- watts.strogatz.game(dim = 1, size = 100, nei = 5, p = p)
	clustering_coefficient <- c(clustering_coefficient, transitivity(g_rand))
	average_path_length <- c(average_path_length, average.path.length(g_rand, directed = FALSE))
}

dat <- data.frame(p = seq(0, 1, 0.01), 
	clustering_coefficient = clustering_coefficient, 
	average_path_length = average_path_length)

#作图展示趋势
source('two_axis.r') #ggplot2 组合坐标轴，r 代码见 https://pan.baidu.com/s/1L-G96AhiqIZ5nvGInBFQvw#list/path=%2F

p1 <- ggplot(dat, aes(log10(p), clustering_coefficient)) +
geom_smooth(color = 'blue', se = FALSE) +
theme(axis.title.y = element_text(color = 'blue'))

p2 <- ggplot(dat, aes(log10(p), average_path_length)) +
geom_smooth(color = 'red', se = FALSE) +
theme(axis.title.y = element_text(color = 'red')) +
theme(panel.background = element_rect(fill = NA))

ggplot2.two_y_axis(p1, p2)


##小世界与经典随机图的比较
set.seed(123)

#生成具有 Nv=25 个节点，r=5 个邻居，重连概率 p=0.05 的网络
g_rand_s <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0.05)

#具有相同节点和边数量的经典随机图
g_rand_ER <- erdos.renyi.game(n = vcount(g_rand_s), p = ecount(g_rand_s), type = 'gnm', mode = 'undirected')

#网络图
par(mfrow = c(1, 2))
plot(g_rand_s, layout = layout.circle)
plot(g_rand_ER, layout = layout.circle)

#聚类系数和平均路径长度比较
transitivity(g_rand_s)
average.path.length(g_rand_s, directed = FALSE)
transitivity(g_rand_ER)
average.path.length(g_rand_ER, directed = FALSE)

#提升重连概率，再比较二者
set.seed(123)

#生成具有 Nv=25 个节点，r=5 个邻居，重连概率 p=0.2 的网络
g_rand_s <- watts.strogatz.game(dim = 1, size = 25, nei = 5, p = 0.2)

#具有相同节点和边数量的经典随机图
g_rand_ER <- erdos.renyi.game(n = vcount(g_rand_s), p = ecount(g_rand_s), type = 'gnm', mode = 'undirected')

#网络图
par(mfrow = c(1, 2))
plot(g_rand_s, layout = layout.circle)
plot(g_rand_ER, layout = layout.circle)

#聚类系数和平均路径长度比较
transitivity(g_rand_s)
average.path.length(g_rand_s, directed = FALSE)
transitivity(g_rand_ER)
average.path.length(g_rand_ER, directed = FALSE)

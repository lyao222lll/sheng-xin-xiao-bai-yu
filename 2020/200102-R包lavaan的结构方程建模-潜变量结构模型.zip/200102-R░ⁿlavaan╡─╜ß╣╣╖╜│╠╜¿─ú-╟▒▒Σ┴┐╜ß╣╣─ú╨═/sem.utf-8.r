library(lavaan)

#数据集，详情 ?PoliticalDemocracy
dat <- PoliticalDemocracy
head(dat)

##验证性因子分析（CFA）
#假定潜变量
cfa_model <- '
#latent variables
ind60 =~ x1 + x2 + x3
dem60 =~ y1 + y2 + y3 + y4
dem65 =~ y5 + y6 + y7 + y8

#note that lavaan automatically includes latent covariances
#but we can add here anyway to be explicit
ind60 ~~ dem60
ind60 ~~ dem65
dem60 ~~ dem65
'

#执行 CFA，详情 ?cfa
cfa_fit <- cfa(model = cfa_model, data = dat)
summary(cfa_fit)

#模型拟合度，详情 ?fitmeasures
fitmeasures(cfa_fit, c('chisq', 'rmsea', 'cfi', 'aic'))

##结构方程模型（SEM）
#假定变量结构
sem_model <- '
#latent variables
ind60 =~ x1 + x2 + x3
dem60 =~ y1 + y2 + y3 + y4
dem65 =~ y5 + y6 + y7 + y8

#regressions
dem60 ~ ind60
dem65 ~ ind60 + dem60

#residual covariances
y1 ~~ y5
y2 ~~ y4 + y6
y3 ~~ y7
y4 ~~ y8
y6 ~~ y8
'

#执行 SEM，详情 ?sem
#这里同时包含了观测变量以及潜在变量的建模，即一个潜变量结构方程建模
#如果 model 中不存在潜在变量，仅为观测变量，则该模型即为一种普通的路径分析模型
sem_fit <- sem(model = sem_model, data = dat, se = 'bootstrap', bootstrap = 100)
summary(sem_fit, standardized = TRUE, fit.measures = TRUE, rsquare = TRUE)

#模型拟合度，详情 ?fitmeasures
fitmeasures(sem_fit, c('chisq', 'rmsea', 'cfi', 'aic'))

#路径图展示模型中的因果关系，详情 ?semPaths
#例如，连线中的数值用于反映标准化的回归系数（标准化的参数估计值）
library(semPlot)

semPaths(sem_fit, what = 'est', layout = 'tree', residuals = FALSE, 
	edge.label.cex = 1, edge.color = 'red')

#通过 MI 值评估是否需要考虑一些遗漏的变量间关系
mf <- modificationindices(sem_fit)
mf <- mf[order(mf$mi, decreasing = TRUE), ]
head(mf)

#例如将 ind60 与 y4 的关系考虑至模型中
sem_model2 <- '
#latent variables
ind60 =~ x1 + x2 + x3 + y4	#在原式中继续添加即可
dem60 =~ y1 + y2 + y3 + y4
dem65 =~ y5 + y6 + y7 + y8

#regressions
dem60 ~ ind60
dem65 ~ ind60 + dem60

#residual covariances
y1 ~~ y5
y2 ~~ y4 + y6
y3 ~~ y7
y4 ~~ y8
y6 ~~ y8
'

#执行 SEM
sem_fit2 <- sem(model = sem_model2, data = dat, se = 'bootstrap', bootstrap = 100)
summary(sem_fit2)

#拟合度评估
fitmeasures(sem_fit2)

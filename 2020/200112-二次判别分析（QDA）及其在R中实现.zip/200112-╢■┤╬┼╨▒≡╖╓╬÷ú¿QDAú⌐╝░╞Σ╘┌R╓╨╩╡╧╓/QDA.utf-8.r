library(MASS)

##数据集，详情 ?iris
data(iris)
head(iris)

#QQ-plot 检验多元正态性
qqplot(qchisq(ppoints(nrow(iris[1:4])), df = ncol(iris[1:4])), mahalanobis(iris[1:4], colMeans(iris[1:4]), cov(iris[1:4])))
abline(a = 0, b = 1)

#可选标准化数据
#本示例的 4 个变量的量纲一致（都是以 cm 为单位），且无极端值，理论上不用标准化
#但为了和前文 LDA 的结果相比较（前文数据标准化了），我选择了对它标准化
iris[1:4] <- scale(iris[1:4])

##将数据集随机分为训练集（80%）和测试集（20%）
set.seed(123)
training <- sample(rownames(iris), nrow(iris)*0.8)

train.data <- subset(iris, rownames(iris) %in% training)
test.data <- subset(iris, ! rownames(iris) %in% training)

##QDA
#使用测试集拟合模型，详情 ?qda
model <- qda(Species~., data = train.data)
model

#模型拟合精度，训练集
predictions <- predict(model, train.data)

#查看训练集对象的后验概率，即根据概率划分到高概率的类中
head(predictions$posterior)
#查看对训练集对象预测的分类
head(predictions$class)
#比较预测的分类和已知先验分类属性的差异，结果反映了准确度信息
mean(predictions$class == train.data$Species)

#模型拟合精度，测试集
predictions <- predict(model, test.data)
mean(predictions$class == test.data$Species)

#后验概率也可通过热图展示
heatmap(predictions$posterior, Colv = NA, cexRow = 0.8, cexCol = 1)

library(igraph)

##输入数据示例，邻接矩阵
#带权重的邻接矩阵
adjacency_weight <- read.delim('adjacency_weight.txt', row.names = 1, sep = '\t', check.names = FALSE)
adjacency_weight

#不带权重的邻接矩阵
adjacency_unweight <- read.delim('adjacency_unweight.txt', row.names = 1, sep = '\t', check.names = FALSE)
adjacency_unweight

##格式转换示例
#带权重邻接矩阵 -> igraph 的邻接列表，获得含权的无向网络
igraph_weight = graph_from_adjacency_matrix(as.matrix(adjacency_weight), mode = 'undirected', weighted = TRUE, diag = FALSE)
igraph_weight

is.weighted(igraph_weight)

#不带权重的邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
igraph_unweight = graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
igraph_unweight

is.weighted(igraph_unweight)

##网络图绘制
plot(igraph_weight, layout = layout.circle)
plot(igraph_unweight, layout = layout.fruchterman.reingold)

##节点和边操作，以含权网络为例
#节点操作，例如将 OTU 人为地分为两组
otu_num <- nrow(adjacency_weight)
group1 <- round(otu_num/2)
group2 <- otu_num - group1

V(igraph_weight)$color <- c(rep('purple', group1), rep('orange', group2))
plot(igraph_weight, layout = layout.circle)

#边操作，例如边权重代表了 OTU 相关性，根据相关性正负分为两组
weight <- E(igraph_weight)$weight    #查看边的权重
color <- rep('', length(weight))
color[which(weight > 0)] <- 'red'
color[which(weight < 0)] <- 'green'

E(igraph_weight)$color <- color
plot(igraph_weight, layout = layout.circle)

##输出节点属性和边列表，以含权网络为例
#节点属性列表，输出 OTU 名称，以及上述赋值的颜色
node_list <- data.frame(
    id = names(V(igraph_weight)),
    color = V(igraph_weight)$color
)
node_list

write.table(node_list, 'node_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#边列表，输出相关的 OTU 的关系，代表相关系数的边权重，以及上述赋值的颜色
edge <- data.frame(as_edgelist(igraph_weight))    #igraph 的邻接列表转为边列表

edge_list <- data.frame(
    source = edge[[1]],
    target = edge[[2]],
    weight = E(igraph_weight)$weight,
    color = E(igraph_weight)$color
)

write.table(edge_list, 'edge_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)

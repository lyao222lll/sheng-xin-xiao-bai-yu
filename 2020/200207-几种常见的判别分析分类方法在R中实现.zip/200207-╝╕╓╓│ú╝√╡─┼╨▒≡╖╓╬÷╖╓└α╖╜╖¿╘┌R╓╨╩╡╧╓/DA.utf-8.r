################################
library(MASS)

##数据集，详情 ?iris
data(iris)
head(iris)

#查看变量分布特征
library(ggplot2)

ggplot(reshape2::melt(iris, id = 'Species'), aes(x = value)) +
geom_histogram(aes(fill = Species), color = 'gray') +
facet_wrap(~variable, ncol = 2, scales = 'free')

#PCA
pca <- princomp(iris[1:4])
plot(pca$scores[ ,1], pca$scores[ ,2], col = rep(c('red', 'green', 'blue'), summary(iris$Species)))

#QQ-plot 检验多元正态性
qqplot(qchisq(ppoints(nrow(iris[1:4])), df = ncol(iris[1:4])), mahalanobis(iris[1:4], colMeans(iris[1:4]), cov(iris[1:4])))
abline(a = 0, b = 1)

#视情况选择标准化数据，如标准化为均值 0，标准差 1 的结构
iris[1:4] <- scale(iris[1:4], center = TRUE, scale = TRUE)

##将数据集随机分为训练集（80%）和测试集（20%）
set.seed(123)
training <- sample(rownames(iris), nrow(iris)*0.8)

train.data <- subset(iris, rownames(iris) %in% training)
test.data <- subset(iris, ! rownames(iris) %in% training)

##LDA
#拟合模型，详情 ?lda
model <- lda(Species~., data = train.data)
model

#作图观测对象在前两 LDA 轴中的投影
plot(model, col = rep(c('red', 'green', 'blue'), summary(train.data$Species)), dimen = 2)

ggplot(cbind(train.data, predict(model)$x), aes(LD1, LD2, color = Species)) +
geom_point() +
stat_ellipse(level = 0.95, show.legend = FALSE)


#对训练集预测分类
predictions <- predict(model, train.data)

#查看训练集对象的后验概率，即根据概率划分到高概率的类中
head(predictions$posterior)
#查看对训练集对象预测的分类
head(predictions$class)
#比较预测的分类和已知先验分类属性的差异，结果反映了准确度信息
mean(predictions$class == train.data$Species)

#对测试集预测分类
predictions <- predict(model, test.data)
mean(predictions$class == test.data$Species)

#后验概率也可通过热图展示
heatmap(predictions$posterior, Colv = NA, cexRow = 0.8, cexCol = 1)

################################
#使用测试集拟合模型，详情 ?qda
model <- qda(Species~., data = train.data)
model

#对训练集预测分类
predictions <- predict(model, train.data)
mean(predictions$class == train.data$Species)

#对测试集预测分类
predictions <- predict(model, test.data)
mean(predictions$class == test.data$Species)

################################
library(mda)

#使用测试集拟合模型，详情 ?mda
model <- mda(Species~., data = train.data, subclasses = 3)
model

plot(model)

#对训练集预测分类
predictions <- predict(model, train.data)
mean(predictions == train.data$Species)    #结果等于 1-Training Misclassification Error

#对测试集预测分类
predictions <- predict(model, test.data)
mean(predictions == test.data$Species)

################################
#使用测试集拟合模型，详情 ?fda
model <- fda(Species~., data = train.data)
model

plot(model)

#对训练集预测分类
predictions <- predict(model, train.data)
mean(predictions == train.data$Species)    #结果等于 1-Training Misclassification Error

#对测试集预测分类
predictions <- predict(model, test.data)
mean(predictions == test.data$Species)

################################
library(klaR)

#使用测试集拟合模型，详情 ?rda
model <- rda(Species~., data = train.data)
model

#对训练集预测分类
predictions <- predict(model, train.data)
mean(predictions$class == train.data$Species)

#对测试集预测分类
predictions <- predict(model, test.data)
mean(predictions$class == test.data$Species)

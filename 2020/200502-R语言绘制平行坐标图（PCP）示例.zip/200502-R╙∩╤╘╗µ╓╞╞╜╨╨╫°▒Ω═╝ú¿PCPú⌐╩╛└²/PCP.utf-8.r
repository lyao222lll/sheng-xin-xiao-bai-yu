#数据集，详情 ?iris
data(iris)
head(iris)

##MASS 包的平行坐标图
library(MASS)

#赋值组别（鸢尾花物种）颜色
iris[which(iris$Species == 'setosa'),'color'] <- '#440154'
iris[which(iris$Species == 'versicolor'),'color'] <- '#36B677'
iris[which(iris$Species == 'virginica'),'color'] <- '#FCE628'

#绘制平行坐标图，详情 ?parcoord
parcoord(iris[1:4], col = iris$color, var.label = TRUE)

##GGally 包的平行坐标图
library(GGally)

#一个简单示例，后面的函数（颜色、主题、坐标轴调整等）和 ggplot2 的用法是一致的
#详情 ?ggparcoord
ggparcoord(iris, columns = 1:4, groupColumn = 5, 
    scale = 'uniminmax',
    showPoints = TRUE, alphaLines = 0.3) + 
scale_color_manual(values = c('#440154', '#36B677', '#FCE628')) +
theme_bw()+
theme(plot.title = element_text(size = 13)) +
labs(x = '')

##plotly 包的平行坐标图
library(plotly)

#以数值指代分组 id
iris[which(iris$Species == 'setosa'),'species_id'] <- 1
iris[which(iris$Species == 'versicolor'),'species_id'] <- 2
iris[which(iris$Species == 'virginica'),'species_id'] <- 3

#绘制平行坐标图，详情 ?plot_ly
p <- plot_ly(iris, 
    type = 'parcoords', 
    line = list(color = ~species_id,
        colorscale = list(c(1, '#440154'), c(2, '#36B677'), c(3, '#FCE628'))),
    dimensions = list(
      list(range = range(iris$Sepal.Length), label = 'Sepal Length', values = ~Sepal.Length),
      list(range = range(iris$Sepal.Width), label = 'Sepal Width', values = ~Sepal.Width),
      list(range = range(iris$Petal.Length), label = 'Petal Length', values = ~Petal.Length),
	  list(range = range(iris$Petal.Width), label = 'Petal Width', values = ~Petal.Width))
)

p

#威斯康星州乳腺癌数据集
breast <- read.csv('http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data',na.strings = '?', header = FALSE)
names(breast) <- c('ID', 'clumpThickness', 'sizeUniformity', 'shapeUniformity', 'maginalAdhesion',
    'singleEpithelialCellSize', 'bareNuclei', 'blandChromatin', 'normalNucleoli', 'mitosis', 'class')

breast$class <- as.factor(breast$class)
str(breast)

#将总数据集分为训练集和测试集
set.seed(123)
select_train <- sample(699, 699*0.7)

breast_train <- breast[select_train, ]
breast_test <- breast[-select_train, ]

##支持向量机
library(e1071)

#拟合模型，详情 ?svm
#~. 是使用所有变量的简写，等同于 clumpThickness+sizeUniformity+...+normalNucleoli+mitosis
#推荐使用 scale=TRUE 将变量标准化为均值为 0、标准差为 1，有助于消除方差较大的变量对超平面识别的影响
set.seed(123)
fit.svm <- svm(class~., data = breast_train, scale = TRUE)
fit.svm

#细节部分可 names(fit.svm) 后，通过 fit.svm$XXX 等提取查看

#tune.svm() 可用于自动确定最佳的 gamma 和 cost 值，详情 ?tune.svm
set.seed(123)
tuned <- tune.svm(class~., data = breast_train, gamma = 10^(-6:1), cost = 10^(-10:10))
tuned

#使用自动确定最佳的 gamma 和 cost 值拟合支持向量机
#本示例给出 gamma=1e-4，cost=10
set.seed(123)
fit.svm <- svm(class~., data = breast_train, scale = TRUE, gamma = 1e-4, cost = 100)
fit.svm

#细节部分可 names(fit.svm) 后，通过 fit.svm$XXX 等提取查看

#训练集自身的预测
#注，支持向量机预测时不允许有缺失值出现，因此使用 na.omit() 去除数据集中的缺失值
pred_train <- predict(fit.svm, na.omit(breast_train))
svm_accuracy <- table(na.omit(breast_train)$class, pred_train, dnn = c('Actual', 'Predicted'))
svm_accuracy

#使用测试集样本进行评估
#同上，支持向量机预测时不允许有缺失值出现，因此使用 na.omit() 去除数据集中的缺失值
pred_test <- predict(fit.svm, na.omit(breast_test))
svm_accuracy <- table(na.omit(breast_test)$class, pred_test, dnn = c('Actual', 'Predicted'))
svm_accuracy

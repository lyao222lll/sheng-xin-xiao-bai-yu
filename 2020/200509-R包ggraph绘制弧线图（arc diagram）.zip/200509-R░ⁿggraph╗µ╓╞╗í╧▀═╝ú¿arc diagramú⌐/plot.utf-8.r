####突出网络中的簇以及节点间邻居关系
##igraph 包的网络操作
library(igraph)

#读取节点属性列表，合理指定节点顺序，这点很重要
#例如这里将处于同一模块内的节点聚在一起，并按节点度降序排序
nodes_list <- read.delim('1-nodes_list.txt', row.names = 1, sep = '\t', check.names = FALSE)
nodes_list <- nodes_list[order(nodes_list$modularity, nodes_list$degree, decreasing = c(FALSE, TRUE)), ]

#备注：您后续可以选择将排序过程去除，查看并对比节点排序前后弧线图/网络图的差异

#读取邻接矩阵(数值“1”表示节点之间存在边，“0”代表不存在边)
#并在邻接矩阵中分配上述预指定的节点顺序
adjacency_unweight <- read.delim('1-adjacency_unweight.txt', row.names = 1, sep = '\t', check.names = FALSE)
adjacency_unweight <- adjacency_unweight[rownames(nodes_list),rownames(nodes_list)]

#邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
#以及合并节点的模块、度等属性信息至网络中
g <- graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
V(g)$degree <- nodes_list$degree
V(g)$modularity <- as.character(nodes_list$modularity)

##ggraph 包绘制弧线图
library(ggraph)

#ggraph 中，直接指定 layout = 'linear' 将节点线性排列，就获得弧线图了
#如期望获得其它类型布局的网络图，更改 layout 参数即可，例如 layout = 'circle' 等，具体可参阅帮助文档
#ggraph 的主题调整等和 ggplot2 基本一致的，视情况修改
ggraph(g, layout = 'linear') +
geom_edge_arc(edge_width = 0.5, color = 'gray60') +  #绘制边
geom_node_point(aes(size = degree, color = modularity), alpha = 0.6) +  #绘制节点，大小表示节点度，颜色表示所属模块
geom_node_text(aes(label = name), angle = 65, hjust = 1, nudge_y = -0.5, size = 3) +  #添加节点标签
scale_size_continuous(range = c(3, 6)) +  #自定义节点尺寸范围
scale_color_manual(values = c('#536C92', '#5C466D', '#A0BD71', '#2E765B', '#D6E55E')) +  #自定义节点颜色
theme_void() +  #去除背景色
expand_limits(x = c(-1, 1), y = c(-5, 5))  #边界调整

####线性的布局利于和其它图形的组合
#以表示细菌（门水平）丰度和抗生素抗性基因（ARGs）丰度的相关性为例

##准备数据
#“2-ARGs_phylum.spearman.txt”为微生物丰度和基因丰度的 Spearman 秩相关矩阵，只包含高显著的正相关关系
#读取后，首先根据关联数量分别定义微生物和基因的顺序
spearman <- read.delim('2-ARGs_phylum.spearman.txt', row.name = 1, check.names = FALSE)

spearman1 <- spearman
spearman1[spearman1 != 0] <- 1
spearman <- spearman[names(sort(rowSums(spearman1), decreasing = TRUE)),names(sort(colSums(spearman1), decreasing = TRUE))]

#“2-phylum_table.txt” 是一个门水平的微生物丰度表
#根据“2-ARGs_phylum.spearman.txt”中的微生物提取对应的丰度
phylum <- read.delim('2-phylum_table.txt', row.name = 1, check.names = FALSE)
phylum <- phylum[ ,rownames(spearman)]

##“2-ARGs_table.txt”是一个抗生素抗性基因丰度表
#根据“2-ARGs_phylum.spearman.txt”中的基因提取对应的丰度
ARGs <- read.delim('2-ARGs_table.txt', row.name = 1, check.names = FALSE)
ARGs <- ARGs[ ,colnames(spearman)]

##构建网络
library(igraph)

#填补 0 值构建对称矩阵，获得网络邻接矩阵
#进而获得 igraph 邻接列表，权重代表了微生物丰度和基因丰度的 Spearman 秩相关系数
spearman[colnames(spearman),rownames(spearman)] <- t(spearman[rownames(spearman),colnames(spearman)])
spearman[colnames(phylum),colnames(phylum)] <- 0
spearman[colnames(ARGs),colnames(ARGs)] <- 0
spearman <- spearman[colnames(spearman),colnames(spearman)] 
g <- graph_from_adjacency_matrix(as.matrix(spearman), mode = 'undirected', weighted = TRUE, diag = FALSE)

#计算节点度，并添加节点属性
V(g)$degree <- degree(g)
V(g)[name %in% colnames(phylum)]$type <- 'bacteria phylum'
V(g)[name %in% colnames(ARGs)]$type <- colnames(ARGs)

##作图
#ggraph 包绘制弧线图表示微生物丰度和基因丰度的相关性
library(ggraph)

p1 <- ggraph(g, layout = 'linear') +
geom_edge_arc(aes(edge_width = weight, alpha = weight), color = 'red') +
geom_node_point(aes(size = degree, color = type)) +
geom_node_text(aes(label = name), angle = 65, hjust = 1, nudge_y = -0.5, size = 3) +
scale_edge_width_continuous(range = c(1, 2)) +
scale_size_continuous(range = c(3, 6)) +
scale_color_manual(values = c('#00C094', '#A58AFF', '#00B6EB', '#FB61D7', '#C49A00', '#53B400', 'gray'), 
    limits = c(colnames(ARGs), 'bacteria phylum')) +
theme_void() +
expand_limits(x = c(-1, 1), y = c(-5, 5)) +
theme(legend.position = 'none')

p1

#微生物丰度热图，使用 pheatmap 包
library(pheatmap)

p2 <- pheatmap(scale(phylum), cluster_cols = FALSE, cluster_rows = FALSE, angle_col = 45)
p2

#ARGs 基因丰度气泡图，ggplo2 作图
ARGs1 <- data.frame(scale(ARGs))
ARGs1$samples <- rownames(ARGs1)
ARGs1 <- reshape2::melt(ARGs1, id = 'samples')

ARGs1$samples <- factor(ARGs1$samples, levels = rev(rownames(ARGs)))
ARGs1$variable <- factor(ARGs1$variable, levels = colnames(ARGs))

p3 <- ggplot(ARGs1, aes(variable, samples)) +
geom_point(aes(color = variable, size = value), show.legend = FALSE) +
scale_size_continuous(range = c(1, 5)) +
scale_color_manual(values = c('#00C094', '#A58AFF', '#00B6EB', '#FB61D7', '#C49A00', '#53B400'), limits = colnames(ARGs)) +
theme_bw() +
theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
labs(x = '', y = '')

p3
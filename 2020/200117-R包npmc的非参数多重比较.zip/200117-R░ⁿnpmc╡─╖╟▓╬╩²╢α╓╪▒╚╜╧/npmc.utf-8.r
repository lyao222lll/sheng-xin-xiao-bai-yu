library(npmc)

#数据集，详情 ?brain
data(brain)
head(brain)

#Bartlett 检验显示 p 值大于 0.05，即拒绝方差齐性假设
bartlett.test(var~class, data = brain)

#Kruskal-Wallis 检验，整体差异
fit <- kruskal.test(var~class, data = brain)
fit$p.value

#npmc 的非参数多重比较
npmc_test <- npmc(brain, df = 2, alpha = 0.05)

#概要
summary(npmc_test, type = 'both', short = FALSE)
#或者
npmc_test$test

#ggplot2 箱线图
library(ggplot2)

p <- ggplot(data = brain, aes(x = class, y = var, fill = class)) +
geom_boxplot(outlier.size = 1) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), 
    legend.title = element_blank(), legend.key = element_blank(), plot.title = element_text(hjust = 0.5)) +
labs(x = '', y = '', title = 'Behrens-Fisher\n')

p + 
annotate('segment', x = 1, xend = 2, y = 50, yend = 50) +
annotate('segment', x = 1, xend = 3, y = 55, yend = 55) +
annotate('segment', x = 2, xend = 3, y = 60, yend = 60) +
annotate('text', x = 1.5, y = 52, label = 'p = 0.147') +
annotate('text', x = 2, y = 57, label = 'p = 0.754') +
annotate('text', x = 2.5, y = 62, label = 'p = 0.044')


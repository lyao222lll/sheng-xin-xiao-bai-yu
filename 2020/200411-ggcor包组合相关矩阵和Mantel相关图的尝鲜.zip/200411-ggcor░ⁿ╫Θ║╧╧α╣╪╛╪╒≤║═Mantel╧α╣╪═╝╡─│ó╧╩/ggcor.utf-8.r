#安装及加载 ggcor
#install.packages('devtools')
#devtools::install_github('houyunhuang/ggcor')
library(ggcor)

#模拟数据集，包含 A/B/C 三个观测地的物种丰度和环境测度（各 4 个观测样方）
#获取自（提取码，z574）：https://pan.baidu.com/s/1lmP-mZVFlm56Gwz0nLf8xg
spe <- read.delim('spe_table.txt', row.names = 1, sep = '\t')
env <- read.delim('env_table.txt', row.names = 1, sep = '\t')

head(spe)[1:6]
head(env)[1:6]

##统计作图
#计算物种丰度与各环境变量的 Mantel 相关，详情 ?fortify_mantel
#过程中，各样本基于物种丰度转化为 Bray-curtis 距离，基于环境变量使用欧式距离
mantel <- fortify_mantel(spe, env, mantel.fun = 'mantel.randtest',
    spec.dist.method = 'bray', env.dist.method = 'euclidean', 
    spec.select = list(A = 1:4, B = 5:8, C = 9:12))

mantel

#作图展示相关性
#包括各环境变量间的相关系数（相关矩阵）
#以及物种矩阵与环境变量间的 Mantel 相关（展示为连线）
p1 <- quickcor(env, type = 'upper') + 
geom_square() +
add_link(mantel, mapping = aes(color = p.value, size = r), diag.label = TRUE)

p1

#ggplot2 可用于进一步调整
library(ggplot2)

p1 + 
scale_fill_gradient2(midpoint = 0, low = 'blue', mid = 'white', high = 'red', space = 'Lab') +  #环境变量相关系数颜色赋值
scale_color_gradient(low = 'red', high = 'blue') +  #根据 Mantel 相关 p 值指定线条颜色
scale_size(range = c(0, 1)) +  #根据 Mantel 相关指定线条粗细
add_diag_label(angle = 45) +  #对角线显示环境变量标签
remove_axis('all')  #去除原 x、y 轴上的环境变量标签

##其他测试
##环境变量的相关矩阵用扇形图展示
p2 <- quickcor(env, type = 'upper') + 
geom_pie2() +  #还有更多样式，和 corrplot 包中的风格是一致的
add_link(mantel, mapping = aes(color = p.value, size = r), diag.label = TRUE) +
scale_fill_gradient2(midpoint = 0, low = 'blue', mid = 'white', high = 'red', space = 'Lab') +
scale_color_gradient(low = 'red', high = 'blue') +
scale_size(range = c(0, 1)) +
add_diag_label(angle = 45) +
remove_axis('all')

p2

##只保留重要的相关系数
#环境变量间的相关矩阵，仅 p<0.05 的值在图中显示数值
p3 <- quickcor(env, cor.test = TRUE, type = 'upper') +
geom_raster(data = get_data(type = 'upper', show.diag = FALSE)) +
geom_mark(data = get_data(type = 'upper', show.diag = FALSE), sep = '\n', size = 2.5, sig.thres = 0.05)

p3

#对于 Mantel 相关，同样只保留 p<0.05 的连线
p3 + add_link(mantel[-which(mantel$p.value>0.05), ], 
    mapping = aes(color = p.value, size = r), diag.label = TRUE) +
scale_fill_gradient2(midpoint = 0, low = 'blue', mid = 'white', high = 'red', space = 'Lab') +
scale_color_gradient(low = 'red', high = 'blue') +
scale_size(range = c(0, 1)) +
add_diag_label(angle = 45) +
remove_axis('all')

##对处于相关系数或 p 值范围下的数值进行调整后作图
#根据 Mantel 相关分为几个区间
mantel2 <- mutate(mantel, 
    r = cut(r, breaks = c(-Inf, 0.25, 0.5, Inf), 
	    labels = c('<0.25', '0.25-0.5', '>=0.5'), right = FALSE),
    p.value = cut(p.value, breaks = c(-Inf, 0.001, 0.01, 0.05, Inf), 
	    labels = c('<0.001', '0.001-0.01', '0.01-0.05', '>=0.05'), right = FALSE))

mantel2

#作图根据定义的区间设置连线风格，区分显著的相关系数和不显著的 Mantel 相关
p4 <- quickcor(env, cor.test = TRUE, type = 'upper') +
geom_square(data = get_data(type = 'upper', show.diag = FALSE)) +
geom_mark(data = get_data(type = 'upper', show.diag = FALSE), sep = '\n', size = 2.5, sig.thres = 0.05) +
add_link(mantel2, mapping = aes(color = p.value, size = r), diag.label = TRUE) +
scale_size_manual(values = c(0.1, 0.5, 1)) +
scale_fill_gradient2(midpoint = 0, low = 'blue', mid = 'white', high = 'red', space = 'Lab' ) +
scale_color_manual(values = c('#56B4E9', '#E69F00', '#999999')) +
add_diag_label(angle = 45) +
remove_axis('all')

p4

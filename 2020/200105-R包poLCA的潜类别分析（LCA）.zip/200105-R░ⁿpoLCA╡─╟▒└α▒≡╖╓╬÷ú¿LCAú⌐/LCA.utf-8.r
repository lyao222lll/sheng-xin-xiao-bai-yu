library(poLCA)

#数据集，详情 ?values
#调查了 216 名受访者对四个问题（A、B、C、D）的认同倾向，“1”代表不认同，“2”代表认同
#注：poLCA 中，分类变量使用 1、2、3 等数值代替，不同数值表示不同类别
data(values)
head(values)

#执行 LCA 识别数据集变量间的潜类别结构，详情 ?poLCA
#例如设置潜类别为 2
#从随机起始值开始，1000 次迭代获取参数估计值（对数似然值） 
#并运行 5 次独立的 poLCA 获得可能的全局最大值
M1 <- poLCA(formula = cbind(A, B, C, D)~1, data = values, nclass = 2, maxiter = 1000, nrep = 5, graph = TRUE)
M1

#提取主要结果，例如
summary(M1)    #对象中的各元素所记录的内容，详情 ?poLCA

M1$probs    #Conditional item response probabilities
M1$P    #Estimated class population shares

#每个变量类别在潜类别中的条件反应概率（Conditional item response probabilities）
library(reshape2)
library(ggplot2)

M1_probs <- melt(M1$probs, level = 2)

ggplot(M1_probs,aes(x = L2, y = value, fill = Var2)) +
geom_bar(stat = 'identity', position = 'stack', width = 0.5) +
facet_grid(Var1~.) +
scale_fill_brewer(type = 'seq', palette = 'Greys') +
theme_bw() +
labs(x = '', fill = 'probabilities') +
guides(fill = guide_legend(reverse = TRUE))

#后验类别概率
M1$posterior

#对象归类
M1$predclass

#作图
library(ggplot2)
library(ggrepel)

posterior <- data.frame(M1$posterior)
posterior$label <- rownames(values)
posterior$class <- as.character(M1$predclass)
names(posterior)[1:2] <- c('class1_probabilities', 'class2_probabilities')

ggplot(posterior, aes(class1_probabilities, class2_probabilities, color = class)) +
geom_point() +
geom_text_repel(aes(label = label, color = class), size = 3, show.legend = FALSE)

## Three-class model with a single covariate.
data(election)

nes2a <- poLCA(formula = cbind(MORALG, CARESG, KNOWG, LEADG, DISHONG, INTELG, MORALB, 
	CARESB, KNOWB, LEADB, DISHONB, INTELB) ~ PARTY, data = election, nclass = 3, nrep = 5)
nes2a

pidmat <- cbind(1, c(1:7))
exb <- exp(pidmat %*% nes2a$coeff)

matplot(c(1:7),(cbind(1,exb)/(1+rowSums(exb))), ylim = c(0,1), type = 'l',
	main = 'Party ID as a predictor of candidate affinity class',
	xlab = 'Party ID: strong Democratic (1) to strong Republican (7)',
	ylab = 'Probability of latent class membership',
	lwd = 2, col = 1)

text(5.9, 0.35, 'Other')
text(5.4, 0.7, 'Bush affinity')
text(1.8, 0.6, 'Gore affinity')

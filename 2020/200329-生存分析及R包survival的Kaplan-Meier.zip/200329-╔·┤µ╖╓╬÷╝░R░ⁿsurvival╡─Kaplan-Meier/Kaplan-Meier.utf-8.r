library(survival)

#示例数据，详情 ?lung
data(lung)
head(lung)

##Kaplan-Meier 分析，详情 ?survfit
KM <- survfit(Surv(time, status) ~ sex, data = lung, type = 'kaplan-meier', conf.type = 'log')
KM
summary(KM)

#结果提取，例如重要的统计值
summary(KM)$table

#对数秩检验，详情 ?survdiff
survdiff(Surv(time, status) ~ sex, data = lung)

#绘制生存曲线，反映了尚在世的患者数量比例和时间的关系
plot(KM, main = 'Kaplan-Meier ', xlab = 'Time (days)', ylab = 'Overall survival', 
    lwd = 2, col = c('blue', 'red'))

legend(x = 'topright', col = c('blue', 'red'), lwd = 2, legend = c('1: male', '2: female'))

#绘制累积风险曲线，反映了疾病风险和时间的关系，与累积的去世患者数量有关
plot(KM, main = 'Cumulative hazard', xlab = 'Time (days)', ylab = 'Cumulative hazard', 
    lwd = 2, col = c('blue', 'red'), fun = 'cumhaz')

legend(x = 'topright', col = c('blue', 'red'), lwd = 2, legend = c('1: male', '2: female'))

##survminer 包的生存曲线作图
library(survminer)

#生存曲线，详情 ?ggsurvplot
ggsurvplot(KM, conf.int = TRUE, palette = c('blue', 'red'), risk.table = TRUE, pval = TRUE)

#累积风险曲线
ggsurvplot(KM, conf.int = TRUE, palette = c('blue', 'red'), fun = 'cumhaz')

#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#查看物种丰度变量的分布
library(ggplot2)

ggplot(dat, aes(x = fish)) +
geom_histogram(bins = 30, fill = 'gray', color = 'black')

ggplot(dat, aes(x = fish, stat(density))) +
geom_histogram(bins = 30, fill = 'gray', color = 'black') +
geom_line(color = 'red', stat = 'density')

##泊松回归
#首先不妨使用全部环境变量拟合与鱼类物种丰度的多元泊松回归
#拟合广义线性模型，详情 ?glm，这里通过 family 参数指定了泊松回归
fit_poisson <- glm(fish~acre+do2+depth+no3+so4+temp, data = dat, family = 'poisson')
summary.glm(fit_poisson)  #展示拟合回归的简单统计

poisson_coef <- coef(fit_poisson)  #提取回归系数
exp(poisson_coef)  #指数化回归系数

##偏大离差
library(qcc)

qcc.overdispersion.test(dat$fish, type = 'poisson')

##准泊松回归
#使用全部环境变量拟合与鱼类物种丰度的多元准泊松回归
#拟合广义线性模型，详情 ?glm，这里通过 family 参数指定了准泊松回归
#其余参数项使用默认值，和先前的泊松回归保持相同
fit_quasipoisson <- glm(fish~acre+do2+depth+no3+so4+temp, data = dat, family = 'quasipoisson')
summary.glm(fit_quasipoisson)  #展示拟合回归的简单统计

#若和先前泊松回归结果做个比较，准泊松回归和泊松回归的唯一区别在回归系数标准误的估计值上

##模型比较
#去除不显著的 do2（水域溶解氧含量）和 so4（水域硫酸盐浓度）后
#剩余 4 种显著的环境变量与鱼类物种丰度关系的准泊松回归
fit_quasipoisson2 <- glm(fish~acre+depth+no3+temp, data = dat, family = 'quasipoisson')
summary.glm(fit_quasipoisson2)  #展示拟合回归的简单统计

#fit_quasipoisson2 中，进一步观察到 temp（水域温度）不显著
#因此进一步优化模型

#去除 do2、so4 和 temp 后
#剩余 3 种显著的环境变量与鱼类物种丰度关系的准泊松回归
fit_quasipoisson3 <- glm(fish~acre+depth+no3, data = dat, family = 'quasipoisson')
summary.glm(fit_quasipoisson3)  #展示拟合回归的简单统计

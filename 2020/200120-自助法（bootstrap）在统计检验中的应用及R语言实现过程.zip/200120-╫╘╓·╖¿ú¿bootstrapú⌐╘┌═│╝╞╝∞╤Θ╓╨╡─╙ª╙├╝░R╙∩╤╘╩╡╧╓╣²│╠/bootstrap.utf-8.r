#数据获取自 http://blog.sciencenet.cn/blog-3406804-1173120.html
dat <- read.table('data.txt', sep = '\t', row.names = 1, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)

#只包含细菌类群丰度数据，计算细菌类群之间的相关性，以 pearson 相关系数为例
dat_phylum <- dat[8:17]
dat_phylum <- scale(dat_phylum)

cor0 <- cor(dat_phylum, method = 'pearson')
cor0    #相关矩阵

#以下使用 bootstrap 的方法获取 pearson 相关系数的置信区间，用以评估观测值的相关系数是否是可信的

#对于 boot() 而言，如果只有单个统计量，函数应当返回一个数值；如果存在多个统计量，函数应该返回一个向量
#这里需要计算多变量间的相关系数，即代表了多统计量情形，因此首先创建一个能够返回相关系数向量的函数
library(reshape2)

cor_prarson <- function(data, indices) {
    cor0 <- melt(cor(data[indices, ]))
    cor0 <- cor0$value
    cor0
}

#自助抽样 1000 次，详情 ?boot
library(boot)
set.seed(123)

boot_result <- boot(data = dat_phylum, statistic = cor_prarson, R = 1000)
boot_result

#根据一开始计算的相关矩阵，获取索引
cor0 <- melt(cor0)
group <- paste(cor0$Var1, cor0$Var2, sep = '-')

#查看感兴起微生物类群间相关系数的抽样分布
plot(boot_result, index = which(group == 'Acidobacteria-Proteobacteria'))

#获取 95% 置信区间，详情 ?boot.ci
#type 参数设定获取置信区间的方法，这里展示了所有方法的区间估计结果，细节描述见帮助
boot.ci(boot_result, conf = 0.95, type = 'all', index = which(group == 'Acidobacteria-Proteobacteria'))

#对于原始数据集所观测的两类群间的 pearson 相关系数
cor0[which(cor0$Var1 == 'Acidobacteria' & cor0$Var2 == 'Proteobacteria'), ]

#上述结果表明 Acidobacteria 和 Proteobacteria 的相关性显著
#再看一个不显著的例子，Actinobacteria 和 Proteobacteria
boot.ci(boot_result, conf = 0.95, type = 'all', index = which(group == 'Latescibacteria-Proteobacteria'))
cor0[which(cor0$Var1 == 'Latescibacteria' & cor0$Var2 == 'Proteobacteria'), ]


bs =function(formula, data, indices) {
fit <- lm(formula, data= data[indices,])
return(coef(fit))
}

boot(data=mtcars, stat = bs, R=1000,formula=mpg~wt+disp)

    names(cor0) <- group
    
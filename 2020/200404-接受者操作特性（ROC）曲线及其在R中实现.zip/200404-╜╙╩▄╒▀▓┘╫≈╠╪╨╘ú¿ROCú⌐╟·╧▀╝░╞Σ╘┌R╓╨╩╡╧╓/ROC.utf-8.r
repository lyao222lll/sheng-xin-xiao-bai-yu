############### ROC 曲线的 R 包
##ROCR 包的 ROC 曲线
library(ROCR)

#示例数据，详情 ?ROCR.simple
data(ROCR.simple)
df <- data.frame(ROCR.simple)

#ROC 曲线
#详情 ?prediction、?performance
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred, 'tpr', 'fpr')
plot(perf, colorize = TRUE)
abline(0, 1)

#计算 AUC 值
perf.auc <- performance(pred, 'auc')
slot(perf.auc, 'y.values')

##pROC 包的 ROC 曲线
library(pROC)

#使用上述示例数据，计算 ROC 曲线
#详情 ?roc
pROC_obj <- roc(df$labels,df$predictions,
    smoothed = TRUE,
    #置信区间相关参数
    ci = TRUE, ci.alpha = 0.95, stratified = FALSE,
    #作图相关参数
    plot = TRUE, auc.polygon = TRUE, max.auc.polygon = TRUE, grid = TRUE,
    print.auc = TRUE, show.thres = TRUE)

sens.ci <- ci.se(pROC_obj)
plot(sens.ci, type = 'shape', col = 'yellow')
plot(sens.ci, type = 'bars', col = 'red')

##PRROC 包的 ROC 曲线
library(PRROC)

#使用上述示例数据，计算 ROC 曲线
#详情 ?roc.curve
PRROC_obj <- roc.curve(scores.class0 = df$predictions, 
    weights.class0 = df$labels, curve = TRUE)

plot(PRROC_obj)

##plotROC 包的 ROC 曲线
library(plotROC)

#使用上述示例数据，计算 ROC 曲线
#详情 ?geom_roc 等
rocplot <- ggplot(df, aes(m = predictions, d = labels)) + 
geom_roc(n.cuts = 20,labels = FALSE) +
style_roc(theme = theme_grey) + 
geom_rocci(fill = 'red')

##precrec 包的 ROC 曲线
library(precrec)

#使用上述示例数据，计算 ROC 曲线
#详情 ?evalmod、?autoplot 等
precrec_obj <- evalmod(scores = df$predictions, labels = df$labels)
autoplot(precrec_obj)

#函数evalmod()的参数选项使生成各种模型特性的基本图变得很容易
precrec_obj2 <- evalmod(scores = df$predictions, labels = df$labels, mode='basic')
autoplot(precrec_obj2)

##ROCit 包的 ROC 曲线
library(ROCit)

#使用上述示例数据，计算 ROC 曲线
#详情 ?rocit
ROCit_obj <- rocit(score = df$predictions, class = df$labels)
plot(ROCit_obj)

#显示正响应和负响应的累积密度，KS统计量显示了两条曲线之间的最大距离
ksplot(ROCit_obj)

############### 使用示例
##分类器
#加载 R 包
library(riskRegression)
library(randomForest)

#bdl 是训练集，bdt 是测试集
set.seed(123)
bdl <- sampleData(40, outcome = 'binary')
bdt <- sampleData(58, outcome = 'binary')
bdl[ ,y:=factor(Y)]
bdt[ ,y:=factor(Y)]

#基于训练集，分别使用二项式回归或随机森林构建分类器
#y 是二元响应变量，X1、X2 等是预测变量
#两者使用相同的训练集以及预测变量，以方便比较哪种方法更优
fb1 <- glm(y ~ X1+X2+X3+X4+X5+X6+X7+X8+X9+X10, data = bdl, family = 'binomial')
fb2 <- randomForest(y ~ X1+X2+X3+X4+X5+X6+X7+X8+X9+X10, data = bdl)

#预测测试集，并绘制 ROC 曲线评估两种模型性能
xb <- Score(list('glm' = fb1, 'rf' = fb2), y~1, data = bdt,
    plots = 'roc', metrics = c('auc', 'brier'))
plotROC(xb, brier.in.legend = 1L)

##使用 ROCR 包的方法获得 ROC 曲线
library(ROCR)

#预测测试集
bdt$pred1 <- predict.glm(fb1, bdt)
bdt$pred2 <- predict(fb2, bdt, type = 'prob')[ ,2]

#ROC 曲线
pred1 <- prediction(bdt$pred1, bdt$y)
pred2 <- prediction(bdt$pred2, bdt$y)
perf1 <- performance(pred1, 'tpr', 'fpr')
perf2 <- performance(pred2, 'tpr', 'fpr')

plot(perf1, col = 'blue')
plot(perf2, col = 'red', add = TRUE)
abline(0, 1)

#计算 AUC 值
perf1.auc <- performance(pred1, 'auc')
slot(perf1.auc, 'y.values')
perf2.auc <- performance(pred2, 'auc')
slot(perf2.auc, 'y.values')


##生存分析（Cox 回归）
#加载 R 包
library(riskRegression)
library(survival)

#sdl 是训练集，sdt 是测试集
set.seed(123)
sdl <- sampleData(40, outcome = 'survival')
sdt <- sampleData(58, outcome = 'survival')

#基于训练集构建 Cox 回归模型
#time 是患者生存时间，event 记录了患者是否去世，X1、X2 等是不同的预测变量
#分别使用不同的预测变量构建模型，以比较哪些变量组合更优
fs1 <- coxph(Surv(time, event) ~ X3+X5+X6+X7+X8+X10, data = sdl, x = TRUE)
fs2 <- coxph(Surv(time, event) ~ X1+X2+X9, data = sdl, x = TRUE)

#预测测试集，并绘制 ROC 曲线评估两种模型性能
xs <- Score(list(model1 = fs1, model2 = fs2), Hist(time, event)~1, data = sdt,
    times = 5, plots = 'roc', metrics = 'auc')
plotROC(xs)

#Bioconductor 安装 ropls
BiocManager::install('ropls')

#加载
library(ropls)

#数据集，详情 ?sacurine
data(sacurine)

head(sacurine$dataMatrix[ ,1:6])
head(sacurine$sampleMetadata)
head(sacurine$variableMetadata)

#PCA，详情 ?opls
sacurine.pca <- opls(x = sacurine$dataMatrix)
sacurine.pca

#opls() 返回结果是 S4 对象结构，可通过 @ 在其中提取所需结果
names(attributes(sacurine.pca))    #查看包含信息

head(sacurine.pca@scoreMN)    #例如，提取对象得分（各样本在 PCA 轴中的排序坐标）
head(sacurine.pca@loadingMN)    #例如，提取变量得分（各代谢物在 PCA 轴中的排序坐标）

#如在排序图中根据个体属性（性别、年龄等）给样本上色
par(mfrow = c(1, 2))
plot(sacurine.pca, typeVc = 'x-score', parAsColFcVn = sacurine$sampleMetadata[, 'gender'])
plot(sacurine.pca, typeVc = 'x-score', parAsColFcVn = sacurine$sampleMetadata[, 'age'])

#也可根据提取坐标自定义作图展示，如 ggplot2，展示前两轴的样本分布，并按个体性别着色
library(ggplot2)

scoreMN <- sacurine.pca@scoreMN
scoreMN <- cbind(scoreMN, sacurine$sampleMetadata)
scoreMN$samples <- rownames(scoreMN)

ggplot(scoreMN, aes(p1, p2, color = gender)) +
geom_point() +
stat_ellipse(show.legend = FALSE)

#PLS-DA，详情 ?opls
#监督分组以性别为例，orthoI = 0 时执行 PLS-DA
sacurine.plsda <- opls(x = sacurine$dataMatrix, y = sacurine$sampleMetadata[, 'gender'], orthoI = 0)
sacurine.plsda

#opls() 返回对象的提取方法和上文 PCA 一致
names(attributes(sacurine.plsda))    #查看包含信息
head(sacurine.plsda@scoreMN)    #例如，样本在 PLS-DA 轴上的位置
head(sacurine.plsda@loadingMN)    #例如，代谢物在 PLS-DA 轴上的位置

#默认 plot() 作图，如查看样本差异以及帮助寻找重要的代谢物
par(mfrow = c(1, 2))
plot(sacurine.plsda, typeVc = 'x-score', parAsColFcVn = sacurine$sampleMetadata[, 'gender'])
plot(sacurine.plsda, typeVc = 'x-loading')

#其它可视化方法，提取坐标后自定义作图（如 ggplot2 等），不再多说

#VIP 值帮助寻找重要的代谢物
vipVn <- getVipVn(sacurine.plsda)
vipVn_select <- vipVn[vipVn > 1]    #这里也通过 VIP>1 筛选下
head(vipVn_select)

vipVn_select <- cbind(sacurine$variableMetadata[names(vipVn_select), ], vipVn_select)
names(vipVn_select)[4] <- 'VIP'
vipVn_select <- vipVn_select[order(vipVn_select$VIP, decreasing = TRUE), ]
head(vipVn_select)    #带注释的代谢物，VIP>1 筛选后，并按 VIP 降序排序

#带模型预测性能评估的执行命令
#如下示例，奇数行的数据用于构建 PLS-DA，偶数行的数据测试 PLS-DA
#此外还可以自定义截取数据子集构建训练集或测试集等
sacurine.plsda <- opls(x = sacurine$dataMatrix, y = sacurine$sampleMetadata[, 'gender'], orthoI = 0, subset = 'odd')
sacurine.plsda

#检查关于训练子集的预测
trainVi <- getSubsetVi(sacurine.plsda)
table(sacurine$sampleMetadata[, 'gender'][trainVi], fitted(sacurine.plsda))

#计算测试子集的性能
table(sacurine$sampleMetadata[, 'gender'][-trainVi], predict(sacurine.plsda, sacurine$dataMatrix[-trainVi, ]))

#OPLS-DA，详情 ?opls
#监督分组以性别为例，orthoI = NA 时执行 OPLS-DA
sacurine.oplsda <- opls(x = sacurine$dataMatrix, y = sacurine$sampleMetadata[, 'gender'], predI = 1, orthoI = NA)
sacurine.oplsda


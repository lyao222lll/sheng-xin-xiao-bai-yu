#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#首先使用全部环境变量拟合与鱼类物种丰度的多元线性回归
fit1 <- lm(fish~acre+do2+depth+no3+so4+temp, data = dat)
summary(fit1)  #展示拟合方程的简单统计

#只考虑使用 3 个和鱼类物种丰度线性关系较为明显的环境变量拟合多元线性回归
#这里将处于线性关系临界值的 depth 也算在内
fit2 <- lm(fish~acre+no3, data = dat)
summary(fit2)  #展示拟合方程的简单统计

#anova() 检验前后两个嵌套模型的拟合优度
#比较去除 3 个不显著的预测变量后，回归整体预测性能是否一样好
anova(fit2, fit1)

#AIC 评估前后两个回归复杂性与拟合优度的关系
#AIC 值较小的回归优先选择，表明较少的预测变量已经获得了足够的拟合度
AIC(fit2, fit1)

##逐步选择
library(MASS)

#前向选择
#首先构建了一个只包含 1 个非常显著的预测变量的起始回归模型
fit0 <- lm(fish~acre, data = dat)
#如果使用不含任何预测变量的空模型
#fit0 <- lm(fish~1, data = dat)
#随后应用前向选择逐步往里添加新的预测变量，直到模型最优或达到指定的最大变量数量
stepAIC(fit0, direction = 'forward', 
    scope = list(lower = fit0, upper = ~acre+do2+depth+no3+so4+temp))

#后向选择
#首先使用全部环境变量拟合与鱼类物种丰度的多元线性回归，作为起始回归模型
fit1 <- lm(fish~acre+do2+depth+no3+so4+temp, data = dat)
#随后应用后向选择逐步在模型中删减预测变量，直到模型最优
stepAIC(fit1, direction = 'backward')

#双向选择
#首先构建了一个只包含 1 个非常显著的预测变量的起始回归模型
fit0 <- lm(fish~acre, data = dat)
#如果使用不含任何预测变量的空模型
#fit0 <- lm(fish~1, data = dat)
#随后执行双向选择，逐步往里添加新的有效预测变量，并考虑删除已存在的无效预测变量，直到模型最优或达到指定的最大变量数量
stepAIC(fit0, direction = 'both', 
    scope = list(lower = fit0, upper = ~acre+do2+depth+no3+so4+temp))

##全子集回归
library(leaps)

#全子集回归评估最佳的 N 变量组合
leap <- regsubsets(fish~acre+do2+depth+no3+so4+temp, data = dat, nbest = 2)
plot(leap, scale = 'adjr2')  #以校正后 R2 代表模型精度

#辅助选择预测变量组合
library(car)

subsets(leap, statistic = 'cp')
abline(1,1,lty = 2,col = 'red')

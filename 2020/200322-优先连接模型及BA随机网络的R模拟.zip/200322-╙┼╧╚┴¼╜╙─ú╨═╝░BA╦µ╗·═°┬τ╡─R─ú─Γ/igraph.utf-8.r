library(igraph)

##模拟 BA 随机网络，详情 ?barabasi.game
set.seed(123)
g_rand_BA <- barabasi.game(n = 100, m = 1, directed = FALSE)

#节点和边数量
vcount(g_rand_BA)
ecount(g_rand_BA) 

#网络图
par(mfrow = c(1, 2))
plot(g_rand_BA, layout = layout.circle)

#度分布
hist(degree(g_rand_BA))

##模拟 ER 随机网络，详情 ?erdos.renyi.game
set.seed(123)
g_rand_ER <- erdos.renyi.game(n = vcount(g_rand_BA), p = ecount(g_rand_BA) , type = 'gnm', weight = FALSE, mode = 'undirected')

#节点和边数量
vcount(g_rand_ER)
ecount(g_rand_ER) 

#网络图
par(mfrow = c(1, 2))
plot(g_rand_ER, layout = layout.circle)

#度分布
hist(degree(g_rand_ER))

##聚类系数和平均路径长度比较
transitivity(g_rand_BA)
average.path.length(g_rand_BA, directed = FALSE)

transitivity(g_rand_ER)
average.path.length(g_rand_ER, directed = FALSE)

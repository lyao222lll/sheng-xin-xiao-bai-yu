##环境变量间的共线性评估
#读取地理坐标和环境组成数据
site_env <- read.delim('site_env.txt', sep = '\t', row.names = 1, check.names = FALSE)

#除了经纬度外，其它均定义为环境因素
env <- site_env[c('Depth', 'Temperature', 'Salinity', 'Chlorophyll_a')]

#评估环境变量间的多重共线性
#Hmisc 包 varclus() 的方法，计算变量间的 spearman 相关性进行评估
library(Hmisc)

env_varclus <- varclus(as.matrix(env), imilarity = 'spearman', method = 'complete')
plot(env_varclus)

##计算距离
#读取浮游细菌群落物种组成数据
spe <- read.delim('FL.otu_table.txt', sep = '\t', row.names = 1, check.names = FALSE)
spe <- data.frame(t(spe))

#vegan 包 vegdist() 计算群落间物种组成的 Bray-curtis 相异度
#并通过 1-Bray-curtis 转换为相似度后，再通过 ln 转化
library(vegan)

comm_dis <- vegdist(spe, method = 'bray')
comm_sim <- log(1 - comm_dis, exp(1))

#地理坐标和环境组成数据已经在上文读取进来了，继续执行

#geosphere 包 distm() 根据经纬度计算采样点间的地理距离
#默认距离单位是米，除以 1000 可转换为千米单位，并再通过 ln(x+1) 转化
library(geosphere)

site_dis <- distm(site_env[c('Lon', 'Lat')]) / 1000  #distm() 要求两列数据，第一列是经度，第二列是纬度
site_dis <- log(site_dis+1, exp(1))
rownames(site_dis) <- rownames(site_env)
colnames(site_dis) <- rownames(site_env)
site_dis <- as.dist(site_dis)

#对于各环境变量，均计算为欧氏距离测度
depth_dis <- vegdist(site_env['Depth'], method = 'euclidean')  #深度
temperature_dis <- vegdist(site_env['Temperature'], method = 'euclidean')  #温度
salinity_dis <- vegdist(site_env['Salinity'], method = 'euclidean')  #盐度

#由于使用地理或环境的距离测度作为自变量拟合多元线性回归
#如果期望后续能够通过回归系数比较各自变量的相对重要性，需要统一对它们进行标准化处理
#MuMIn 包 stdize() 可以实现对地理或环境距离测度的标准化功能，参考自：https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4961435/
library(MuMIn)

site_dis <- stdize(site_dis)
depth_dis <- stdize(depth_dis)
temperature_dis <- stdize(temperature_dis)
salinity_dis <- stdize(salinity_dis)

##MRM 分析
library(ecodist)

#详情 ?MRM，以下基于 9999 次置换估计 p 值

#综合多个自变量矩阵的多元线性回归，在多元回归中，各自变量的回归系数即“偏回归系数”
#“偏回归系数”的含义，对于某个自变量而言，当控制其它自变量保持恒定时，该自变量对响应变量的相对效应
fit_MRM <- MRM(comm_sim~site_dis+depth_dis+temperature_dis+salinity_dis, 
    nperm = 10000, method = 'linear')
fit_MRM

#如果希望获得各个自变量独立的回归系数，则单独执行各自变量与响应变量的一元回归即可
#例如考虑地理距离对群落组成相似度独立的效应
fit_MRM_site <- MRM(comm_sim~site_dis, nperm = 10000, method = 'linear')
fit_MRM_site

#根据重要性排名，水深>盐度>地理距离>温度
#手动组建一个前向逐步回归，评估重要环境或地理因素对群落组成相似度的累积解释率
fit_MRM1 <- MRM(comm_sim~depth_dis, nperm = 10000, method = 'linear')
fit_MRM2 <- MRM(comm_sim~depth_dis+salinity_dis, nperm = 10000, method = 'linear')
fit_MRM3 <- MRM(comm_sim~depth_dis+salinity_dis+site_dis, nperm = 10000, method = 'linear')
fit_MRM4 <- MRM(comm_sim~depth_dis+salinity_dis+site_dis+temperature_dis, nperm = 10000, method = 'linear')

fit_MRM1$r.squared  #水深的贡献
fit_MRM2$r.squared  #水深和盐度的综合贡献
fit_MRM3$r.squared  #水深、盐度和地理距离的综合贡献
fit_MRM4$r.squared  #水深、盐度、地理距离和温度的综合贡献

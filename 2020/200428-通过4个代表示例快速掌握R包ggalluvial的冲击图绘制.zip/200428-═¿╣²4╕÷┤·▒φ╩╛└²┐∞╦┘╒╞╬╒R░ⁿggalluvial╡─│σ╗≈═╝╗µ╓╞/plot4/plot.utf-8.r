####描述部分对应或跨类别关系
##例如展示基因组共线性分析

#读取已经提前准备好的共线性分析的数据
#表格中，已经按参考基因组的染色体碱基位置作了排序
mummer <- read.delim('mummer.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)[1:6]
mummer$contig <- factor(mummer$contig, levels = unique(mummer$contig))
mummer$chr <- factor(mummer$chr, levels = unique(mummer$chr))

#冲击图
library(ggalluvial)

p <- ggplot(mummer, aes(y = length, axis1 = chr, axis2 = contig)) +
geom_flow(aes(fill = strand)) +  #连线展示共线性区域，颜色代表序列对应的方向
scale_fill_manual(values = c('blue', 'red')) +  #红色代表正向比对，蓝色代表反向比对
geom_stratum(fill = c(rep('orange', length(levels(mummer$chr))), rep('lightblue', length(levels(mummer$contig)))), 
    width = 0.3, size = 2, color = 'white') +  #一列为参考基因组染色体序列，另一列为组装基因组 contigs 序列
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #染色体或 contigs 名称
coord_flip() +  #横向展示该图，下方参数为背景等主题调整
theme(legend.position = 'none', panel.background = element_blank(), 
    line = element_blank(), text = element_blank()) 

p

#输出图片至本地
ggsave('test.pdf', p, width = 10, height = 5)
#ggsave('test.png', p, width = 10, height = 5)
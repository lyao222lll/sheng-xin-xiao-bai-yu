####描述不同类别变量间的包含关系
##展示样本和物种丰度的对应关系，以及样本分组和物种分类

#读取数据，在给定的示例数据中，我已经提前按照总丰度水平、样本类型等作了排序
#并在读取后将指定列转化为因子类型，即指定了预先定义顺序，便于后续作图展示
otu <- read.delim('otu_table.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu$OTU <- factor(otu$OTU, levels = unique(otu$OTU))

tax <- read.delim('taxonomy.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
tax$Phylum <- factor(tax$Phylum, levels = unique(tax$Phylum))

group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
group$Sample <- factor(group$Sample, levels = unique(group$Sample))
group$Group <- factor(group$Group, levels = unique(group$Group))

#合并 OTU 丰度、OTU 门水平分类、样本分组
otu <- reshape::melt(otu, id = 'OTU')
otu <- merge(otu, tax, by = 'OTU')
names(otu)[2] <- 'Sample'
otu <- merge(otu, group, by = 'Sample')

#整理成 ggplot2 作图格式，以便于 ggalluvial 绘制冲击图
otu <- reshape::melt(otu, id = 'value')
names(otu) <- c('value', 'type', 'detail')
type <- summary(otu$type)
otu$flow <- rep(1:type[1], length(type))

#预指定 OTU、门分类、样本、分组的颜色
color_otu <- c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', 
    '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8', 
    '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33', '#A65628', '#F781BF', '#66C2A5')
color_sample <- c('#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#049a0b')
color_phylum <- c('#BEAED4', '#FDC086', '#FFFF99', '#386CB0', '#F0027F')
color_group <- c('#4253ff', '#ff4308')

#冲击图
library(ggalluvial)

p <- ggplot(otu, aes(x = type, y = value,
    stratum = detail, alluvium = flow, fill = detail)) +
geom_stratum() +  #类似堆叠柱形图
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #在各个区块中添加文字标签
geom_flow() +  #绘制同类别之间的连接线
scale_fill_manual(values = c(color_sample, color_otu, color_phylum, color_group)) +  #颜色赋值
scale_x_discrete(limits = c('Phylum', 'OTU', 'Sample', 'Group')) +  #定义簇（列）的展示顺序
scale_y_continuous(expand = c(0, 0)) +
labs(x = '', y = 'Abundance') +  #从这儿开始是一些主题参数等的设置
theme(legend.position = 'none', axis.line = element_line(), 
    panel.background = element_blank())

p

#输出图片至本地
ggsave('test.pdf', p, width = 10, height = 5)
#ggsave('test.png', p, width = 10, height = 5)


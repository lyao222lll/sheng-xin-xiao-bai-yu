####描述同类型变量的趋势变化
##以物种堆叠冲击图为例

#读取门水平丰度数据
dat <- read.delim('phylum_top10.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#该丰度表中，已经提前按总丰度水平的高低作了降序排序
#现在将分类列转化为因子类型，即指定了预先定义的类群展示顺序
dat$Taxonomy <- factor(dat$Taxonomy, levels = rev(dat$Taxonomy))

#整理成 ggplot2 作图格式
dat <- reshape::melt(dat, id = 'Taxonomy')

#添加分组，根据样本分组绘制分面
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE)
names(group)[1] <- 'variable'
dat <- merge(dat, group, by = 'variable')

#绘制带分面的柱状图
library(ggplot2)

color <- c('gray', '#CCEBC5', '#BC80BD', '#FCCDE5', '#B3DE69', '#FDB462', 
    '#80B1D3', '#FB8072', '#BEBADA', '#FFFFB3', '#8DD3C7')

p <- ggplot(dat, aes(x = times, y = 100 * value, fill = Taxonomy)) +
geom_col(position = 'stack', width = 0.6) +  #堆叠柱形图
facet_wrap(~group, scales = 'free_x', ncol = 2) +  #分面图
scale_fill_manual(values = color) +  #填充颜色赋值
labs(x = '', y = 'Relative Abundance(%)')

p

#修改为带分面的冲击图
library(ggalluvial)

p <- ggplot(dat, aes(x = times, y = 100 * value, fill = Taxonomy, 
    stratum = Taxonomy, alluvium = Taxonomy)) +
geom_stratum() +  #代替 geom_col() 绘制堆叠柱形图
geom_flow(alpha = 0.5) +  #绘制同类别之间的连接线
facet_wrap(~group, scales = 'free_x', ncol = 2) +  #分面图
scale_fill_manual(values = color) +
labs(x = '', y = 'Relative Abundance(%)')

p

#继续修改主题，如背景色、网格线、图例、字体等
#和 ggplot2 的使用一样的
p <- p + theme(panel.grid = element_blank(), strip.text = element_text(size = 12), 
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
theme(axis.text = element_text(size = 12), axis.title = element_text(size = 13), 
    legend.title = element_blank(), legend.text = element_text(size = 11))

p

#输出图片至本地
ggsave('test.pdf', p, width = 10, height = 5)
#ggsave('test.png', p, width = 10, height = 5)

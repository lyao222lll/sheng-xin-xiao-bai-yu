####描述靶向或上下游关系
##例如将一个 ceRNA 网络图以冲击图展示

#读取数据，两个靶向关系表
circ_mi <- read.delim('circRNA_miRNA.txt', sep = '\t', stringsAsFactors = FALSE)
mi_m <- read.delim('miRNA_mRNA.txt', sep = '\t', stringsAsFactors = FALSE)

#整合靶向关系，合并为 3 列的表
circ_mi_m <- merge(circ_mi, mi_m, by = 'miRNA')

#预指定颜色
color_circRNA <- '#8DD3C7'
color_miRNA <- c('#A65628', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', 
    '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', '#FFED6F', '#E41A1C', '#377EB8', 
    '#4DAF4A', '#984EA3', '#FF7F00', '#FFFF33')
color_mRNA <- c('#6181BD', '#F34800', '#64A10E', '#FF00FF', '#c7475b', '#66C2A5', 
    '#BEAED4', '#FDC086', '#FFFF99', '#386CB0', '#F0027F')

#冲击图
library(ggalluvial)

p <- ggplot(circ_mi_m, aes(axis1 = circRNA, axis2 = miRNA, axis3 = mRNA)) +
geom_flow(aes(fill = miRNA)) +  #在这里，将所有连线的颜色按 miRNA 赋值，代表 miRNA 介导的关系
scale_fill_manual(values = rev(color_miRNA)) +
geom_stratum(fill = c(color_circRNA, color_miRNA, color_mRNA)) +  #类似堆叠柱形图
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #在各个区块中添加文字标签
scale_x_discrete(limits = c('circRNA', 'miRNA', 'mRNA')) +
labs(x = '', y = '') +  #从这儿开始是一些主题参数等的设置
theme(legend.position = 'none', panel.background = element_blank(), 
    line = element_blank(), text = element_blank())

p

#输出图片至本地
ggsave('test.pdf', p, width = 10, height = 5)
#ggsave('test.png', p, width = 10, height = 5)

#####
##另一种画法

#重新融合表格，并定义方格区块高度数值，以及连接流
circ_mi_m$link <- 1
circ_mi_m <- reshape::melt(circ_mi_m, id = 'link')

variable <- summary(circ_mi_m$variable)
circ_mi_m$flow <- rep(1:variable[1], length(variable))

link <- 1 / summary(circ_mi_m$value)
for (i in names(link)) circ_mi_m[which(circ_mi_m$value == i),'link'] <- link[i]

#冲击图
p <- ggplot(circ_mi_m, aes(x = variable, y = link,
    stratum = value, alluvium = flow, fill = value)) +
geom_stratum() +  #类似堆叠柱形图
geom_text(stat = 'stratum', infer.label = TRUE, size = 2.5) +  #在各个区块中添加文字标签
geom_flow(aes.flow = 'backward') +  #这次，连线颜色就不用 miRNA 赋值了，将 mRNA 也加进来，看一下效果
scale_fill_manual(values = c(color_miRNA, color_circRNA, color_mRNA)) +  #颜色赋值
scale_x_discrete(limits = c('circRNA', 'miRNA', 'mRNA')) +  #定义簇（列）的展示顺序
labs(x = '', y = '') +  #从这儿开始是一些主题参数等的设置
theme(legend.position = 'none', panel.background = element_blank(), 
    line = element_blank(), text = element_blank())

p

#输出图片至本地
ggsave('test.pdf', p, width = 10, height = 5)
#ggsave('test.png', p, width = 10, height = 5)
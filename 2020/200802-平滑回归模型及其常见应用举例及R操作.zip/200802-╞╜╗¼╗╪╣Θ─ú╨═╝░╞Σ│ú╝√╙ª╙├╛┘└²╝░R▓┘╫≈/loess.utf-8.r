###通过平滑确定线性回归
#读取数据
dat1 <- read.delim('comm_dis.depth40.North.txt', sep = '\t')

#平滑拟合，详情 ?loess
#参数 span 可控制平滑度，值越大拟合曲线越平滑
#默认使用最小二乘回归法进行局部拟合，如要更改，可通过参数 family 指定
fit1 <- loess(comm_sim~site_dis, data = dat1, span = 0.75)
summary(fit1)  #展示平滑回归的一些细节

#使用 ggplot2 对平滑拟合简单作图，并展示 95% 置信区间
library(ggplot2)

p1 <- ggplot(dat1, aes(site_dis, comm_sim)) +
geom_point() +
stat_smooth(method = 'loess', formula = y~x, span = 0.75, se = TRUE, level = 0.95, 
    color = 'blue', fill = 'blue') +
ylim(0, 1)

p1

#添加线性回归线，并展示 95% 置信区间
p1 + stat_smooth(method = 'lm', formula = y~x, se = TRUE, level = 0.95, 
    color = 'red', fill = 'red')

fit1_lm <- lm(comm_sim~site_dis, data = dat1)
summary(fit1_lm)  #线性回归统计概要

###通过平滑确定分段线性回归
#读取数据
dat2 <- read.delim('Arkansas.txt', sep = '\t')

#平滑拟合，详情 ?loess
#参数 span 可控制平滑度，值越大拟合曲线越平滑
#默认使用最小二乘回归法进行局部拟合，如要更改，可通过参数 family 指定
fit2 <- loess(sqrt.mayflies~year, data = dat2, span = 0.75)
summary(fit2)  #展示平滑回归的一些细节

#使用 ggplot2 对平滑拟合简单作图，并展示 95% 置信区间
library(ggplot2)

p2 <- ggplot(dat2, aes(year, sqrt.mayflies)) +
geom_point() +
stat_smooth(method = 'loess', formula = y~x, span = 0.75, se = TRUE, level = 0.95, 
    color = 'blue', fill = 'blue')

p2

##分段线性回归
#先拟合一个简单的线性回归模型
fit2_lm <- lm(sqrt.mayflies~year, data = dat2)
summary(fit2_lm)

#segmented 包的分段线性回归，详情 ?segmented
library(segmented)

#可通过参数 npsi 指定断点数量，该示例为 1，将自动寻找可能的断点位置
lm_seg1 <- segmented(fit2_lm, seg.Z = ~year, npsi = 1)
summary(lm_seg1)

plot(lm_seg1, xlab = 'year', ylab = 'sqrt.mayflies', col = 'red')
points(sqrt.mayflies~year, data = dat2)
lines(dat2$year, fitted(fit2), col = 'blue')

#或者通过参数 psi 指定断点的大致位置，该示例为 x=1997，将自动在 x=1997 附近寻找最佳的断点位置
lm_seg2 <- segmented(fit2_lm, seg.Z = ~year, psi = 1997) 
summary(lm_seg2)

plot(lm_seg2, xlab = 'year', ylab = 'sqrt.mayflies', col = 'red')
points(sqrt.mayflies~year, data = dat2)
lines(dat2$year, fitted(fit2), col = 'blue')

#特别注意：
#segmented() 的两种方法得到的断点位置或参数估计值等可能不同
#不同 R 包的分段回归函数之间，得到的断点位置或参数估计值等也可能不同

###通过平滑反映地理和环境梯度
#读取数据
dat3 <- read.delim('site.txt', sep = '\t')
names(dat3) <- c('site', 'Lon', 'Lat', 'Depth', 'Temperature', 'Salinity')

#使用 R 包 mgcv 中的 gam() 拟合加性模型
library(mgcv)

#详情 ?gam
#温度随经纬度变化的二维平滑器
fit3_temp <- gam(Temperature~s(Lon, Lat, k = 10), data = dat3)
summary(fit3_temp)

#盐度随经纬度变化的二维平滑器
fit3_salt <- gam(Salinity~s(Lon, Lat, k = 10), data = dat3)
summary(fit3_salt)

#作图，详情 ?vis.gam
par(mfrow = c(2, 2))

vis.gam(fit3_temp, color = 'topo', plot.type = 'contour')
points(dat3$Lon, dat3$Lat, pch = 16)
vis.gam(fit3_salt, color = 'terrain', plot.type = 'contour')
points(dat3$Lon, dat3$Lat, pch = 16)
vis.gam(fit3_temp, color = 'topo', theta = 30)
vis.gam(fit3_salt, color = 'terrain', theta = 30)

###和排序图结合，展示群落异质性和环境的关系
#读取数据，注意 3 个文件中样本顺序要一致，便于后续合并处理
otu <- read.delim('otu_table.txt', sep = '\t', row.names = 1)  #物种丰度
env <- read.delim('env_table.txt', sep = '\t', row.names = 1)  #环境组成
group <- read.delim('group.txt', sep = '\t', row.names = 1)  #样本分组

#物种丰度的非约束排序
#使用 vegan 包执行，计算群落间 Bray-Curtis 相异度，并执行 NMDS 排序
library(vegan)

nmds <- metaMDS(otu, distance = 'bray', k = 2)
ordiplot(nmds, display = 'sites', type = 'none')
points(nmds, pch = 19, cex = 0.7, col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)))

#继续使用 ordisurf() 将环境变量以非线性曲面的形式投影至排序空间中，可借此探索排序样本沿环境变量的梯度分布
#以环境变量 DOC 为例
gam_doc <- ordisurf(nmds, env[, 'DOC'], add = TRUE, col = 'blue')
gam_doc

##使用加性模型 gam() 手动重现一下该过程
#提取群落排序的前两轴坐标
nmds_site <- data.frame(nmds$points)

#合并各样本群落的 NMDS 坐标与环境组成数据
nmds_site_env <- cbind(nmds_site, env)

#通过 gam() 拟合 NMDS 坐标与环境变量 DOC 的二维平滑器，详情 ?gam
fit4_doc <- gam(DOC~s(MDS1, MDS2, k = 12), data = nmds_site_env)
summary(fit4_doc)

#作图，详情 ?vis.gam
vis.gam(fit4_doc, color = 'bw', plot.type = 'contour')
points(nmds_site_env$MDS1, nmds_site_env$MDS2, pch = 16, 
    col = c(rep('red', 9), rep('orange', 9), rep('green3', 9)))

vis.gam(fit4_doc, color = 'bw', theta = 30)

##ggplot2 的二维平滑器
#参考自：http://userweb.eng.gla.ac.uk/umer.ijaz/bioinformatics/ecological.html
library(ggplot2)
library(metR)
library(ggrepel)

#在上述 vegan 包计算的 NMDS 基础上继续
ordi <- ordisurf(nmds, env$DOC, plot = FALSE, bs = 'ds')
ordi.grid <- ordi$grid
ordi.mite <- expand.grid(x = ordi.grid$x, y = ordi.grid$y)
ordi.mite$z <- as.vector(ordi.grid$z)
ordi.mite.na <- data.frame(na.omit(ordi.mite))

#标记 NMDS 中样本的分组信息
NMDS <- data.frame(x = nmds$point[ ,1], y = nmds$point[ ,2], Type = group[ ,1])
NMDS$name <- rownames(NMDS)

#作图
ggplot()+
stat_contour(data = ordi.mite.na, aes(x, y, z = z, color = ..level..)) +
geom_text_contour(data = ordi.mite.na, aes(x, y, z = z, color = ..level..), size = 2.5) +
scale_colour_continuous(high = '#132B44', low = '#56B1F7') +
geom_point(data = NMDS, aes(x, y, fill = Type), color = 'transparent', pch = 21, size = 1.5) +
scale_fill_manual(values = c('red', 'orange', 'green3')) +
labs(x = 'NMDS1', y = 'NMDS2', color = 'DOC') +
theme(panel.grid = element_blank(), legend.key = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
geom_text_repel(data = NMDS, aes(x, y, label = name), show.legend = FALSE, size = 2.5)

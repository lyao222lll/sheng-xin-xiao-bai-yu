#这是一个来自微生物共发生网络的统计结果
#通常，微生物共发生网络的节点度分布服从幂律分布

#读取网络节点度的频数分布文件
dat <- read.delim('degree.txt')
head(dat)

#作图查看分布
par(mfrow = c(1, 2))
plot(dat$degree, dat$count, xlab = 'Degree', ylab = 'Count', 
    main = 'Degree distribution')
plot(log10(dat$degree), log10(dat$count), xlab = 'Log-degree', 
    ylab = 'Log-count', main = 'Log-log degree distribution')

######X 和 Y 的双 log 转换后的线性回归

#因此，可以首先作双 log 转化（log2、log10、ln 都可以，这里以 log10 为例）
#然后再通过转化后的值拟合一个简单一元线性回归
dat$log10_degree <- log10(dat$degree)
dat$log10_count <- log10(dat$count)

fit <- lm(log10_count~log10_degree, data = dat)
summary(fit)  #展示线性回归的简单统计

#可知获得的线性回归为
#lgY = -1.855lgX+2.564，校正后 R2=0.953，且 p<0.001

#提取斜率、截距和 R2（以校正后的 R2 为准），保留 3 位小数足矣了
b1 <- round(coefficients(fit)[1], 3)  #斜率，该示例为 2.564
a1 <- round(coefficients(fit)[2], 3)  #截距，该示例为 -1.855
r2.adj <- round(summary(fit)$adj.r.squared, 3)  #校正后的 R2，该示例为 0.953

#作图展示双 log 转化后，节点度和其频数分布的线性关系
library(ggplot2)

p <- ggplot(dat, aes(x = log10_degree, y = log10_count)) +
geom_point() +
stat_function(fun = function(x) a1*x+b1, color = 'blue') +  #添加自定义回归方程式，上面已经提取了斜率 a1=-1.855，截距 b1=2.564
theme(panel.grid = element_blank(), legend.key = element_blank(),
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
labs(x = 'Log10-degree', y = 'Log10-count')

p

#在图中添加线性回归式的文字描述
label_fit <- data.frame(
    formula = sprintf('italic(Y) == %.3f*italic(X) + %.3f', a1, b1),
    r2.adj = sprintf('italic(R^2) == %.3f', r2.adj),
    p = sprintf('italic(P) < %.3f', 0.001))

p +
geom_text(x = 0.8, y = 2.4, aes(label = formula), data = label_fit, parse = TRUE,
    size = 3, hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 0.8, y = 2.2, aes(label = r2.adj), data = label_fit, parse = TRUE,
    size = 3, hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 0.8, y = 2.0, aes(label = p), data = label_fit, parse = TRUE,
    size = 3, hjust = 0, color = 'blue', show.legend = FALSE)


######指数回归
#根据 X 和 Y 的双 log 转换后的线性回归式，lgY = -1.855lgX+2.564
#反向推算指数回归式，Y = 366.44X^-1.855

#作图展示原始的节点度和其频数分布的线性关系
a <- 366.438
b <- -1.855

p <- ggplot(dat, aes(x = degree, y = count)) +
geom_point() +
stat_function(fun = function(x) a*x^b, color = 'blue') +  #添加自定义回归方程式，这个是指数回归
theme(panel.grid = element_blank(), legend.key = element_blank(),
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
labs(x = 'degree', y = 'count')

p

#在图中添加指数回归式的文字描述
label_fit <- data.frame(
    formula1 = sprintf('italic(Y) == %.3f*italic(X)^%.3f', a, b)
)

p +
geom_text(x = 13, y = 320, aes(label = formula1), data = label_fit, parse = TRUE,
    hjust = 0, color = 'blue', show.legend = FALSE)

#通过非线性回归函数 nls() 拟合指数回归
fit <- nls(count ~ a*degree^b, data = dat, start = list(a = 366.438, b = -1.855))
summary(fit)  #展示拟合的指数回归的简单统计

#nls() 拟合的指数回归，Y = 224.754^-1.325

##通过指数回归式，基于 degree 值预测 count 值，再根据 count 的原始观测值和预测值的差异，获得 R2
#SSre：the sum of the squares of the distances of the points from the fit
#SStot：the sum of the squares of the distances of the points from a horizontal line through the mean of all Y values

#指数回归式，Y = 366.44X^-1.855
mod1 <- function(x) 366.44*x^-1.855
fit1 <- mod1(dat$degree)
SSre <- sum((dat$count-fit1)^2)
SStot <- sum((dat$count-mean(dat$count))^2)
R2.lm <- round(1 - SSre/SStot, 3)
R2.lm  #这个是 Y = 366.44X^-1.855 的 R2，线性回归转换的 R2

#指数回归式，Y = 224.754^-1.325
mod2 <- function(x) 224.754*x^-1.325
fit2 <- mod2(dat$degree)
SSre <- sum((dat$count-fit2)^2)
SStot <- sum((dat$count-mean(dat$count))^2)
R2.nls <- round(1 - SSre/SStot, 3)
R2.nls  #这个是 Y = 224.754^-1.325 的 R2，nls() 拟合的 R2

##p 值可以根据置换检验的原理获得
#将 count 的值分别随机置换 N 次（例如 999 次），通过随机置换数据后数据获取 R2（R2'）
#比较随机置换后值的 R2' 大于观测值的 R2 的频率，即为 p 值
#指数回归式 Y = 366.44X^-1.855 和 Y = 224.754^-1.325，放在一个循环中同时计算了
p_num.lm <- 1
p_num.nls <- 1
n <- 999

dat_rand <- dat
for (i in 1:n) {
    dat_rand$count <- sample(dat_rand$count)
    
    SSre_rand.lm <- sum((dat_rand$count-fit1)^2)
    SStot_rand.lm <- sum((dat_rand$count-mean(dat_rand$count))^2)
    R2_rand.lm <- 1 - SSre_rand.lm/SStot_rand.lm
    if (R2_rand.lm > R2.lm) p_num.lm <- p_num.lm + 1
    
	SSre_rand.nls <- sum((dat_rand$count-fit2)^2)
    SStot_rand.nls <- sum((dat_rand$count-mean(dat_rand$count))^2)
    R2_rand.nls <- 1 - SSre_rand.nls/SStot_rand.nls
    if (R2_rand.nls > R2.nls) p_num.nls <- p_num.nls + 1
}

p_value.lm <- p_num.lm / (n+1)
p_value.lm  #这个是 Y = 366.44X^-1.855 的 R2，线性回归转换的 p 值
p_value.nls <- p_num.nls / (n+1)
p_value.nls  #这个是 Y = 224.754^-1.325 的 R2，nls() 拟合的 p 值

#比较由线性回归转化的指数回归，和 nls() 直接得到的指数回归的差异
a.lm <- 366.438
b.lm <- -1.855
R2.lm <- 0.554
p.lm <- 0.001

a.nls <- 224.754
b.nls <- -1.325
R2.nls <- 0.983
p.nls <- 0.001

p <- ggplot(dat, aes(x = degree, y = count)) +
geom_point() +
stat_function(fun = function(x) a.lm*x^b.lm, color = 'blue') + 
stat_function(fun = function(x) a.nls*x^b.nls, color = 'red') +
theme(panel.grid = element_blank(), legend.key = element_blank(),
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
labs(x = 'degree', y = 'count')

p

#在图中添加指数回归式的文字描述
label_fit <- data.frame(
    formula_1 = sprintf('italic(Y) == %.3f*italic(X)^%.3f', a.lm, b.lm), 
    r2_1 = sprintf('italic(R^2) == %.3f', R2.lm), 
    p_1 = sprintf('italic(P) < %.3f', p.lm), 
    formula_2 = sprintf('italic(Y) == %.3f*italic(X)^%.3f', a.nls, b.nls), 
    r2_2 = sprintf('italic(R^2) == %.3f', R2.nls), 
    p_2 = sprintf('italic(P) < %.3f', p.nls)
)

p +
geom_text(x = 13, y = 350, aes(label = formula_1), data = label_fit, parse = TRUE,
    hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 13, y = 310, aes(label = r2_1), data = label_fit, parse = TRUE,
    hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 13, y = 270, aes(label = p_1), data = label_fit, parse = TRUE,
    hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 13, y = 220, aes(label = formula_2), data = label_fit, parse = TRUE,
    hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 13, y = 180, aes(label = r2_2), data = label_fit, parse = TRUE,
    hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 13, y = 140, aes(label = p_2), data = label_fit, parse = TRUE,
    hjust = 0, color = 'red', show.legend = FALSE)

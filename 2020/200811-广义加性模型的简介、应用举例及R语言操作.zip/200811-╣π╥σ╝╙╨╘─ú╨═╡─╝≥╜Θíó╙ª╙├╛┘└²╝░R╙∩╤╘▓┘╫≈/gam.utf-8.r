#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#使用 mgcv 包拟合广义加性模型
library(mgcv)

#详情 ?gam，这里通过 family='poisson' 指定泊松加性模型
#需要在 gam() 函数中指定自变量的局部平滑器类型，如 s() 的样条平滑、lo() 的 LOESS 平滑等
#以样条平滑 s() 为例，参数 k 可用于指定平滑程度，值越小约平滑，越高扭动越高，详情 ?s
#这里直接使用默认的平滑参数，只是可能有些不妥，作为示例请忽略这点
gam_poisson <- gam(fish~s(acre)+s(do2)+s(depth)+s(no3)+s(so4)+s(temp), 
    data = dat, family = 'poisson')
summary(gam_poisson)

#平滑回归曲线图，默认显示 95% 置信区间，通过 select 参数选择第 n 个自变量展示
par(mfrow = c(2, 3))
plot(gam_poisson, select = 1, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson, select = 2, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson, select = 3, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson, select = 4, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson, select = 5, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson, select = 6, pch = 20, shade = TRUE, residuals = TRUE)

#更改平滑参数，将导致不同的生物学意义解释
#例如更改氧含量的平滑参数，在样条平滑 s() 中调试参数 k
gam_poisson1 <- gam(fish~s(acre)+s(do2, k = 3)+s(depth)+s(no3)+s(so4)+s(temp), data = dat, family = 'poisson')
gam_poisson2 <- gam(fish~s(acre)+s(do2, k = 5)+s(depth)+s(no3)+s(so4)+s(temp), data = dat, family = 'poisson')

par(mfrow = c(1, 3))
plot(gam_poisson, select = 2, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson1, select = 2, pch = 20, shade = TRUE, residuals = TRUE)
plot(gam_poisson2, select = 2, pch = 20, shade = TRUE, residuals = TRUE)

#考虑了偏大离差问题的泊松加性模型
gam_quasipoisson <- gam(fish~s(acre)+s(do2)+s(depth)+s(no3)+s(so4)+s(temp), 
    data = dat, family = 'quasipoisson')

summary(gam_quasipoisson)
plot(gam_quasipoisson)



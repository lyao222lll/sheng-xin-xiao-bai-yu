####两组连续变量之间的交互效应
#读取示例数据
dat_beetles <- read.delim('beetles.txt', sep = '\t')

#拟合甲虫捕食频率与周围猎物数量和气温的关系
#不考虑猎物数量和气温的交互效应时，不放首先通过二元线性回归来简单描述三者间关系
fit1 <- lm(attack_rate~prey_num+temperature, data = dat_beetles)
summary(fit1)  #不带交互项回归的简单统计

#可以看到猎物数量和气温也存在较强关联的，但是本示例请忽略这种共线性问题......
plot(dat_beetles$temperature, dat_beetles$prey_num, pch = 20, 
    xlab = 'temperature', ylab = 'prey number')

#如果考虑猎物数量和气温的交互效应，公式中使用“*”表示二者交互，此时不再是线性回归
fit2 <- lm(attack_rate~prey_num*temperature, data = dat_beetles)
summary(fit2)  #带交互项回归的简单统计

#作图查看交互效应
#effects 包提供了强大而便捷的方法
library(effects)

plot(effect('prey_num*temperature', fit2), multiline=TRUE)

####考虑类别预测变量的交互效应
#读取示例数据
dat_plant <- read.delim('plant.txt', sep = '\t')

#探讨植物生长高度与其所处环境中土壤氮浓度及温度的关系
#存在类别型预测变量时，lm() 中推荐使用 factor(类别型预测变量) 写入公式

#不考虑土壤氮浓度及温度的交互效应时，一个简单的带类别型自变量的二元线性回归
fit1 <- lm(plant~N+factor(temperature), data = dat_plant)
summary(fit1)  #不带交互项回归的简单统计

#如果考虑土壤氮浓度及温度的交互效应，同样地，公式中使用“*”表示二者交互，此时不再是线性回归
fit2 <- lm(plant~N*factor(temperature), data = dat_plant)
summary(fit2)  #带交互项回归的简单统计

#anova() 检验两个嵌套模型的拟合优度
#比较不含交互项与含交互项的预测效果是否一样好
anova(fit1, fit2)

#AIC 评估两个回归复杂性与拟合优度的关系
#AIC 值较小的回归优先选择，表明较少的预测变量已经获得了足够的拟合度
AIC(fit1, fit2)

#作图查看交互效应
library(ggplot2)

p <- ggplot(dat_plant, aes(x = N, y = plant, color = factor(temperature))) +
geom_point() +
scale_color_manual(values = c('red', 'blue'), limit = c('High', 'Low')) +
stat_function(fun = function(x) 2.99*x - 1.17, color = 'blue') +  #添加自定义回归方程式
stat_function(fun = function(x) 4.50*x - 1.10, color = 'red') +
theme(panel.grid = element_blank(), legend.key = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'transparent')) +
labs(x = 'N', y = 'plant', color = '')

#将回归方程添加在图中
label_fit <- data.frame(
    formula_high = sprintf('italic(Y) == %.2f*italic(X) - %.2f', 4.50, 1.10), 
    formula_low = sprintf('italic(Y) == %.2f*italic(X) - %.2f', 2.99, 1.17))

p +
geom_text(x = 1, y = 40, aes(label = formula_high), data = label_fit, parse = TRUE,
    hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 1, y = 35, aes(label = formula_low), data = label_fit, parse = TRUE,
    hjust = 0, color = 'blue', show.legend = FALSE)


#########
library(SiZer)

#示例数据集，详情 ?Arkansas
data(Arkansas)
head(Arkansas)

#平滑拟合探索二者关系，发现似乎存在一个阈值时间
#该时间点之前，蜉蝣丰度呈上升趋势；时间点之后，蜉蝣丰度大致平缓
library(ggplot2)

ggplot(Arkansas, aes(year, sqrt.mayflies)) +
geom_point() +
geom_smooth()

#提示似乎可以通过分段线性回归描述二者关系，该阈值时间就是断点
#执行分段线性回归，详情 ?piecewise.linear
#分段断点的位置自动确定，并使用 1000 次自举估计 95% 置信区间
model <- piecewise.linear(x = Arkansas$year, y = Arkansas$sqrt.mayflies, 
    CI = TRUE, bootstrap.samples = 1000, sig.level = 0.05)
model

#简单作图查看分段线性回归图
plot(model, xlab = 'year', ylab = 'sqrt.mayflies')

#模型预测值
predict(model, Arkansas$year)

#对于模型 R2 的获得方式，可以通过已知回归式，基于自变量值预测响应变量的期望值，再根据响应变量的原始观测值和预测值的差异，获得 R2
#SSre：the sum of the squares of the distances of the points from the fit
#SStot：the sum of the squares of the distances of the points from a horizontal line through the mean of all Y values
fit1 <- predict(model, Arkansas$year)
SSre <- sum((Arkansas$sqrt.mayflies-fit1)^2)
SStot <- sum((Arkansas$sqrt.mayflies-mean(Arkansas$sqrt.mayflies))^2)
R2 <- round(1 - SSre/SStot, 3)
R2

#########
library(segmented)

#例如，先拟合一个简单的线性回归模型
fit_lm <- lm(sqrt.mayflies~year, data = Arkansas)
summary(fit_lm)

#在上述已知的线性回归模型中，通过函数 segmented() 寻找可能的断点
#详情 ?segmented，可选两种方法

#第一种，通过 npsi 指定断点数量
#例如 1 个断点，将自动在全范围内寻找可能的断点位置
lm_seg1 <- segmented(fit_lm, seg.Z = ~year, npsi = 1)
summary(lm_seg1)

plot(lm_seg1, xlab = 'year', ylab = 'sqrt.mayflies')
points(sqrt.mayflies~year, data = Arkansas)

#第二种，通过 psi 指定断点可能存在的大致初始位置
#例如 x=1997 是可能的断点位置，将它指定，将自动在 x=1997 附近寻找最佳的断点位置
lm_seg2 <- segmented(fit_lm, seg.Z = ~year, psi = 1997) 
summary(lm_seg2)

plot(lm_seg2, xlab = 'year', ylab = 'sqrt.mayflies')
points(sqrt.mayflies~year, data = Arkansas)

#注：segmented() 的两种方法得到的断点位置或参数估计值等可能不同
#不同 R 包的方法之间，得到的断点位置或参数估计值等可能不同

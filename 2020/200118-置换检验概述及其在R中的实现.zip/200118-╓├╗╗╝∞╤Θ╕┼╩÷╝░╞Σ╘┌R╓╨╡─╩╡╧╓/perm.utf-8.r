#数据获取自 http://blog.sciencenet.cn/blog-3406804-1173120.html
dat <- read.table('data.txt', sep = '\t', row.names = 1, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)

#只包含细菌类群丰度数据，计算细菌类群之间的相关性
dat_phylum <- dat[8:17]
var_name <- names(dat_phylum)

##自写过程实现
#计算观测数据的相关系数
dat_phylum <- scale(dat_phylum)
cor0 <- cor(dat_phylum, method = 'pearson')

p_num <- cor0
p_num[abs(p_num)>0] <- 1

#随机置换数据 999 次，计算每次获得的相关系数，并统计 |corN|>|cor0| 的频数
set.seed(123)

for (i in 1:999) {
	random <- matrix(sample(dat_phylum), ncol = 10)
	colnames(random) <- var_name
	corN <- cor(random, method = 'pearson')
	
	corN[abs(corN) >= abs(cor0)] <- 1
	corN[abs(corN) < abs(cor0)] <- 0
	p_num <- p_num + corN
}

#p 值矩阵，即 |corN|>|cor0| 的概率
p <- p_num/1000
p

##使用 R 内置函数的相关性系数计算并获得检验
library(psych)

cor_test <- corr.test(dat_phylum, method = 'pearson')

cor_test$r
cor_test$p

##相关图比较
#左图为手写的置换检验结果，右图为 psych 包获得的结果
#仅显著的相关系数标以背景色
library(corrplot)

layout(matrix(c(1,2), 1, 2, byrow = TRUE))
corrplot(cor0, method = 'square', type = 'lower', p.mat = p, sig.level = 0.05, insig = 'blank', addCoef.col = 'black', diag = FALSE, number.cex = 0.8, tl.cex = 0.8)
corrplot(cor_test$r, method = 'square', type = 'lower', p.mat = cor_test$p, sig.level = 0.05, insig = 'blank', addCoef.col = 'black', diag = FALSE, number.cex = 0.8, tl.cex = 0.8)

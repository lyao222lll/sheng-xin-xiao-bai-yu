##
library(igraph)

#输入数据示例，邻接矩阵
#这是一个微生物相关性网络，数值表示了微生物 OTU 之间的相关系数（正负相关以及相关性的大小）
adjacency_weight <- read.delim('adjacency_weight.txt', row.names = 1, sep = '\t', check.names = FALSE)
head(adjacency_weight)[1:6]    #邻接矩阵类型的网络文件

#邻接矩阵 -> igraph 的邻接列表，获得含权的无向网络
g <- graph_from_adjacency_matrix(as.matrix(adjacency_weight), mode = 'undirected', weighted = TRUE, diag = FALSE)
g    #igraph 的邻接列表

#孤立节点的删除（删除度为 0 的节点）
g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))

#上述将相关系数转化为边的权重
#由于相关系数有负值，而权重正常都应为正值，所以对由相关系数得到的权重取绝对值
#新生成一列边属性记录相关系数
E(g)$corr <- E(g)$weight
E(g)$weight <- abs(E(g)$weight)

#计算节点度（Degree）以及获得其分布
V(g)$degree <- degree(g)
degree_dist <- degree.distribution(g)[-1]
degree_num <- 1:max(V(g)$degree)

par(mfrow = c(1, 2))
hist(V(g)$degree, xlab = 'Degree', ylab = 'Frequency', 
    main = 'Degree distribution')
plot(degree_num, degree_dist, log = 'xy', xlab = 'Log-degree', 
    ylab = 'Log-intensity', main = 'Log-log degree distribution')

#节点数量和边的数量
node_num <- vcount(g)
edge_num <- ecount(g)
node_num
edge_num

#聚类系数（clustering coefficient）
clustering_coefficient <- transitivity(g)
clustering_coefficient

#平均路径长度（average path length）
average_path_length <- average.path.length(g, directed = FALSE)
average_path_length

##随机网络生成
#经典随机图，详见 ?erdos.renyi.game，以下两种方法都可以
#指定节点数量，以及每对节点间出现边的概率
g_rand <- erdos.renyi.game(n = 77, p = 161/(77^2/2), type = 'gnp', weight = FALSE, mode = 'undirected')
vcount(g_rand)
ecount(g_rand)    #通过概率指定的边数量，每次会存在波动
hist(degree(g_rand))    #节点度分布

#或者直接指定节点数量和边数量
g_rand <- erdos.renyi.game(n = 77, p = 161, type = 'gnm', weight = FALSE, mode = 'undirected')
vcount(g_rand)
ecount(g_rand)
hist(degree(g_rand))    #节点度分布

#聚类系数和平均路径长度
transitivity(g_rand)
average.path.length(g_rand, directed = FALSE)

#1000 个随机网络的拓扑特征与上述微生物共发生网络的拓扑特征比较
clustering_coefficient_rand <- clustering_coefficient
average_path_length_rand <- average_path_length
for (i in 1:1000) {
    g_rand <- erdos.renyi.game(n = 77, p = 161, type = 'gnm', weight = FALSE, mode = 'undirected')
    clustering_coefficient_rand <- c(clustering_coefficient_rand, transitivity(g_rand))
    average_path_length_rand <- c(average_path_length_rand, average.path.length(g_rand, directed = FALSE))
}

par(mfrow = c(1, 2))
hist(clustering_coefficient_rand, breaks = 50)
abline(v = clustering_coefficient, col = 'red')
hist(average_path_length_rand, breaks = 50)
abline(v = average_path_length, col = 'red')

##广义随机图
#上述微生物共发生网络的度分布
node_num <- vcount(g)
node_num

degree_dist <- table(V(g)$degree)
degree_num <- as.numeric(names(degree_dist))
degree_count <- as.numeric(degree_dist)
names(degree_count) <- degree_num
degree_count

#定义图的集合
degs <- rep(degree_num, degree_count)
degs

#广义随机图获得的一种方式，详情 ?degree.sequence.game
#尽管每次获得的随机图具有相同的节点数、边数和度分布，但连通结构是不同的
g_rand <- degree.sequence.game(degs, method = 'simple')
vcount(g_rand)    #节点数量
ecount(g_rand)    #边数量

#聚类系数和平均路径长度
transitivity(g_rand)
average.path.length(g_rand, directed = FALSE)

par(mfrow = c(1, 2))
plot(g_rand, layout = layout.circle)    #网络图简单展示
hist(degree(g_rand))    #节点度分布

#1000 个随机网络的拓扑特征与上述微生物共发生网络的拓扑特征比较
clustering_coefficient_rand <- clustering_coefficient
average_path_length_rand <- average_path_length
for (i in 1:1000) {
    g_rand <- degree.sequence.game(degs, method = 'simple')
    clustering_coefficient_rand <- c(clustering_coefficient_rand, transitivity(g_rand))
    average_path_length_rand <- c(average_path_length_rand, average.path.length(g_rand, directed = FALSE))
}

par(mfrow = c(1, 2))
hist(clustering_coefficient_rand, breaks = 50)
abline(v = clustering_coefficient, col = 'red')
hist(average_path_length_rand, breaks = 50)
abline(v = average_path_length, col = 'red')

##5 个网络的批处理
adj_file <- dir('five_network')
result <- NULL

for (file in adj_file) {
    #读取网络邻接矩阵
    adj <- read.delim(paste('five_network', file, sep = '/'), row.names = 1, sep = ',', check.names = FALSE)
    
    #转为 igraph 网络邻接列表，并删除孤立节点（删除度为 0 的节点）
    g <- graph_from_adjacency_matrix(as.matrix(adj), mode = 'undirected', weighted = TRUE, diag = FALSE)
    g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))
    
    #网络拓扑特征
    node_num <- vcount(g)    #节点数量
    edge_num <- ecount(g)    #边的数量
    V(g)$degree <- degree(g)    #计算节点度
    clustering_coefficient <- transitivity(g)    #聚类系数
    
    #接下来通过广义随机图评估
    #首先定义图的集合
    degree_dist <- table(V(g)$degree)
    degree_num <- as.numeric(names(degree_dist))
    degree_count <- as.numeric(degree_dist)
    names(degree_count) <- degree_num
    degs <- rep(degree_num, degree_count)
    
    #1000 个随机网络及拓扑特征计算
    clustering_coefficient_rand <- clustering_coefficient
    set.seed(123)
    for (i in 1:1000) {
        g_rand <- degree.sequence.game(degs, method = 'simple')
        clustering_coefficient_rand <- c(clustering_coefficient_rand, transitivity(g_rand))
    }
    
    result <- rbind(result, c(node_num, edge_num, clustering_coefficient, 
        mean(clustering_coefficient_rand), sd(clustering_coefficient_rand)))
}

#输出表格
result <- data.frame(result)
rownames(result) <- gsub('.csv', '', adj_file)
colnames(result) <- c('node_num', 'edge_num', 'clustering_coefficient', 
    'clustering_coefficient_rand_average', 'clustering_coefficient_rand_sd')
result

write.table(result, 'five_network.stat.txt', sep = '\t', col.names = NA, quote = FALSE)
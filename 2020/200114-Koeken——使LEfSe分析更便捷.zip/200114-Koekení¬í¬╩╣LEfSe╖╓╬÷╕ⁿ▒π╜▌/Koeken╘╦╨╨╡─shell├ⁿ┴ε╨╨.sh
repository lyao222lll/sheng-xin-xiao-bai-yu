#使用 pip 安装 Koeken
pip install https://github.com/twbattaglia/koeken/zipball/master
koeken.py --help

#或者编译安装
wget https://codeload.github.com/twbattaglia/koeken/zip/master
unzip master
cd koeken-master
python setup.py install
koeken.py --help

#或者 conda 安装
conda install Koeken
koeken.py --help


#示例数据可获取自 https://pan.baidu.com/s/1ctwyoTqT1ofygMUnTj7CPA
#otu_table.txt，OTU 丰度表
#otu_tax.txt，OTU 注释文件，数据库随意
#mapping.txt，QIIME 的 mapping 配置文件，含样本分组信息

#常见的 OTU 丰度表转为 biom 格式，并添加 OTU 注释信息
cp otu_table.txt otu_table.tsv
sed -i '1i\# Constructed from biom file' otu_table.tsv
biom convert -i otu_table.tsv -o otu_table.biom --table-type="OTU table" --to-json
biom add-metadata -i otu_table.biom --observation-metadata-fp otu_tax.txt -o otu_table.tax.biom --sc-separated taxonomy --observation-header OTUID,taxonomy 

#运行 Koeken 的一个简单示例，细节参数详见 koeken.py --help
#例如，设定统计检验显著性 p 值 0.05，LDA 得分值 2.0
koeken.py --input otu_table.tax.biom --map mapping.txt --output koeken_out \
    --class Treatment --split Day --level 6 --pval 0.05 --effect 2 --clade --image pdf

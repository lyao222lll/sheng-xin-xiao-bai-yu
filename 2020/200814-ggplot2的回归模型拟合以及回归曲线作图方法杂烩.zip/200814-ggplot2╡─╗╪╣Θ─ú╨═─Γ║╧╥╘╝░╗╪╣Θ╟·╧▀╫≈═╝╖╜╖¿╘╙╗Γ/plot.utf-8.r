#######################################
#######################################
#stat_smooth()和 geom_smooth() 绘制拟合曲线

#############
#MASS 包的示例数据集，波士顿郊区的房屋价值，详情 ?Boston
library(MASS)
data(Boston)

#ggplot2 绘制低收入人口比例和居住地房屋价格的关系
library(ggplot2)

p <- ggplot(data = Boston, aes(x = medv, y = lstat)) +
geom_point() +
theme_bw()

p

##拟合局部加权回归（loess），并展示 95% 置信区间
#stat_smooth() 参数 span 可控制曲线平滑度，值越大拟合曲线越平滑，详情 ?stat_smooth
#注意平滑参数值应当谨慎设置，它强烈影响曲线意义的解读
p1 <- p + stat_smooth(method = 'loess', span = 0.5, se = TRUE, level = 0.95) 
p1

#类似地，geom_smooth() 参数中，span 控制曲线平滑度
p2 <- p + geom_smooth(method = 'loess', span = 0.75, se = TRUE)
p2

##gam 默认情况下执行一般加性模型的平滑回归，并展示 95% 置信区间
#stat_smooth() 和 geom_smooth() 的用法大致相似
#通过 formula = y~s(x) 指定函数关系，s() 中的参数 k 可调整平滑度，详情 ?s()
#注意平滑参数值应当谨慎设置，它强烈影响曲线意义的解读
p + stat_smooth(method = 'gam', formula = y~s(x, k = 10), se = TRUE, level = 0.95) 
p + geom_smooth(method = 'gam', formula = y~s(x, k = 5), se = TRUE)

##一般线性模型（lm），并展示 95% 置信区间
#stat_smooth() 拟合简单线性回归，详情 ?stat_smooth
p1 <- p1 + stat_smooth(method = 'lm', se = TRUE, level = 0.95, color = 'red')
p1

#geom_smooth() 拟合简单线性回归，详情 ?geom_smooth
p2 <- p2 + geom_smooth(method = 'lm', se = TRUE, color = 'red')
p2

##添加低收入人口比例和居住地房屋价格的二次线性回归，并展示 95% 置信区间
#geom_smooth() 默认 formula=y~x 对应一次关系，可更改 formula = y~poly(x, n) 拟合 n 次关系，详情 ?stat_smooth
p1 + stat_smooth(method = 'lm', formula = y~poly(x, 2), se = TRUE, level = 0.95, color = 'green3')

#同样地，geom_smooth() 默认 formula=y~x 对应一次关系，可更改 formula = y~poly(x, n) 拟合 n 次关系，详情 ?geom_smooth
p2 + geom_smooth(method = 'lm', formula = y~poly(x, 2), se = TRUE, color = 'green3')

#############
#读取示例的鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#ggplot2 绘制鱼类物种丰度与水域流域面积的关系
library(ggplot2)

p <- ggplot(data = dat, aes(x = acre, y = fish)) +
geom_point() +
theme_bw()

p

##计数型变量，尝试使用泊松加性模型拟合平滑曲线探索变量关系，并展示 95% 置信区间
#stat_smooth() 和 geom_smooth() 的用法大致相似
#通过 method.args 指定响应变量的类型，这里使用泊松加性模型
#通过 formula = y~s(x) 指定函数关系，平滑器 s() 中的参数 k 可调整平滑度，详情 ?s()
#注意平滑参数值应当谨慎设置，它强烈影响曲线意义的解读
p1 <- p + stat_smooth(method = 'gam', formula = y~s(x, k = 5), method.args = list(family = 'poisson'), se = TRUE, level = 0.95)
p1

p2 <- p + geom_smooth(method = 'gam', formula = y~s(x, k = 3), method.args = list(family = 'poisson'), se = TRUE)
p2

##计数型变量，尝试使用广义线性模型的泊松回归描述变量关系，并展示 95% 置信区间
#stat_smooth() 和 geom_smooth() 中，通过 method.args 指定响应变量的类型，这里使用泊松回归
p1 + stat_smooth(method = 'glm', method.args = list(family = 'poisson'), se = TRUE, level = 0.95, color = 'red') 
p2 + geom_smooth(method = 'glm', method.args = list(family = 'poisson'), se = TRUE, color = 'red')

#############
#威斯康星州乳腺癌数据集
breast <- read.csv('breast.csv')

#使用 0-1 的二分数值重新定义肿瘤的两种状态（0，良性；1，恶性）
breast[which(breast$class == 2),'response'] <- 0
breast[which(breast$class == 4),'response'] <- 1

#例如以肿瘤厚度得分与肿瘤良性或恶性状态的关系为例
library(ggplot2)

p <- ggplot(data = breast, aes(x = clumpThickness, y = response)) +
geom_jitter(height = 0.05, width = 0, alpha = 0.5) +  #作图时对点添加了少量上下抖动效果仅为减少点的重叠
theme_bw()

p

##二分响应变量，使用广义线性模型的二项 logistic 回归描述变量关系，并展示 95% 置信区间
p + stat_smooth(method = 'glm', method.args = list(family = 'binomial'), se = TRUE, level = 0.95, color = 'red') 
p + geom_smooth(method = 'glm', method.args = list(family = 'binomial'), se = TRUE, color = 'red')

#############
#MASS 包的示例数据集，波士顿郊区的房屋价值，详情 ?Boston
library(MASS)
data(Boston)

#ggplot2 绘制居住地房屋价格和人均城镇犯罪率的关系
library(ggplot2)

p <- ggplot(data = Boston, aes(x = crim, y = medv)) +
geom_point() +
theme_bw() +
stat_smooth(method = 'loess', span = 0.5, se = TRUE, level = 0.95) 

p

##参数非线性回归（nls）的拟合，以指数回归为例
#stat_smooth() 和 geom_smooth() 的用法大致相似
#参数中 a 和 b 的初始值手动指定，可参考 https://mp.weixin.qq.com/s/fxkMlEBs8UEwuGlUi50uLA
p + stat_smooth(method = 'nls', formula = y ~ a*x^b, method.args = list(start = list(a = 2, b = 1.5)), se = FALSE, color = 'red')
p + geom_smooth(method = 'nls', formula = y ~ a*x^b, method.args = list(start = list(a = 2, b = 1.5)), se = FALSE, color = 'red')

#######################################
#######################################
#stat_function() 绘制拟合曲线

#############
#MASS 包的示例数据集，波士顿郊区的房屋价值，详情 ?Boston
library(MASS)
data(Boston)

#ggplot2 绘制低收入人口比例和居住地房屋价格的关系
library(ggplot2)

p <- ggplot(data = Boston, aes(x = medv, y = lstat)) +
geom_point() +
theme_bw()

p

##通过 lm() 计算低收入人口比例和居住地房屋价格的二次线性关系
fit <- lm(lstat~medv+I(medv^2), data = Boston)
summary(fit)

#根据 lm() 获得的对回归系数（斜率）和截距的参数估计值
#可知二次回归式书写为 Y = -1.715X + 0.021X^2 + 39.048
#然后将这个回归式书写到 stat_function() 中
p + stat_function(fun = function(x) -1.715*x+0.021*x^2+39.048, color = 'red', size = 1.2)

#或者直接在 lm() 结果中提取回归系数（斜率）和截距
#然后将提取出的值代入至 stat_function() 中
b0 <- coefficients(fit)[1]  #截距
b1 <- coefficients(fit)[2]  #一次项的回归系数
b2 <- coefficients(fit)[3]  #二次项的回归系数

p + stat_function(fun = function(x) b1*x+b2*x^2+b0, color = 'red', size = 1.2)

#############
#ggplot2 绘制居住地房屋价格和人均城镇犯罪率的关系
library(ggplot2)

p <- ggplot(data = Boston, aes(x = crim, y = medv)) +
geom_point() +
theme_bw()

p

##参数非线性回归（nls）的拟合，以指数回归为例
#参数中 a 和 b 的初始值手动指定，可参考 https://mp.weixin.qq.com/s/fxkMlEBs8UEwuGlUi50uLA
mod <- nls(medv ~ a*crim^b, data = Boston, start = list(a = 2, b = 1.5))
summary(mod)

#根据 nls() 获得的对 a 和 b 参数估计值
#可知指数回归式书写为 Y = 20.743X^-0.086
#然后将这个回归式书写到 stat_function() 中
p + stat_function(fun = function(x) 20.743*x^-0.086, color = 'red', size = 1.2)

#或者直接在 nls() 结果中提取 a 和 b 的值
#然后将提取出的值代入至 stat_function() 中
a <- coefficients(mod)[1]  #a 的值
b <- coefficients(mod)[2]  #b 的值

p + stat_function(fun = function(x) a*x^b, color = 'red', size = 1.2)


#######################################
#######################################
#根据已知回归模型预测期望值，并在图中绘制后连接成线

#############
#MASS 包的示例数据集，波士顿郊区的房屋价值，详情 ?Boston
library(MASS)
data(Boston)

#ggplot2 绘制低收入人口比例和居住地房屋价格的关系
library(ggplot2)

p <- ggplot(data = Boston, aes(x = medv, y = lstat)) +
geom_point() +
theme_bw()

p

##通过 R 函数 loess() 构建局部加权回归（LOESS）模型
#参数 span 可控制曲线平滑度，值越大拟合曲线越平滑，详情 ?loess
#注意平滑参数值应当谨慎设置，它强烈影响曲线意义的解读
fit <- loess(lstat~medv, data = Boston, span = 0.75)
summary(fit)

#通过 predict() 根据已构建好的回归模型预测响应变量的期望值
#即根据居住地房屋价格获得低收入人口比例的预测值
lstat_pred <- predict(fit, Boston, type = 'response')
head(lstat_pred)

#将低收入人口比例的预测值添加在已有的关系图中，并用折线图连接成“拟合线”
Boston$lstat_pred <- lstat_pred

p + geom_line(data = Boston, aes(x = medv, y = lstat_pred), color = 'red') 

##和 ggplot2 的默认方法 stat_smooth() 的比较
p + stat_smooth(method = 'loess', span = 0.75, se = TRUE, level = 0.95) 

#############
#威斯康星州乳腺癌数据集
breast <- read.csv('breast.csv')

#使用 0-1 的二分数值重新定义肿瘤的两种状态（0，良性；1，恶性）
breast[which(breast$class == 2),'response'] <- 0
breast[which(breast$class == 4),'response'] <- 1

#例如以肿瘤厚度得分与肿瘤良性或恶性状态的关系为例
library(ggplot2)

p <- ggplot(data = breast, aes(x = clumpThickness, y = response)) +
geom_jitter(height = 0.05, width = 0, alpha = 0.5) +  #作图时对点添加了少量上下抖动效果仅为减少点的重叠
theme_bw()

p

##二分响应变量，使用广义线性模型的二项 logistic 回归描述变量关系
fit <- glm(response~clumpThickness, data = breast, family = binomial())
summary.glm(fit)

#通过 predict() 根据已构建好的回归模型预测响应变量的期望值
#即根据肿瘤厚度得分预测肿瘤为恶性的概率
response_pred <- predict(fit, breast, type = 'response')
head(response_pred)

#将预测的肿瘤为恶性的概率添加在已有的关系图中，并用折线图连接成“拟合线”
breast$response_pred <- response_pred

p + geom_line(data = breast, aes(x = clumpThickness, y = response_pred), color = 'red') 

##和 ggplot2 的默认方法 stat_smooth() 的比较
p + stat_smooth(method = 'glm', method.args = list(family = 'binomial'), se = TRUE, level = 0.95) 

#######################################
#######################################
#其它拓展作图

#############
#植物生长与环境条件的数据集
dat <- read.delim('plant.txt', sep = '\t')

#横坐标土壤氮浓度，纵坐标植物生长高度
#按高温和低维条件分别标记分组后，拟合线性回归
library(ggplot2)

p <- ggplot(data = dat, aes(x = N, y = plant)) +
geom_point(aes(color = temperature)) +
scale_color_manual(values = c('red', 'blue'), limits = c('High', 'Low')) +
geom_smooth(aes(color = temperature), method = 'lm', se = TRUE, show.legend = FALSE) +
theme_bw() +
theme(legend.key = element_blank()) +
labs(x = 'N', y = 'plant height')

p

#通过 lm() 获得线性回归的参数估计
fit_height <- lm(plant~N, data = subset(dat, temperature == 'High'))
summary(fit_height)

fit_low <- lm(plant~N, data = subset(dat, temperature == 'Low'))
summary(fit_low)

#提取两个回归的回归系数（斜率）、截距、R2、p 值等
b0_height <- coefficients(fit_height)[1]  #截距
b1_height <- coefficients(fit_height)[2]  #斜率
R2_height <- summary(fit_height)$adj.r.squared  #推荐使用校正后的 R2
p_height <- summary(fit_height)$coefficients[2,4]  #p 值

b0_low <- coefficients(fit_low)[1]  #截距
b1_lowt <- coefficients(fit_low)[2]  #斜率
R2_low <- summary(fit_low)$adj.r.squared  #推荐使用校正后的 R2
p_low <- summary(fit_low)$coefficients[2,4]  #p 值

#将提取出的结果组合成新的数据集，以便添加在原图中
label_height <- data.frame(
    formula_height = sprintf('italic(Y) == %.3f*italic(X) + %.3f', b1_height, b0_height),
    R2_height = sprintf('italic(R^2) == %.3f', R2_height),
    p_height = ifelse(p_height < 0.001, sprintf('italic(P) < 0.001'), ifelse(p_height < 0.01, sprintf('italic(P) < 0.01'), ifelse(p_height < 0.05, sprintf('italic(P) < 0.05'), sprintf('italic(P) >= 0.05')))), 
    formula_low = sprintf('italic(Y) == %.3f*italic(X) + %.3f', b1_lowt, b0_low),
    R2_low = sprintf('italic(R^2) == %.3f', R2_low),
    p_low = ifelse(p_low < 0.001, sprintf('italic(P) < 0.001'), ifelse(p_low < 0.01, sprintf('italic(P) < 0.01'), ifelse(p_low < 0.05, sprintf('italic(P) < 0.05'), sprintf('italic(P) >= 0.05')))))

#添加文字时手动调整下位置
p +
geom_text(x = 1, y = 42, aes(label = formula_height), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 1, y = 38, aes(label = R2_height), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 1, y = 34, aes(label = p_height), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'red', show.legend = FALSE) +
geom_text(x = 1, y = 28, aes(label = formula_low), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 1, y = 24, aes(label = R2_low), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'blue', show.legend = FALSE) +
geom_text(x = 1, y = 20, aes(label = p_low), data = label_height, parse = TRUE, size = 2.5, hjust = 0, color = 'blue', show.legend = FALSE)

#############
#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#绘制二维散点图观测各环境变量与鱼类物种丰度的关系
#并同时添加简单线性回归拟合线
library(ggplot2)

dat_plot <- reshape2::melt(dat, id = 'fish')

p <- ggplot(dat_plot, aes(value, fish)) +
geom_point() +
facet_wrap(~variable, ncol = 3, scale = 'free') +
geom_smooth(method = 'lm') +
labs(x = '', y = 'fish')

p

#以下在散点图中添加各环境变量与鱼类物种丰度的一元回归的 R2 和 p 值作为标识
#注：该 R2 和 p 值仅为多个一元回归的 R2 和 p 值，不要将其视为一个多元回归

#拟合各环境变量与鱼类物种丰度的一元回归，并提取各自 R2 和 p 值
env <- c('acre', 'do2', 'depth', 'no3', 'so4', 'temp')
R2_adj <- c()
p_value <- c()

for (i in env) {
    fit_stat <- summary(lm(dat[['fish']]~dat[[i]]))  #一元线性回归
    R2_adj <- c(R2_adj, fit_stat$adj.r.squared)  #提取校正后 R2
    p_value <- c(p_value, fit_stat$coefficients[2,4])  #提取显著性 p 值
}

env_stat <- data.frame(row.names = env, R2_adj, p_value)
env_stat  #数据框中存储了各环境变量与鱼类物种丰度的一元回归的 R2 和 p 值

#自动定义文字在图中的展示坐标位置
env_stat$fish <- (max(dat$fish)-min(dat$fish))*0.85 + min(dat$fish)
for (i in env) env_stat[i,'value'] <- (max(dat[[i]])-min(dat[[i]]))*0.7 + min(dat[[i]])

#生成文字标签数据集
env_stat$variable <- rownames(env_stat)
env_stat$R2_adj <- paste(sprintf('italic(R^2) == %.3f', env_stat$R2_adj))
env_stat$p_value <- paste(sprintf('italic(P) == %.3f', env_stat$p_value))

#和先前的数据框合并，便于作图
env_stat <- env_stat[c('fish', 'variable', 'value', 'R2_adj', 'p_value')]
dat_plot$R2_adj <- NA
dat_plot$p_value <- NA
dat_plot <- rbind(dat_plot, env_stat)

p + 
geom_text(data = dat_plot, aes(label = R2_adj), parse = TRUE, size = 3, hjust = 0) +
geom_text(data = dat_plot, aes(label = p_value), parse = TRUE, size = 3, hjust = 0, vjust = 3)

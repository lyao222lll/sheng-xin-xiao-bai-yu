##安装
#参考自
# https://stackoverflow.com/questions/29656320/r-mvpart-package-any-option-to-use-in-r-3-1-x#opennewwindow

#首先安装 Rtools，点击以下链接
# https://cran.r-project.org/bin/windows/Rtools/

#Rtools 安装好之后，再安装 mvpart 等包
install.packages('devtools')
devtools::install_github('cran/mvpart')  #计算多元回归树
devtools::install_github('cran/MVPARTwrap')  #辅助分析

#要是在已经安装了 Rtools 之后，再安装 mvpart 等包时还提示“ had non-zero exit status”之类的
#重新再安装一个新的 R 后，再安装 mvpart 等包

#加载
library(mvpart)
library(MVPARTwrap)

##多元回归树
#数据集，详情 ?spider
data(spider)
head(spider)

#由于 MRT 中的平方和计算具有欧式空间属性
#因此使用自己的数据分析时，需要考虑数据本身的特点，原始数值是否适合直接作为 MRT 的输入
#决定是否需要提前执行某种特定的预转化（如原始物种多度数据的预转化）
#或标准化（常见量纲不同的数据）等

#构建 MRT，详情 ?mvpart
#~. 意为使用所有环境变量，等同于 ~herbs+reft+moss+sand+twigs+water
species <- spider[ ,1:12]
env <- spider[ ,13:18]

set.seed(123)
spider_mvpart <- mvpart(data.matrix(species)~., env, xval = nrow(species), xvmult = 100, xv = 'pick', pca = TRUE)
spider_mvpart

#查看细节
summary(spider_mvpart)

##提取需要的结果用于进一步观测
names(spider_mvpart)

#例如获取 CP 表
cptable <- spider_mvpart$cptable
cptable

#例如查看样方分组
spider_class <- spider_mvpart$where
names(spider_class) <- rownames(spider)
spider_class

##MVPARTwrap 包的辅助功能，详情 ?MRT
#该包的安装方法同 mvpart，已在上文提及
library(MVPARTwrap)

spider_mvpart_wrap <- MRT(spider_mvpart, percent = 10, species = colnames(species))
spider_mvpart_wrap

summary(spider_mvpart_wrap)
plot(spider_mvpart_wrap)
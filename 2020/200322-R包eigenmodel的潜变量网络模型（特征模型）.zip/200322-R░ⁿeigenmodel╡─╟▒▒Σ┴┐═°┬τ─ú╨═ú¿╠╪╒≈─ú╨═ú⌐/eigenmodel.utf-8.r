##示例网络数据集
#注，sand 包在加载时默认加载 igraph
library(sand)

#律师关系网络，以 igraph 邻接列表形式给出，详情 ?lazega
data(lazega)
summary(lazega)
plot(lazega)

#这两个数据集为数据框结构的
#网络边列表（记录律师成员间的交互）
#节点属性列表（律师成员的属性）
head(elist.lazega)
head(v.attr.lazega)

#igraph 邻接列表转换为邻接矩阵
A <- get.adjacency(lazega, sparse = FALSE)
A[1:10,1:10]

##eigenmodel 包的潜变量网络模型
library(eigenmodel)

#潜变量特征推断，详情 ?eigenmodel_mcmc
#构建一个不包括成对协变量，潜变量特征空间维度 Q=2 的模型
set.seed(123)
lazega.leig.fit1 <- eigenmodel_mcmc(Y = A, X = NULL, R = 2, S = 11000, burn = 10000)

#考虑办公地点作为协变量
#为了包括共同办公地点的效应，创建一个包含该信息的序列
same.off.op <- v.attr.lazega$Office %o% v.attr.lazega$Office
same.off <- matrix(as.numeric(same.off.op %in% c(1, 4, 9)), 36, 36)
same.off <- array(same.off,dim = c(36, 36, 1))

#同样地，构建一个潜变量特征空间维度 Q=2 的模型
set.seed(123)
lazega.leig.fit2 <- eigenmodel_mcmc(Y = A, X = same.off, R = 2, S = 11000, burn = 10000)

#特征模型的特征向量提取
lat.sp.1 <- eigen(lazega.leig.fit1$ULU_postmean)$vec[ ,1:2]
lat.sp.2 <- eigen(lazega.leig.fit2$ULU_postmean)$vec[ ,1:2]

#网络图展示，按律师成员所在的办公地点对网络节点着色
colbar <- c('red', 'dodgerblue', 'goldenrod')
v.colors <- colbar[V(lazega)$Office]

par(mfrow = c(1, 2))
plot(lazega, layout = lat.sp.1, vertex.color = v.colors, main = '不包括成对协变量')
plot(lazega, layout = lat.sp.2, vertex.color = v.colors, main = '考虑办公地点作为协变量')

#后验均值
apply(lazega.leig.fit1$L_postsamp, 2, mean)
apply(lazega.leig.fit2$L_postsamp, 2, mean)

##5折交叉验证
#预定义向量集
perm.index <- sample(1:630)
nfolds <- 5
nmiss <- 630/nfolds
Avec <- A[lower.tri(A)]
Avec.pred1 <- numeric(length(Avec))
Avec.pred2 <- numeric(length(Avec))

#交叉验证过程
for(i in seq(1, nfolds)){
  
  #缺失值的索引值
  miss.index <- seq(((i-1) * nmiss + 1), 
     (i*nmiss), 1)
  A.miss.index <- perm.index[miss.index]
  
  #用 NA 值适当地填充一个新的 Atemp 矩阵
  Avec.temp <- Avec
  Avec.temp[A.miss.index] <- rep('NA', length(A.miss.index))
  Avec.temp <- as.numeric(Avec.temp)
  Atemp <- matrix(0, 36, 36)
  Atemp[lower.tri(Atemp)] <- Avec.temp
  Atemp <- Atemp + t(Atemp)
  
  #拟合特征模型并进行预测
  #分别为不包括成对协变量，以及将办公地点作为协变量
  Y <- Atemp
  
  set.seed(123)
  model1.fit <- eigenmodel_mcmc(Y = Y, R = 2, S = 11000, burn = 10000)
  model1.pred <- model1.fit$Y_postmean
  model1.pred.vec <- model1.pred[lower.tri(model1.pred)]
  Avec.pred1[A.miss.index] <- model1.pred.vec[A.miss.index]
  
  model2.fit <- eigenmodel_mcmc(Y = Y, X = same.off, R = 2, S = 11000, burn = 10000)
  model2.pred <- model2.fit$Y_postmean
  model2.pred.vec <- model2.pred[lower.tri(model2.pred)]
  Avec.pred2[A.miss.index] <- model2.pred.vec[A.miss.index]
}

##ROC 曲线
library(ROCR)

#预测
pred1 <- prediction(Avec.pred1, Avec)
perf1 <- performance(pred1, 'tpr', 'fpr')
pred2 <- prediction(Avec.pred2, Avec)
perf2 <- performance(pred2, 'tpr', 'fpr')

#绘制 ROC 曲线
par(mfrow = c(1, 2))
plot(perf1, col = 'red', lwd = 3, main = '不包括成对协变量')
abline(0,1)
plot(perf2, col = 'blue', lwd = 3, main = '考虑办公地点作为协变量')
abline(0,1)

#曲线下面积评估
perf1.auc <- performance(pred1, 'auc')
slot(perf1.auc, 'y.values')
perf2.auc <- performance(pred2, 'auc')
slot(perf2.auc, 'y.values')



##链接到 github 安装 SpiecEasi 包
#library(devtools)
devtools::install_github('zdk123/SpiecEasi')
library(SpiecEasi)

#示例数据，详情 ?amgut1.filt
data(amgut1.filt)
class(amgut1.filt)
amgut1.filt[1:6,1:6]

##构建网络，详情 ?spiec.easi
#data 指定未作任何预转化的 OTU 丰度表，将通过内部方法标准化
#method 提供了两种估计方法，即 glasso 和 mb，分别展示（二者间可能会差别较大）
se.gl.amgut <- spiec.easi(data = amgut1.filt, method = 'glasso', lambda.min.ratio = 0.01,
    nlambda = 20, pulsar.params = list(rep.num = 50))

se.mb.amgut <- spiec.easi(amgut1.filt, method = 'mb', lambda.min.ratio = 0.01,
    nlambda = 20, pulsar.params = list(rep.num=50))

se.gl.amgut
se.mb.amgut

#0-1 矩阵获得，即非含权的邻接矩阵（1 代表二者互作，0 代表无互作，不包含互作类型或强度）
#以 glasso 的结果为例
summary(se.gl.amgut)

adjacency_unweight <- data.frame(as.matrix(se.gl.amgut$refit$stars))
rownames(adjacency_unweight) <- colnames(amgut1.filt)
colnames(adjacency_unweight) <- colnames(amgut1.filt)
adjacency_unweight[10:16,10:16]

#如需输出 0-1 关系的邻接矩阵
write.table(adjacency_unweight, 'adjacency_unweight.glasso.txt', col.names = NA, sep = '\t', quote = FALSE)

##构建 igraph 网络，便于后续的统计分析，或作图
#将上述邻接矩阵转化为 igraph 的邻接列表，详情 ?adj2igraph
library(igraph)

ig.gl <- adj2igraph(getRefit(se.gl.amgut), vertex.attr = list(label = colnames(amgut1.filt)))
ig.mb <- adj2igraph(getRefit(se.mb.amgut), vertex.attr = list(label = colnames(amgut1.filt)))
ig.gl
ig.mb

#简单作图展示下
vsize <- rowMeans(clr(amgut1.filt, 1)) + 6
am.coord <- layout.fruchterman.reingold(ig.mb)

par(mfrow = c(1, 2))
plot(ig.gl, layout = am.coord, vertex.size = vsize, vertex.label = NA, main = 'glasso')
plot(ig.mb, layout = am.coord, vertex.size = vsize, vertex.label = NA, main = 'MB')

#非含权的网络输出，以 glasso 的结果为例
#节点属性列表
node.gl <- data.frame(id = as.vector(V(ig.gl)), label = V(ig.gl)$label)
write.table(node.gl, 'unweight.glasso_node.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#边列表
edge.gl <- data.frame(as_edgelist(ig.gl))
edge.gl <- data.frame(source = edge.gl[[1]], target = edge.gl[[2]], weight = E(ig.gl)$weight)
write.table(edge.gl, 'unweight.glasso_edge.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#graphml 格式，可使用 gephi 软件打开并进行可视化编辑
write.graph(ig.gl, 'unweight.glasso.graphml', format = 'graphml')

#gml 格式，可使用 cytoscape 软件打开并进行可视化编辑
write.graph(ig.gl, 'unweight.glasso.gml', format = 'gml')

##估计边的权重
library(Matrix)

secor <- cov2cor(getOptCov(se.gl.amgut))
sebeta <- symBeta(getOptBeta(se.mb.amgut), mode = 'maxabs')
elist.gl <- summary(triu(secor*getRefit(se.gl.amgut), k = 1))
elist.mb <- summary(sebeta)

head(elist.gl)
head(elist.mb)

#将权重合并到网络中，以 glasso 的结果为例
elist.gl <- data.frame(elist.gl)
names(elist.gl) <- c('source', 'target', 'weight')
elist.gl <- elist.gl[order(elist.gl$source, elist.gl$target), ]
E(ig.gl)$weight <- elist.gl$weight

#输出带权重的邻接矩阵，不再是 0-1 关系，而替换为具体数值（可表示两变量关联程度）
adjacency_weight <- as.matrix(get.adjacency(ig.gl, attr = 'weight'))
rownames(adjacency_weight) <- colnames(amgut1.filt)
colnames(adjacency_weight) <- colnames(amgut1.filt)
adjacency_weight[10:16,10:16]
write.table(data.frame(adjacency_weight), 'adjacency_weight.glasso.txt', col.names = NA, sep = '\t', quote = FALSE)

#以及含权重的边列表
edge.gl <- data.frame(as_edgelist(ig.gl))
edge.gl <- data.frame(source = edge.gl[[1]], target = edge.gl[[2]], weight = E(ig.gl)$weight)
write.table(edge.gl, 'weight.glasso_edge.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#graphml 格式，可使用 gephi 软件打开并进行可视化编辑
write.graph(ig.gl, 'weight.glasso.graphml', format = 'graphml')

#gml 格式，可使用 cytoscape 软件打开并进行可视化编辑
write.graph(ig.gl, 'weight.glasso.gml', format = 'gml')

##与 phyloseq 结合使用
library(SpiecEasi)
library(phyloseq)

#示例数据，内置的 phyloseq 对象
data('amgut2.filt.phy')

#构建非加权的无向网络
se.gl.amgut2 <- spiec.easi(amgut2.filt.phy, method = 'glasso', lambda.min.ratio = 0.01,
    nlambda = 20, pulsar.params = list(rep.num = 50))

#邻接矩阵转化为 igraph 的邻接列表
ig2.gl <- adj2igraph(getRefit(se.gl.amgut2), vertex.attr = list(name = taxa_names(amgut2.filt.phy)))

#可视化
plot_network(ig2.gl, amgut2.filt.phy, type = 'taxa', color = 'Rank3')

##跨组学数据的关联推断
library(SpiecEasi)
library(phyloseq)

#示例数据，内置的 phyloseq 对象（16S 的 hmp216S、蛋白质组的 hmp2prot）
data(hmp2)

#关联网络推断
se.hmp2 <- spiec.easi(list(hmp216S, hmp2prot), method = 'glasso', lambda.min.ratio = 0.01, 
    nlambda = 40,pulsar.params = list(thresh = 0.05))

#可视化
dtype <- c(rep(1,ntaxa(hmp216S)), rep(2,ntaxa(hmp2prot)))
plot(adj2igraph(getRefit(se.hmp2)), vertex.color = dtype + 1, vertex.size = 9)

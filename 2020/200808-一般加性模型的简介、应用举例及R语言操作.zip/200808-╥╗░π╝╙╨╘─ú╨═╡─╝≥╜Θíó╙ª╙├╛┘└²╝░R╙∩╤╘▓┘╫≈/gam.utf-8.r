#示例数据集，详情加载 agridat 包后 ?lasrosas.corn
library(agridat)

data(lasrosas.corn)
head(lasrosas.corn)

##R 包 mgcv 执行加性模型
##单变量回归示例
library(mgcv)

#避免多年度、多地区间数据混乱，选取 1999 年的 W 地区玉米田的数据为例进行后续分析
lasrosas.corn.select <- subset(lasrosas.corn, year == 1999 & topo == 'W')

#此处以一般加性模型为例，拟合玉米产量与施加氮肥浓度的平滑回归
#需要在 gam() 函数中指定自变量的局部平滑器类型，如 s() 的样条平滑、lo() 的 LOESS 平滑等
#详情 ?gam、?s、?lo 等

#以样条平滑为例，实现响应变量与自变量的局部平滑拟合
#s() 中，参数 k 可用于指定平滑程度，值越小约趋于线性平滑，越高扭动越厉害
fit1_k3 <- gam(yield~s(nitro, k = 3), data = lasrosas.corn.select)
summary(fit1_k3)  #检验自变量的显著性以及评估回归整体的方差解释率

fit1_k5 <- gam(yield~s(nitro, k = 5), data = lasrosas.corn.select)
summary(fit1_k5)  #检验自变量的显著性以及评估回归整体的方差解释率

fit1_k6 <- gam(yield~s(nitro, k = 6), data = lasrosas.corn.select)
summary(fit1_k6)  #检验自变量的显著性以及评估回归整体的方差解释率

#平滑回归曲线图，默认显示 95% 置信区间
par(mfrow = c(2, 3))
plot(fit1_k3)
plot(fit1_k5)
plot(fit1_k6)
plot(fit1_k3, select = 1, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)
plot(fit1_k5, select = 1, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)
plot(fit1_k6, select = 1, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)

##双变量回归示例
#类似多元回归方法，以 + 相连各自变量，表示加和效应，详情 ?gam
#对于各自变量，都需要指定局部平滑器类型，如这里统一为 s() 的样条平滑，详情 ?s()
#各自变量允许设置各自不同的平滑参数，如下示例
fit2_k3_k5 <- gam(yield~s(nitro, k = 3) + s(bv, k = 5), data = lasrosas.corn.select)
summary(fit2_k3_k5)  #检验自变量的显著性以及评估回归整体的方差解释率

fit2_k5_k10 <- gam(yield~s(nitro, k = 5) + s(bv, k = 10), data = lasrosas.corn.select)
summary(fit2_k5_k10)  #检验自变量的显著性以及评估回归整体的方差解释率

#平滑回归曲线图，默认显示 95% 置信区间
#多变量时，通过 select 选择第 n 个自变量展示和响应变量的回归曲线
par(mfrow = c(2, 2))
plot(fit2_k3_k5, select = 1, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)
plot(fit2_k3_k5, select = 2, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)
plot(fit2_k5_k10, select = 1, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)
plot(fit2_k5_k10, select = 2, pch = 20, se = TRUE, rug = TRUE, residuals = TRUE)

#拓展作图，二元平滑回归的二维平面等高线图和三维图，详情 ?vis.gam
#二维平面等高线图其实就是三维图中 z 轴的降维投影形式
par(mfrow = c(2, 2))

vis.gam(fit2_k3_k5, color = 'cm', plot.type = 'contour')
points(lasrosas.corn.select$nitro, lasrosas.corn.select$bv, pch = 16)
vis.gam(fit2_k5_k10, color = 'cm', plot.type = 'contour')
points(lasrosas.corn.select$nitro, lasrosas.corn.select$bv, pch = 16)
vis.gam(fit2_k3_k5, color = 'cm', theta = 30)
vis.gam(fit2_k5_k10, color = 'cm', theta = 30)

##继续考虑交互效应
#在上文的氮肥浓度、土壤有机物含量对玉米产量影响的二元回归的基础上
#继续考虑加入氮肥浓度和土壤有机物含量的交互效应

#直接在同一个平滑器内部输入所考虑交互效应的两自变量
#本示例使用样条平滑 s()，此时两自变量统一设置平滑参数
fit2_inter <- gam(yield~s(nitro, bv, k = 5), data = lasrosas.corn.select)
summary(fit2_inter)

#二维平面等高线图和三维图，详情 ?vis.gam
par(mfrow = c(1, 2))
vis.gam(fit2_inter, color = 'cm', plot.type = 'contour')
points(lasrosas.corn.select$nitro, lasrosas.corn.select$bv, pch = 16)
vis.gam(fit2_inter, color = 'cm', theta = 30)


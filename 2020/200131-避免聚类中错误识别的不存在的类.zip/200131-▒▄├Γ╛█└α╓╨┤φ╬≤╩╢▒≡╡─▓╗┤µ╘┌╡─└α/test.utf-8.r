##模拟生成均值为 3、标准差为 0.2 的正态分布的随机数
#共计 200 个随机数，构成 100 行 2 列的矩阵，视为 100 个观测对象，2 个变量
set.seed(123)
rand <- matrix(rnorm(200, mean = 3, sd = 0.2), ncol = 2)
head(rand)

#NbClust 包的最佳聚类数量评估，详情 ?NbClust
library(NbClust)

nc <- NbClust(rand, distance = 'euclidean', min.nc = 2, max.nc = 10, method = 'kmeans', index = 'hubert')
plot(nc)

#k-means 聚类
set.seed(123)
rand_kmeans <- kmeans(rand, centers = 6, nstart = 25)

rand_kmeans$cluster

#轮廓图评估
library(cluster)

plot(silhouette(rand_kmeans$cluster, vegdist(rand, method = 'euclidean')))

#二维变量的散点图，并标记分类
library(ggplot2)
library(plyr)

rand1 <- data.frame(rand)
rand1$group <- as.character(rand_kmeans$cluster)
group_border <- ddply(rand1, 'group', function(df) df[chull(df[[1]], df[[2]]), ])

ggplot(rand1, aes(X1, X2)) +
geom_point(aes(color = group)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.key = element_rect(fill = 'transparent')) +
geom_polygon(data = group_border, aes(fill = group), alpha = 0.1, show.legend = FALSE)

##识别错误的类
library(NbClust)

nc <- NbClust(rand, distance = 'euclidean', min.nc = 2, max.nc = 10, method = 'kmeans', index = 'ccc')
plot(nc$All.index, type = 'o', col = 'blue', xlab = 'Number of clusters', ylab = 'CCC')

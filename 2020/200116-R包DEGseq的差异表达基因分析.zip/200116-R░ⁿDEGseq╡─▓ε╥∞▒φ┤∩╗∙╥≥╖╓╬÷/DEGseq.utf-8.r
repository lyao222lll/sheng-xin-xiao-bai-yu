#Bioconductor 安装 DEGseq
BiocManager::install('DEGseq')

#载入 DEGseq
library(DEGseq)

###########################
#示例数据集，详情 ?GeneExpExample5000
geneExpFile <- system.file('extdata', 'GeneExpExample5000.txt', package = 'DEGseq')
#选择子集，Kidney 样本组
geneExpMatrix1 <- readGeneExp(file = geneExpFile, geneCol = 1, valCol = c(7, 9, 12, 15, 17, 18, 20))
#选择子集，Liver 样本组
geneExpMatrix2 <- readGeneExp(file = geneExpFile, geneCol = 1, valCol = c(8, 10, 11, 13, 14, 16, 19))

#Kidney 组和 Liver 组的差异表达基因分析，详情 ?DEGexp
#自定义选择 p 值、q 值、foldchange 值等阈值，设置数据标准化方法以及模型选择等
#MARS 方法
DEGexp(geneExpMatrix1 = geneExpMatrix1, geneCol1 = 1, expCol1 = c(2, 3, 4, 5, 6), groupLabel1 = 'kidney', 
    geneExpMatrix2 = geneExpMatrix2, geneCol2 = 1, expCol2 = c(2, 3, 4, 5, 6), groupLabel2 = 'liver', 
    pValue = 1e-3, zScore = 4, qValue = 1e-3, foldChange = 4, 
    normalMethod = 'median', method = 'MARS', outputDir = './MARS_result')

#Kidney 组和 Liver 组的差异表达基因分析，详情 ?DEGexp
#自定义选择 p 值、q 值、foldchange 值等阈值，设置数据标准化方法以及模型选择等
#MATR 方法
DEGexp(geneExpMatrix1 = geneExpMatrix1, expCol1 = 2, groupLabel1 = 'kidneyR1L1',
    geneExpMatrix2 = geneExpMatrix2, expCol2 = 2, groupLabel2 = 'liverR1L2',
    replicateExpMatrix1 = geneExpMatrix1, expColR1 = 3, replicateLabel1 = 'kidneyR1L3',
    replicateExpMatrix2 = geneExpMatrix1, expColR2 = 4, replicateLabel2 = 'kidneyR1L7',
    pValue = 1e-3, zScore = 4, qValue = 1e-3, foldChange = 4,
    normalMethod = 'median', method = 'MATR', outputDir = './MATR_result')


###########################
#示例数据集，详情 ?kidneyChr21.bed 等
kidneyR1L1 <- system.file('extdata', 'kidneyChr21.bed.txt', package = 'DEGseq')
refFlat <- system.file('extdata', 'refFlatChr21.txt', package = 'DEGseq')

#这里以单样本为例，多样本时，可将同组的样本文件合并到一个向量中
mapResultBatch <- c(kidneyR1L1)
#mapResultBatch <- c(kidneyR1L1, kidneyR1L2, kidneyR1L3)

#获得 reads count 值，详情 ?getGeneExp
exp_stat <- getGeneExp(mapResultBatch, refFlat = refFlat, output = './read_count.txt')


###########################
#示例数据集，详情 ?kidneyChr21.bed 等
kidneyR1L1 <- system.file('extdata', 'kidneyChr21.bed.txt', package = 'DEGseq') 
liverR1L2 <- system.file('extdata', 'liverChr21.bed.txt', package = 'DEGseq')
refFlat <- system.file('extdata', 'refFlatChr21.txt', package = 'DEGseq')

#这里以单样本为例，多样本时，可将同组的样本文件合并到一个向量中
mapResultBatch1 <- c(kidneyR1L1)
mapResultBatch2 <- c(liverR1L2)
#mapResultBatch1 <- c(kidneyR1L1, kidneyR1L2, kidneyR1L3)
#mapResultBatch2 <- c(liverR1L1, liverR1L2, liverR1L3)

#Kidney 组和 Liver 组的差异表达基因分析，详情 ?DEGseq
#自定义选择 p 值、q 值、foldchange 值等阈值，设置数据标准化方法以及模型选择等
#LRT 方法
DEGseq(mapResultBatch1, mapResultBatch2, fileFormat = 'bed', refFlat = refFlat,
    pValue = 1e-3, zScore = 4, qValue = 1e-3, foldChange = 4,
    normalMethod = 'median', method = 'LRT', outputDir = './LRT_result')

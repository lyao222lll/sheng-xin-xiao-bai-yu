####网络全局特征指标的直接数值比较
#5 个网络的批处理，计算拓扑特征以及对应的随机网络获得
library(igraph)    #igraph 包用于网络统计

adj_file <- dir('five_network')
result <- NULL

for (file in adj_file) {
    #输入数据示例，网络邻接矩阵
    #这是一些微生物 OTU 水平的互作网络，数值 1 代表 OTU 之间有互作关系，0 代表无关联，即非加权的无向网络
    adj <- read.csv(paste('five_network', file, sep = '/'), row.names = 1, check.names = FALSE)
    
    #转为 igraph 网络邻接列表，并删除孤立节点（删除度为 0 的节点）
    g <- graph_from_adjacency_matrix(as.matrix(adj), mode = 'undirected', diag = FALSE)
    g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))
    
    #这里简单选择了选择一些网络拓扑特征做统计描述，例如
    node_num <- vcount(g)    #节点数量
    edge_num <- ecount(g)    #边的数量
    V(g)$degree <- degree(g)    #计算节点度
    average_degree <- mean(degree(g))  #节点平均度
    clustering_coefficient <- transitivity(g)    #聚类系数
    
    #通过广义随机图评估“给定网络是否是非随机驱动的”
    #首先定义图的集合
    degree_dist <- table(V(g)$degree)
    degree_num <- as.numeric(names(degree_dist))
    degree_count <- as.numeric(degree_dist)
    names(degree_count) <- degree_num
    degs <- rep(degree_num, degree_count)
    
    #1000 个随机网络及拓扑特征计算
    clustering_coefficient_rand <- clustering_coefficient
    set.seed(123)
    for (i in 1:1000) {
        g_rand <- degree.sequence.game(degs, method = 'simple')
        clustering_coefficient_rand <- c(clustering_coefficient_rand, transitivity(g_rand))
    }
    
    result <- rbind(result, c(node_num, edge_num, average_degree, clustering_coefficient, 
        mean(clustering_coefficient_rand), sd(clustering_coefficient_rand)))
}

#输出表格
result <- data.frame(result)
rownames(result) <- gsub('.csv', '', adj_file)
colnames(result) <- c('node_num', 'edge_num', 'average_degree', 'clustering_coefficient',  
    'clustering_coefficient_rand_average', 'clustering_coefficient_rand_sd')
result$clustering_coefficient_random <- paste(round(result$clustering_coefficient_rand_average, 3), 
    round(result$clustering_coefficient_rand_sd, 3), sep = '±')

result <- result[c(1:4, 7)]
result

write.table(result, 'five_network.stat.txt', sep = '\t', col.names = NA, quote = FALSE)


####Kolmogorov-Smirnov test比较各节点特征的整体分布
#定义计算函数，参考自“Agricultural intensification reduces microbial network complexity and the abundance of keystone taxa in roots”附件代码
#式中，g 是 igraph 的网络邻接列表数据结构
library(igraph)

node_char <- function(g) {
    
    #计算节点拓扑特征
    all_degree <- degree(g, mode = 'all')  #节点度
    all_betweenness <- betweenness(g, normalized = TRUE)  #节点介数中心性
    all_closeness <- closeness(g, normalized = TRUE)  #节点接近中心性
    all_transitivity <- transitivity(g, 'local', vids = V(g))  #节点连通性
    all_transitivity[is.na(all_transitivity)] <- 0
    names(all_transitivity)<- V(g)$name
    
    #Bootstrapping，10000 次自举重抽样，估计节点特征的理论分布
    set.seed(123)
    boot_degree <- replicate(10000, sample(all_degree, 1, replace = TRUE))
    boot_betweenness <- replicate(10000, sample(all_betweenness, 1, replace = TRUE))
    boot_closeness <- replicate(10000, sample(all_closeness, 1, replace = TRUE))
    boot_transitivity <- replicate(10000, sample(all_transitivity, 1, replace = TRUE))
    
    #合并数据框
    node_characterstics <- data.frame(cbind(boot_degree, boot_betweenness, boot_closeness, boot_transitivity))
    node_characterstics
}

#5 个网络的批处理
#将 5 个网络的结果数据框整合为列表数据结构便于存储
adj_file <- dir('five_network')
network_node <- list()

for (file in adj_file) {
    #输入数据示例，网络邻接矩阵
    #这是一些微生物 OTU 水平的互作网络，数值 1 代表 OTU 之间有互作关系，0 代表无关联，即非加权的无向网络
    adj <- read.csv(paste('five_network', file, sep = '/'), row.names = 1, check.names = FALSE)
    
    #转为 igraph 网络邻接列表，并删除孤立节点（删除度为 0 的节点）
    g <- graph_from_adjacency_matrix(as.matrix(adj), mode = 'undirected', diag = FALSE)
    g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))
    
    #调用上述计算函数，计算网络中节点拓扑特征并估计理论分布
    network_node[gsub('.csv', '', file)] <- list(node_char(g))
}

#所有结果统一存储在一个列表中，包含了 10000 次 bootstrap 重抽样模拟后的数值
#例如查看网络“a_net”
head(network_node[['a_net']])

#再例如初步观测所有网络的节点度分布状态
par(mfrow = c(2, 5))

for (network in names(network_node)) {
    hist(network_node[[network]][ ,'boot_degree'], xlab = 'degree', ylab = 'count', main = network)
}

for (network in names(network_node)) {
    degree_dist <- table(network_node[[network]][ ,'boot_degree'])
    degree_num <- as.numeric(names(degree_dist))
    degree_count <- as.numeric(degree_dist)
    plot(log(degree_num), log(degree_count), xlab = 'log-degree', ylab = 'log-count', main = network)
}

#两两网络之间，节点拓扑特征分布的 KS 检验
result <- NULL
num <- length(network_node)

for (i in 1:(num-1)) {
    for (j in (i+1):num) {
        
        #节点度的 KS 检验
        node_degree_i <- network_node[[i]][ ,'boot_degree']
        node_degree_j <- network_node[[j]][ ,'boot_degree']
        ks_degree <- ks.test(node_degree_i, node_degree_j, alternative = 'two.sided')
        
        #介数中心性的 KS 检验
        node_betweenness_i <- network_node[[i]][ ,'boot_betweenness']
        node_betweenness_j <- network_node[[j]][ ,'boot_betweenness']
        ks_betweenness <- ks.test(node_betweenness_i, node_betweenness_j, alternative = 'two.sided')
        
        #接近中心性的 KS 检验
        node_closeness_i <- network_node[[i]][ ,'boot_closeness']
        node_closeness_j <- network_node[[j]][ ,'boot_closeness']
        ks_closeness <- ks.test(node_closeness_i, node_closeness_j, alternative = 'two.sided')
        
        #连通度的 KS 检验
        node_transitivity_i <- network_node[[i]][ ,'boot_transitivity']
        node_transitivity_j <- network_node[[j]][ ,'boot_transitivity']
        ks_transitivity <- ks.test(node_transitivity_i, node_transitivity_j, alternative = 'two.sided')
        
        #合并统计值，均以显著性 p 值作为标准
        result <- rbind(result, c('group1' = names(network_node)[i], 'group2' = names(network_node)[j], 
            'ks_degree' = ks_degree$p.value, 'ks_betweenness' = ks_betweenness$p.value, 
            'ks_closeness' = ks_closeness$p.value, 'ks_transitivity' = ks_transitivity$p.value))
    }
}

result <- data.frame(result, stringsAsFactors = FALSE)
result$ks_degree <- as.numeric(result$ks_degree)
result$ks_betweenness <- as.numeric(result$ks_betweenness)
result$ks_closeness <- as.numeric(result$ks_closeness)
result$ks_transitivity <- as.numeric(result$ks_transitivity)
result    #这里所示的数值都是 p 值，默认 p<0.05 为显著

#输出表格
write.table(result, 'five_network.node_KStest.txt', sep = '\t', row.names = FALSE, quote = FALSE)

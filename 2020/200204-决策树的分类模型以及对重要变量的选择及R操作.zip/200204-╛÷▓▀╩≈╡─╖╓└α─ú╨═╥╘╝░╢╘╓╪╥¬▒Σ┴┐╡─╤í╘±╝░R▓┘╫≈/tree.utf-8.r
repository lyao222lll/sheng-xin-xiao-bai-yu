#威斯康星州乳腺癌数据集
breast <- read.csv('http://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data',na.strings = '?', header = FALSE)
names(breast) <- c('ID', 'clumpThickness', 'sizeUniformity', 'shapeUniformity', 'maginalAdhesion',
    'singleEpithelialCellSize', 'bareNuclei', 'blandChromatin', 'normalNucleoli', 'mitosis', 'class')

breast$class <- as.factor(breast$class)
str(breast)

#将总数据集分为训练集和测试集
set.seed(123)
select_train <- sample(699, 699*0.7)

breast_train <- breast[select_train, ]
breast_test <- breast[-select_train, ]

##经典决策树
library(rpart)

#生成树，详情 ?rpart
#~. 是使用所有变量的简写，等同于 clumpThickness+sizeUniformity+...+normalNucleoli+mitosis
#选项 method='class' 是指拟合一个分类模型，
set.seed(123)
tree <- rpart(class ~ ., data = breast_train, method = 'class', parms = list(split = 'information'))
tree

#可视化决策树
plot(tree, margin = 0.1)
text(tree, cex = 0.5)

#决策树划分细节概要，各个分支结构等
summary(tree)

#CP 表，显示了不同大小的树对应的预测误差
#names(tree)
tree$cptable

#交叉验证误差与复杂度参数的关系图
plotcp(tree)

#剪掉不重要的枝
tree_cut <- prune(tree, cp = 0.0249)
tree_cut
summary(tree_cut)

plot(tree_cut, margin = 0.1)
text(tree_cut, cex = 0.5)

#决策树可视化的其它方法，例如
library(rpart.plot)

prp(tree_cut, type = 2, extra = 104, fallen.leaves = TRUE, main = 'Decision Tree')

#训练集自身的预测
pred_train <- predict(tree_cut, breast_train, type = 'class')
tree_accuracy <- table(breast_train$class, pred_train, dnn = c('Actual', 'Predicted'))
tree_accuracy

#使用测试集样本进行评估
pred_test <- predict(tree_cut, breast_test, type = 'class')
tree_accuracy <- table(breast_test$class, pred_test, dnn = c('Actual', 'Predicted'))
tree_accuracy

##条件推断树
library(party)

#生成树，详情 ?ctree
#~. 是使用所有变量的简写，等同于 clumpThickness+sizeUniformity+...+normalNucleoli+mitosis
set.seed(123)
tree <- ctree(class~., data = breast_train)
tree

#可视化决策树
plot(tree, main = 'Conditional Inference Tree')

#训练集自身的预测
pred_train <- predict(tree, breast_train, type = 'response')
tree_accuracy <- table(breast_train$class, pred_train, dnn = c('Actual', 'Predicted'))
tree_accuracy

#使用测试集样本进行评估
pred_test <- predict(tree, breast_test, type = 'response')
tree_accuracy <- table(breast_test$class, pred_test, dnn = c('Actual', 'Predicted'))
tree_accuracy

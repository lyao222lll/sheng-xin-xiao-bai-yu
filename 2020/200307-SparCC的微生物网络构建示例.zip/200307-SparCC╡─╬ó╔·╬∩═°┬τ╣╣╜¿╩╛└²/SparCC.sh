####安装
#克隆库
hg clone https://bitbucket.org/yonatanf/sparcc

#添加环境变量（例如我将 sparcc 存放至 /home/ly/software/sparcc/）
export PATH="/home/ly/software/sparcc/:$PATH"

#添加可执行权限
chmod -R 755 /home/ly/software/sparcc/

#sparcc 需要 python2 环境支持（python3 不行）
#如果出来帮助选项就代表成功了
#若提示缺少 python 模块（numpy、pandas），额外安装下即可
SparCC.py -h

####使用
mkdir test && cd test

#第 1 步，计算观测值的相关矩阵
#SparCC.py -h
SparCC.py otu_table.txt -i 5 --cor_file=cor_sparcc.out.txt > sparcc.log

#第 2 步，通过自举抽样获得随机数据集
#MakeBootstraps.py -h
MakeBootstraps.py otu_table.txt -n 100 -t bootstrap_#.txt -p pvals/ >> sparcc.log

#第 3 步，计算伪 p 值，作为评估相关性显著的依据
#首先通过循环语句批处理，获得各随机数据集中变量的相关矩阵（随机值的相关矩阵）
for n in {0..100}; do SparCC.py pvals/bootstrap_${n}.txt -i 5 --cor_file=pvals/bootstrap_cor_${n}.txt >> sparcc.log; done

#通过观测值的相关矩阵中系数（cor0），以及随机值的相关矩阵中系数（corN），考虑 |cor0|>|corN| 的频率，获得伪 p 值（我猜的应该是这样......）
#PseudoPvals.py -h
PseudoPvals.py cor_sparcc.out.txt pvals/bootstrap_cor_#.txt 100 -o pvals/pvals.two_sided.txt -t two_sided >> sparcc.log

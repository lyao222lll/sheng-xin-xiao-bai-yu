##微生物共发生网络的自然连通度计算
#计算自然连通度
#adj_matrix 是网络邻接矩阵
nc <- function(adj_matrix) {
    #获取 0-1 矩阵，1 表示节点间存在边，0 表示不存在边
    adj_matrix <- as.matrix(adj_matrix)
    adj_matrix[abs(adj_matrix) != 0] <- 1
    
    #矩阵的特征分解，获取特征值 λ
    lambda <- eigen(adj_matrix, only.values = TRUE)$values
    lambda <- sort(lambda, decreasing = TRUE)
    
    #计算“平均特征根”，获得自然连通度
    lambda_sum <- 0
    N = length(lambda)
    for (i in 1:N) lambda_sum = lambda_sum + exp(lambda[i])
    lambda_average <- log(lambda_sum/N, base = exp(1))
    lambda_average
}

#输入数据示例，非含权的邻接矩阵
#这是一个微生物互作网络，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adj_matrix <- read.delim('adjacency_unweight.txt', row.names = 1, sep = '\t', check.names = FALSE)

#计算自然连通度
natural_connectivity <- nc(adj_matrix)
natural_connectivity

#模拟随机移除节点，就是随机在邻接矩阵中移除行和列中对应的 OTU
#示例数据共 508 个节点，就随机移除 1-400 个节点吧
set.seed(123)

for (i in 1:400) {
    
    #在邻接矩阵中随机移除 i 个节点
    remove_node <- sample(1:508, i)
    adj_matrix2 <- adj_matrix[-remove_node,-remove_node]
    
    #计算自然连通度
    natural_connectivity_remove <- nc(adj_matrix2)
    natural_connectivity <- c(natural_connectivity, natural_connectivity_remove)
}

#ggplot2 散点图+拟合线，展示随机移除节点后网络的自然连通度
library(ggplot2)

dat <- data.frame(remove_node = 0:400, natural_connectivity = natural_connectivity)
#write.csv(dat, 'dat.csv', row.names = FALSE, quote = FALSE)

ggplot(dat, aes(remove_node, natural_connectivity)) +
geom_point() +
geom_smooth(se = FALSE)

##和给定微生物网络具有相同节点和边数量的随机网络的自然连通度计算
library(igraph)

#以广义随机图为例，首先需要定义图的集合
g <- graph_from_adjacency_matrix(as.matrix(adj_matrix), mode = 'undirected', diag = FALSE)
degree_dist <- table(degree(g))
degree_num <- as.numeric(names(degree_dist))
degree_count <- as.numeric(degree_dist)
names(degree_count) <- degree_num
degs <- rep(degree_num, degree_count)

#获得广义随机图（构建 3 个），并转换为邻接矩阵
set.seed(123)
g_rand1 <- degree.sequence.game(degs, method = 'simple')
adj_matrix_rand1 <- as.matrix(get.adjacency(g_rand1))
g_rand2 <- degree.sequence.game(degs, method = 'simple')
adj_matrix_rand2 <- as.matrix(get.adjacency(g_rand2))
g_rand3 <- degree.sequence.game(degs, method = 'simple')
adj_matrix_rand3 <- as.matrix(get.adjacency(g_rand3))

#随机移除节点，并计算自然连通度
natural_connectivity_rand1 <- nc(adj_matrix_rand1)
natural_connectivity_rand2 <- nc(adj_matrix_rand2)
natural_connectivity_rand3 <- nc(adj_matrix_rand3)

for (i in 1:400) {
    
    #在邻接矩阵中随机移除 i 个节点
    remove_node <- sample(1:508, i)
    adj_matrix_rand1_remove <- adj_matrix_rand1[-remove_node,-remove_node]
    adj_matrix_rand2_remove <- adj_matrix_rand2[-remove_node,-remove_node]
    adj_matrix_rand3_remove <- adj_matrix_rand3[-remove_node,-remove_node]
    
    #计算自然连通度
    natural_connectivity_rand1 <- c(natural_connectivity_rand1, nc(adj_matrix_rand1_remove))
    natural_connectivity_rand2 <- c(natural_connectivity_rand2, nc(adj_matrix_rand2_remove))
    natural_connectivity_rand3 <- c(natural_connectivity_rand3, nc(adj_matrix_rand3_remove))
}

#ggplot2 作图，微生物网络和随机网络一起，拟合线
library(ggplot2)

dat <- data.frame(remove_node = rep(0:400, 4), 
    natural_connectivity = c(natural_connectivity, natural_connectivity_rand1, natural_connectivity_rand2, natural_connectivity_rand3), 
    network = c(rep('microbial network', 401), rep('random network 1', 401), rep('random network 2', 401), rep('random network 3', 401)))
#write.csv(dat, 'dat.csv', row.names = FALSE, quote = FALSE)

ggplot(dat, aes(remove_node, natural_connectivity, color = network)) +
geom_smooth(se = FALSE)

##来自 3 种环境的微生物网络鲁棒性评估
library(igraph)
library(ggplot2)

#读取网络邻接矩阵，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adj1 <- read.csv('s.adj.csv', row.names = 1, check.names = FALSE)
adj2 <- read.csv('r.adj.csv', row.names = 1, check.names = FALSE)
adj3 <- read.csv('e.adj.csv', row.names = 1, check.names = FALSE)

#计算自然连通度
natural_connectivity1 <- nc(adj1)
natural_connectivity2 <- nc(adj2)
natural_connectivity3 <- nc(adj3)

#转化为 igraph 邻接列表，计算节点平均度
g1 <- graph_from_adjacency_matrix(as.matrix(adj1), mode = 'undirected', diag = FALSE)
g2 <- graph_from_adjacency_matrix(as.matrix(adj2), mode = 'undirected', diag = FALSE)
g3 <- graph_from_adjacency_matrix(as.matrix(adj3), mode = 'undirected', diag = FALSE)
average_degree1 <- mean(degree(g1))
average_degree2 <- mean(degree(g2))
average_degree3 <- mean(degree(g3))

#随机移除 200 个节点，并计算上述 3 种网络特征
for (i in 1:200) {
    
    #在邻接矩阵中随机移除 i 个节点
    remove_node <- sample(1:nrow(adj1), i)
    adj1_remove <- adj1[-remove_node,-remove_node]
    remove_node <- sample(1:nrow(adj2), i)
    adj2_remove <- adj2[-remove_node,-remove_node]
    remove_node <- sample(1:nrow(adj3), i)
    adj3_remove <- adj3[-remove_node,-remove_node]
    
    #计算自然连通度
    natural_connectivity1 <- c(natural_connectivity1, nc(adj1_remove))
    natural_connectivity2 <- c(natural_connectivity2, nc(adj2_remove))
    natural_connectivity3 <- c(natural_connectivity3, nc(adj3_remove))
    
    #计算节点平均度
    g1 <- graph_from_adjacency_matrix(as.matrix(adj1_remove), mode = 'undirected', diag = FALSE)
    g2 <- graph_from_adjacency_matrix(as.matrix(adj2_remove), mode = 'undirected', diag = FALSE)
    g3 <- graph_from_adjacency_matrix(as.matrix(adj3_remove), mode = 'undirected', diag = FALSE)
    average_degree1 <- c(average_degree1, mean(degree(g1)))
    average_degree2 <- c(average_degree2, mean(degree(g2)))
    average_degree3 <- c(average_degree3, mean(degree(g3)))
}

#ggplot2 作图，拟合线
dat <- data.frame(remove_node = rep(0:200, 6), 
    variable = c(rep(c(rep('natural_connectivity', 201), rep('average_degree', 201)), 3)), 
    values = c(natural_connectivity1, average_degree1, natural_connectivity2, average_degree2, natural_connectivity3, average_degree3), 
    network = c(rep('s', 201*2), rep('r', 201*2), rep('e', 201*2)))
#write.csv(dat, 'dat.csv', row.names = FALSE, quote = FALSE)

ggplot(dat, aes(remove_node, values, color = network)) +
geom_smooth(se = FALSE) +
facet_wrap(~variable, ncol = 2, scale = 'free_y')


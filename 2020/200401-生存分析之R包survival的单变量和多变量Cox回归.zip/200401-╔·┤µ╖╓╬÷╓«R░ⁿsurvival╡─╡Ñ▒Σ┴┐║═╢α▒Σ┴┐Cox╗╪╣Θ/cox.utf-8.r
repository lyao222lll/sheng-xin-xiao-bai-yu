library(survival)

#示例数据，详情 ?lung
data(lung)
head(lung)

##单变量 Cox 回归，详情 ?coxph
#生存时间与性别（分类变量）的关系
cox_sex <- coxph(Surv(time, status) ~ sex, data = lung)
cox_sex

summary(cox_sex)

#结果提取，例如
#names(summary(cox_sex))
summary(cox_sex)$coefficients  #变量的回归系数、p 值等
summary(cox_sex)$logtest  #Likelihood ratio test 的统计量、p 值等
summary(cox_sex)$waldtest  #Wald test 的统计量、p 值等
summary(cox_sex)$sctest  #Score (logrank) test 的统计量、p 值等

#通过构建好的 Cox 回归模型执行风险预测
lung$risk_sex <- predict(cox_sex, type = 'risk')
head(lung$risk_sex)

library(ggplot2)

ggplot(lung, aes(factor(sex), risk_sex, color = factor(sex), label = risk_sex)) +
geom_point() +
scale_color_manual(values = c('blue', 'red'), limits = c('1', '2'), labels = c('male', 'female')) +
theme(panel.background = element_rect(fill = 'transparent', color = 'black'), 
    panel.grid = element_blank()) +
geom_text(vjust = -0.5, show.legend = FALSE)

#生存时间与年龄（连续变量）的关系
cox_age <- coxph(Surv(time, status) ~ age, data = lung)
cox_age

summary(cox_age)

#生存时间与年龄的散点图
ggplot(lung, aes(age, time, color = factor(status), shape = factor(status))) +
geom_point() +
scale_shape_manual(values = c(1, 16), limits = c('1', '2')) +
theme(panel.background = element_rect(fill = 'transparent', color = 'black'), 
    panel.grid = element_blank()) +
geom_smooth(method = lm, se = FALSE, show.legend = FALSE)

#通过构建好的 Cox 回归模型执行风险预测
lung$risk_age <- predict(cox_age, type = 'risk')
head(lung$risk_age)

ggplot(lung, aes(age, risk_age, color = age, shape = factor(status))) +
geom_point() +
scale_color_gradientn(colors = c('green', 'yellow', 'red')) +
scale_shape_manual(values = c(1, 16), limits = c('1', '2')) +
theme(panel.background = element_rect(fill = 'transparent', color = 'black'), 
    panel.grid = element_blank())

##多变量 Cox 回归，详情 ?coxph
#多变量时，直接在执行式中以“+”相连即可
cox2 <- coxph(Surv(time, status) ~ sex+age, data = lung)
cox2

summary(cox2)

#AIC 值获取
extractAIC(cox2)

#通过构建好的 Cox 回归模型执行风险预测
lung$risk_sex_age <- predict(cox2, type = 'risk')
head(lung$risk_sex_age)

ggplot(lung, aes(age, risk_sex_age, color = factor(sex), shape = factor(status))) +
geom_point() +
scale_color_manual(values = c('blue', 'red'), limits = c('1', '2')) +
scale_shape_manual(values = c(1, 16), limits = c('1', '2')) +
theme(panel.background = element_rect(fill = 'transparent', color = 'black'), 
    panel.grid = element_blank())

##survminer 包作图
library(survminer)

#生存曲线和累积风险曲线
KM <- survfit(Surv(time, status) ~ sex, data = lung)  #先执行一个 Kaplan-Meier 分析

ggsurvplot(KM, conf.int = TRUE, palette = c('blue', 'red'), risk.table = TRUE, pval = TRUE)
ggsurvplot(KM, conf.int = TRUE, palette = c('blue', 'red'), fun = 'cumhaz')

#森林图，详情 ?ggforest
ggforest(cox2, main = 'hazard ratio', refLabel = 'reference', noDigits = 2)


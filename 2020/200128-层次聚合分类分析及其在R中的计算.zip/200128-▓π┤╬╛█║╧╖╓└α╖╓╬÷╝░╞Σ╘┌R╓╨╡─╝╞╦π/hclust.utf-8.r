
##示例 1，基因表达数据
dat_gene <- read.delim('gene_express.txt', row.names = 1)
dat_gene <- t(dat_gene)

#常用欧几里得距离表示各样本中的基因表达相异性，可由 vegan 包 vegdist() 计算距离测度
dis_euc <- vegan::vegdist(dat_gene, method = 'euclidean')

##示例 2，物种丰度数据
dat_otu <- read.delim('otu_table.txt', row.names = 1)
dat_otu <- t(dat_otu)

#群落数据的分析中，Bray-curtis 距离是常用的距离测度类型
dis_bray <- vegan::vegdist(dat_otu, method = 'bray')

#不过考虑到某些聚类方法只能以欧式距离作为输入
#因此可以通过平方根转化的形式，将 Bray-curtis 距离转化为具有欧式几何属性的距离测度
ade4::is.euclid(dis_bray)
dis_bray_euc <- dis_bray^0.5
ade4::is.euclid(dis_bray_euc)

##此外，如果提供了现有的已经计算好的某种距离矩阵，也可直接读取
#例如，外部的 Bray-curtis 距离矩阵
dis_bray <- as.dist(read.delim('bray_distance.txt', row.names = 1))

#平方根转化，使其具有欧式几何属性
dis_bray_euc <- dis_bray^0.5

####几种层次聚类在 R 中的计算方法，均可使用 hclust() 计算

##基于连接的层次聚合分类，详情 ?hclust
#以物种丰度的 Bray-curtis 距离为例

#单连接聚合聚类，单联动
clust_single <- hclust(dis_bray, method = 'single')
summary(clust_single)

#完全连接聚合聚类，全联动
clust_complete <- hclust(dis_bray, method = 'complete')
summary(clust_complete)

#聚类树，默认效果
par(mfrow = c(1, 2))
plot(clust_single, main = 'single')
plot(clust_complete, main = 'complete')

##平均聚合聚类，详情 ?hclust
#以物种丰度的 Bray-curtis 距离为例

#使用中值的非权重成对组法，UPGMA
clust_average <- hclust(dis_bray, method = 'average')
summary(clust_average)

#使用质心的非权重成对组法，UPGMC
clust_centroid <- hclust(dis_bray, method = 'centroid')
summary(clust_centroid)

#使用中值的权重成对组法，WPGMA
clust_mcquitty <- hclust(dis_bray, method = 'mcquitty')
summary(clust_mcquitty)

#使用质心的权重成对组法，WPGMC
clust_median <- hclust(dis_bray, method = 'median')
summary(clust_median)

#聚类树，默认效果
par(mfrow = c(2, 2))
plot(clust_average, main = 'UPGMA')
plot(clust_centroid, main = 'UPGMC')
plot(clust_mcquitty, main = 'WPGMA')
plot(clust_median, main = 'WPGMC')

##Ward 最小方差聚类（包含两种不同的 Ward 聚类算法，详情 ?hclust）
#该方法中只能使用欧式几何属性的距离测度，因此更换为平方根转化后的 Bray-curtis 距离测度

#ward.D
clust_ward <- hclust(dis_bray_euc, method = 'ward.D')
summary(clust_ward)

#ward.D2
clust_ward2 <- hclust(dis_bray_euc, method = 'ward.D2')
summary(clust_ward2)

#聚类树，默认效果
par(mfrow = c(1, 2))
plot(clust_ward, main = 'ward.D')
plot(clust_ward2, main = 'ward.D2')

##灵活聚类，详情 ?agnes
#也可在该函数中通过指定 method 执行上述的多种常规聚类，如 method='average' 即为 UPGMA
#当 method='flexible' 时，par.method 参数中的 4 个值分别对应了 αh、αi、γ、β 的设定值，例如
clust_flex <- cluster::agnes(dis_bray_euc, method = 'flexible', par.method = c(0.5, 0.5, 0, 0.5))
summary(clust_flex)

plot(clust_flex)

##plot() 绘制聚类树参数简要说明，以上述 UPGMA 结果为例
#默认
plot(clust_average)

#hang 参数（默认 0.1）可用于调整标签与树高的关系，当hang < 0时，强制标签从 0 开始并对齐，如下示例
par(mfrow = c(1, 2))
plot(clust_average, hang = 0.2)
plot(clust_average, hang = -1)

#col 可定义颜色，cex 可调整标签字体大小，lwd 可调整线宽，lty 可调整线型，如下示例
plot(clust_average, col = 'red', cex = 1, lwd = 1, lty = 2)

#labels 为字符向量时可重新指定样本标签，= FALSE 时则直接隐藏样本标签，axes = FALSE 时可隐藏距离标尺，frame.plot = TRUE 时显示背景框
plot(clust_average, labels = FALSE, axes = FALSE)

#main、sub、xlab、ylab 用于修改图片标题或坐标轴标题，如下示例
plot(clust_average, main = 'UPGMA\n(Bray-curtis distance)', sub = '', xlab = 'Sample', ylab = 'Height')

#设定选择观测的聚类群数量为 4
plot(clust_average, main = 'UPGMA\nBray-curtis distance', sub = '', xlab = 'Sample', ylab = 'Height')
rect.hclust(clust_average, k = 4, border = c('red', 'blue', 'green3', 'orange'))

#vegan 包函数 reorder() 可以实现对聚类树重排，详情 ?reorder
#尽可能使聚类树内对象的排列顺序和原始相异矩阵内对象的排列顺序一致
#不过效果似乎一般
library(vegan)

par(mfrow = c(1, 2))
plot(clust_average, main = 'UPGMA\nBray-curtis distance', sub = 'before reorder', xlab = 'Sample', ylab = 'Height')
rect.hclust(clust_average, k = 4, border = c('red', 'blue', 'green3', 'orange'))
plot(reorder(clust_average, dis_bray, order = is.ordered(X)), main = 'UPGMA\nBray-curtis distance', sub = 'after reorder', xlab = 'Sample', ylab = 'Height')
rect.hclust(reorder(clust_average, dis_bray), k = 4, border = c('red', 'blue', 'green3', 'orange'))

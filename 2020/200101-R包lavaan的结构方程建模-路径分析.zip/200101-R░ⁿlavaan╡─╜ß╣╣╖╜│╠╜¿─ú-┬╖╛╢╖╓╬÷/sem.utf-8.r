#mtcars 中的变量间相关性
library(GGally)

ggcorr(mtcars[-c(5,7,9)], nbreaks = NULL, label = TRUE, low = 'red3', high = 'green3', 
	label_round = 2, name = 'Correlation Scale', label_alpha = TRUE, hjust = 0.75) + 
ggtitle(label = 'Correlation Plot') + 
theme(plot.titl = element_text(hjust = 0.6))

##结构方程模型（SEM）
#假定变量结构
model <- '
# Blue Relationship
mpg ~ hp + cyl + disp + carb + am + wt

# Green Relationship
hp ~ cyl + disp + carb
'

#执行 SEM，详情 ?sem
#这里 model 中不存在潜在变量，仅为观测变量，则该模型即为一种常规的路径分析
library(lavaan)

path <- sem(model = model, data = mtcars, se = 'bootstrap', bootstrap = 100)
summary(path, standardized = TRUE, fit.measures = TRUE, rsquare = TRUE)

#模型拟合度，详情 ?fitmeasures
fitmeasures(path, c('chisq', 'rmsea', 'cfi', 'aic'))

#展示变量间因果关系的路径图，详情 ?semPaths
#例如，连线中的数值用于反映标准化的回归系数（标准化的参数估计值）
library(semPlot)

semPaths(path, what = 'std', layout = 'tree', residuals = FALSE, edge.label.cex = 1)

#通过 MI 值评估是否需要考虑一些遗漏的变量间关系
mf <- modificationindices(path)
mf <- mf[order(mf$mi, decreasing = TRUE), ]
head(mf)

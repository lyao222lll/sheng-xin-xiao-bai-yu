#读取示例数据
dat <- read.delim('plant.txt', sep = '\t')

#通过线性回归探讨植物生长高度与其所处环境中土壤氮浓度及温度的关系
fit <- lm(plant~N+factor(temperature), data = dat)
summary(fit)  #展示拟合方程的简单统计

#单独观察植物生长高度与土壤氮浓度的关系，已知高度随氮浓度增加而增加
dat[which(dat1$temperature == 'Low'),'color'] <- 'blue'
dat[which(dat1$temperature == 'High'),'color'] <- 'red'

plot(dat$N, dat$plant, pch = 20, col = dat$color, main = 'N > plant', 
    xlab = 'N', ylab = 'plant')

#单独观察植物生长高度与温度的关系，已知低温不利于植物生长
plot(dat$temperature, dat$plant, col = c('red', 'blue'), main = 'temperature > plant', 
    xlab = 'temperature', ylab = 'plant')

#同时展示三组变量关系的三维图
library(car)

dat[which(dat$temperature == 'Low'),'temp'] <- 0  #首先将类别变量转换为 0-1 数值
dat[which(dat$temperature == 'High'),'temp'] <- 1

scatter3d(plant~N+temp, data = dat, )


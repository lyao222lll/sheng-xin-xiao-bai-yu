##cluster 包
library(cluster)

#示例数据包含 15 个样本（对象），20 个变量
dat <- read.delim('data.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
#推荐变量标准化，主要用于消除量纲差异，降低极端值比重
dat <- scale(dat)

#已知这些样本来自于 3 组数据，但不明确具体哪些样本是一组的，用来演示模糊 c 均值聚类过程
#模糊 c 均值聚类，详情 ?fanny
set.seed(123)
cm.fanny <- fanny(dat, k = 3, metric = 'euclidean', maxit = 100)
cm.fanny

#或者也可计算对象间距离，将距离作为模糊 c 均值聚类的输入，不使用原始数据
dis_euc <- vegan::vegdist(dat, method = 'euclidean')
set.seed(123)
cm.fanny <- fanny(dis_euc, k = 3, diss = TRUE, maxit = 100)
cm.fanny

#查看主要结果
names(cm.fanny)

head(cm.fanny$membership)    #对象属于某一类的程度，即成员值，行和为 1
cm.fanny$clustering    #最佳分类，即各对象最接近的聚类簇

#轮廓图
plot(silhouette(cm.fanny))

#以 PCoA 为例降维，并将聚类结果标注在排序图中
#以上述所得对象间欧几里得距离为例，计算 PCoA
pcoa <- cmdscale(dis_euc, k = (nrow(dat) - 1), eig = TRUE)
eig_prop <- 100*pcoa$eig/sum(pcoa$eig)
pcoa_site <- pcoa$point[ ,1:2]
plot(pcoa_site, 
    xlab = paste('PCoA axis1:', round(eig_prop[1], 2), '%'), 
    ylab = paste('PCoA axis2:', round(eig_prop[2], 2), '%'))

#标注各对象最接近的聚类簇
for (i in 1:3) {
    gg <- pcoa_site[cm.fanny$clustering == i, ]
    hpts <- chull(gg)
    hpts <- c(hpts, hpts[1])
    lines(gg[hpts, ], col = 1+1)
}

#星图展示了各对象的成员值
stars(cm.fanny$membership, location = pcoa_site, draw.segments = TRUE, 
    add = TRUE, scale = FALSE, col.segments = 2:4, len = 0.5)

#factoextra 包的可视化方案
library(factoextra)

#聚类和 PCA 结合，点的颜色和形状代表分组，分组椭圆展示为 95% 置信区间
fviz_cluster(cm.fanny, ellipse.type = 'norm', repel = TRUE, palette = 'jco',
    ellipse.level = 0.95, ggtheme = theme_minimal(), legend = 'right')

#轮廓图
fviz_silhouette(cm.fanny, palette = 'jco', ggtheme = theme_minimal())

##e1071 包
library(e1071)

#读取数据
dat <- read.delim('data.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
#推荐标准化，主要用于消除量纲差异，降低极端值比重
dat <- scale(dat)

#模糊 c 均值聚类，详情 ?cmeans
#期望分为 3 类，最大迭代 100 次
set.seed(123)
cm.cmeans <- cmeans(dat, centers = 3, iter.max = 100, dist = 'euclidean', method = 'cmeans')
cm.cmeans

#查看主要结果
summary(cm.cmeans)

head(cm.cmeans$membership)    #对象属于某一类的程度，即成员值，行和为 1
cm.cmeans$cluster    #最佳分类，即各对象最接近的聚类簇

#使用 corrplot 包描述对象归属的成员值
library(corrplot)
corrplot(cm.cmeans$membership, is.corr = FALSE)

#factoextra 包的可视化方案，和 PCA 结合
#点的颜色和形状代表分组，分组椭圆展示为 95% 置信区间
library(factoextra)
fviz_cluster(list(data = dat, cluster = cm.cmeans$cluster), palette = 'jco',
    ellipse.type = 'norm', ellipse.level = 0.95, ggtheme = theme_minimal())


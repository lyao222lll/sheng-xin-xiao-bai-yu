###########
#K-means

#示例数据集，该数据集实际上来自 DEGseq 包，详情可在加载 DEGseq 包后 ?GeneExpExample5000 查看
#已知的先验分组，Kidney_group=c(7, 9, 12, 15, 17, 18, 20)；Liver_group=c(8, 10, 11, 13, 14, 16, 19)
gene_express <- read.delim('GeneExpExample5000.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
reads_count <- t(gene_express[7:20])

#当变量量纲不同时，需要标准化数据使方差有意义；变量标准化还能降低极大值的影响
#本示例变量量纲一致，但如果觉得基因表达值的数量级相差过大可能导致较大离散度，可选标准化
#reads_count <- scale(reads_count)

#k-means 聚类，详情 ?kmeans
#由于 k-means 在开始时随机指定中心点，每次调用函数时可能获得不同的方案，使用 set.seed() 保证可重复性
#设定 k=2，并生成 25 种初始配置（初始中心点）并输出最好的一个
set.seed(123)
gene_kmeans <- kmeans(reads_count, centers = 2, nstart = 25)
summary(gene_kmeans)
gene_kmeans$cluster

#轮廓图评估
plot(silhouette(gene_kmeans$cluster, vegan::vegdist(reads_count, method = 'euclidean')))

#随机生成模拟数据
set.seed(123)
rand <- rbind(matrix(rnorm(150, mean = 10, sd = 0.3), ncol = 5), 
    matrix(rnorm(150, mean = 3, sd = 0.2), ncol = 5), 
    matrix(rnorm(150, mean = 1, sd = 0.1), ncol = 5), 
    matrix(rnorm(150, mean = 6, sd = 0.3), ncol = 5), 
    matrix(rnorm(150, mean = 9, sd = 0.3), ncol = 5))

#NbClust 包的最佳聚类数量评估，详情 ?NbClust
library(NbClust)
nc <- NbClust(rand, distance = 'euclidean', min.nc = 2, max.nc = 10, method = 'kmeans', index = 'hubert')
plot(nc)

#vegan 包的最佳聚类数量评估，详情 ?cascadeKM
library(vegan)
cc <- cascadeKM(rand, inf.gr = 2, sup.gr = 10, iter = 100, criterion = 'ssi')
plot(cc)

#非欧式距离的应用，如 Bray-curtis 距离
#读取距离矩阵
dis_bray <- read.delim('bray_distance.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
#平方根转化
dis <- (as.dist(dis_bray))^0.5
#PCoA
pcoa <- cmdscale(dis, k = (nrow(dis_bray) - 1), eig = TRUE)
#获取对象排序轴
site <- pcoa$point
#k-means，聚为 3 类
bray_kmeans <- kmeans(site, centers = 3, nstart = 25)
bray_kmeans$cluster

###########
#PAM

library(cluster)

#PAM 聚类，详情 ?pam
#可以输入原始数据，指定距离测度，同样以欧几里得距离为例
gene_pam <- pam(reads_count, k = 2, metric = 'euclidean')
summary(gene_pam)

#也可以首先计算距离矩阵，将距离矩阵作为输入，同样以欧几里得距离为例
dis_euc <- vegan::vegdist(reads_count, method = 'euclidean')
gene_pam <- pam(dis_euc, k = 2, diss = TRUE)
summary(gene_pam)

#可通过轮廓图评估上述分类是否可靠
plot(gene_pam)


################
#标注变异区域

#读取数据
seq_stat <- read.delim('genome_stat.txt', stringsAsFactors = FALSE)
sample1 <- read.delim('sample1_SNV.txt', stringsAsFactors = FALSE)
sample2 <- read.delim('sample2_SNV.txt', stringsAsFactors = FALSE)
sample3 <- read.delim('sample3_SNV.txt', stringsAsFactors = FALSE)
sample4 <- read.delim('sample4_SNV.txt', stringsAsFactors = FALSE)

#统计变异类型
sample_df <- function(dat) {
    dat[which(dat$change == 'A>T'|dat$change == 'T>A'),'type'] <- 1
    dat[which(dat$change == 'A>G'|dat$change == 'T>C'),'type'] <- 2
    dat[which(dat$change == 'A>C'|dat$change == 'T>G'),'type'] <- 3
    dat[which(dat$change == 'G>A'|dat$change == 'C>T'),'type'] <- 4
    dat[which(dat$change == 'G>T'|dat$change == 'C>A'),'type'] <- 5
    dat[which(dat$change == 'G>C'|dat$change == 'C>G'),'type'] <- 6
    dat[which(dat$change == 'insert'),'type'] <- 7
    dat[which(dat$change == 'delet'),'type'] <- 8
    return(dat[c(1:3, ncol(dat))])
}

sample1_df <- sample_df(sample1)
sample2_df <- sample_df(sample2)
sample3_df <- sample_df(sample3)
sample4_df <- sample_df(sample4)

##作图
library(circlize)  #圈图绘制
library(ComplexHeatmap)  #这个包绘制图例
library(grid)  #组合圈图和图例

pdf('circlize1.pdf', width = 8, height = 8)
circle_size = unit(1, 'snpc')
circos.par(gap.degree = 3, start.degree = 90)

#染色体区域
circos.genomicInitialize(seq_stat, plotType = c('axis', 'labels'), major.by = 250000, track.height = 0.05)

circos.genomicTrackPlotRegion(
    seq_stat, track.height = 0.05, stack = TRUE, bg.border = NA,
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = '#049a0b', border = NA, ...)
    } )

#sample1 SNV
color_assign <- colorRamp2(breaks = c(1, 2, 3, 4, 5, 6, 7, 8), color = c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3', 'red', 'blue'))

circos.genomicTrackPlotRegion(
    sample1_df, track.height = 0.1, stack = TRUE, bg.border = NA, 
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample1', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )
    
#sample2 SNV
circos.genomicTrackPlotRegion(
    sample2_df, track.height = 0.1, stack = TRUE, bg.border = NA, 
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample2', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#sample3 SNV
circos.genomicTrackPlotRegion(
    sample3_df, track.height = 0.1, stack = TRUE, bg.border = NA, 
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample3', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#sample4 SNV
circos.genomicTrackPlotRegion(
    sample4_df, track.height = 0.1, stack = TRUE, bg.border = NA, 
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample4', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#图例
snv_legend <- Legend(
    at = c(1, 2, 3, 4, 5, 6, 7, 8), 
    labels = c(' SNP: A>T|T>A', ' SNP: A>G|T>C', ' SNP: A>C|T>G', ' SNP: G>A|C>T', ' SNP: G>T|C>A', ' SNP: G>C|C>G', ' InDel: insert', ' InDel: delet'), 
    labels_gp = gpar(fontsize = 6), title = 'variance type', title_gp = gpar(fontsize = 7),  
    grid_height = unit(0.4, 'cm'), grid_width = unit(0.4, 'cm'), type = 'points', pch = NA, 
    background = c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3', 'red', 'blue') )

pushViewport(viewport(x = 0.5, y = 0.5))
grid.draw(snv_legend)
upViewport()

circos.clear()
dev.off()

################
#点图展示变异位点

#读取数据
seq_stat <- read.delim('genome_stat.txt', stringsAsFactors = FALSE)
sample1 <- read.delim('sample1_SNV.txt', stringsAsFactors = FALSE)
sample2 <- read.delim('sample2_SNV.txt', stringsAsFactors = FALSE)
sample3 <- read.delim('sample3_SNV.txt', stringsAsFactors = FALSE)
sample4 <- read.delim('sample4_SNV.txt', stringsAsFactors = FALSE)

#统计变异类型
sample_list <- function(dat) {
    dat <- list(dat[which(dat$change == 'A>T'|dat$change == 'T>A'), ], 
        dat[which(dat$change == 'A>G'|dat$change == 'T>C'), ], 
        dat[which(dat$change == 'A>C'|dat$change == 'T>G'), ], 
        dat[which(dat$change == 'G>A'|dat$change == 'C>T'), ], 
        dat[which(dat$change == 'G>T'|dat$change == 'C>A'), ], 
        dat[which(dat$change == 'G>C'|dat$change == 'C>G'), ], 
        dat[which(dat$change == 'insert'), ], 
        dat[which(dat$change == 'delet'), ])
    return(dat)
}

sample1_list <- sample_list(sample1)
sample2_list <- sample_list(sample2)
sample3_list <- sample_list(sample3)
sample4_list <- sample_list(sample4)

##作图
library(circlize)  #圈图绘制
library(ComplexHeatmap)  #这个包绘制图例
library(grid)  #组合圈图和图例

pdf('circlize2.pdf', width = 8, height = 8)
circle_size = unit(1, 'snpc')
circos.par(gap.degree = 3, start.degree = 90)

#染色体区域
circos.genomicInitialize(seq_stat, plotType = c('axis', 'labels'), major.by = 250000, track.height = 0.05)

circos.genomicTrackPlotRegion(
    seq_stat, track.height = 0.05, stack = TRUE, bg.border = NA,
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = '#049a0b', border = NA, ...)
    } )

#sample1 SNV
color_assign <- c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3', 'red', 'blue')

circos.genomicTrackPlotRegion(
    sample1_list, track.height = 0.12, bg.border = 'black', bg.lwd = 0.4, 
    panel.fun = function(region, value, ...) {
        circos.genomicPoints(region, value, pch = 16, cex = 0.5, col = color_assign[getI(...)], ...)
        circos.yaxis(labels.cex = 0.2, lwd = 0.1, tick.length = convert_x(0.15, 'mm'))
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample1', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )
        
#sample2 SNV
circos.genomicTrackPlotRegion(
    sample2_list, track.height = 0.12, bg.border = 'black', bg.lwd = 0.4, 
    panel.fun = function(region, value, ...) {
        circos.genomicPoints(region, value, pch = 16, cex = 0.5, col = color_assign[getI(...)], ...)
        circos.yaxis(labels.cex = 0.2, lwd = 0.1, tick.length = convert_x(0.15, 'mm'))
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample2', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#sample3 SNV
circos.genomicTrackPlotRegion(
    sample3_list, track.height = 0.12, bg.border = 'black', bg.lwd = 0.4, 
    panel.fun = function(region, value, ...) {
        circos.genomicPoints(region, value, pch = 16, cex = 0.5, col = color_assign[getI(...)], ...)
        circos.yaxis(labels.cex = 0.2, lwd = 0.1, tick.length = convert_x(0.15, 'mm'))
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample3', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#sample4 SNV
circos.genomicTrackPlotRegion(
    sample4_list, track.height = 0.12, bg.border = 'black', bg.lwd = 0.4, 
    panel.fun = function(region, value, ...) {
        circos.genomicPoints(region, value, pch = 16, cex = 0.5, col = color_assign[getI(...)], ...)
        circos.yaxis(labels.cex = 0.2, lwd = 0.1, tick.length = convert_x(0.15, 'mm'))
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample4', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#图例
snv_legend <- Legend(
    at = c(1, 2, 3, 4, 5, 6, 7, 8), 
    labels = c(' SNP: A>T|T>A', ' SNP: A>G|T>C', ' SNP: A>C|T>G', ' SNP: G>A|C>T', ' SNP: G>T|C>A', ' SNP: G>C|C>G', ' InDel: insert', ' InDel: delet'), 
    labels_gp = gpar(fontsize = 6), title = 'variance type', title_gp = gpar(fontsize = 7),  
    grid_height = unit(0.4, 'cm'), grid_width = unit(0.4, 'cm'), type = 'points', background = NA, 
    legend_gp = gpar(col = c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3', 'red', 'blue')) )

pushViewport(viewport(x = 0.5, y = 0.5))
grid.draw(snv_legend)
upViewport()

circos.clear()
dev.off()

################
#点图展示变异位点，同时标记注释类型

##预处理
#读取数据
seq_stat <- read.delim('genome_stat.txt', stringsAsFactors = FALSE)
anno <- read.delim('anno_SNV.txt', stringsAsFactors = FALSE)

#统计变异类型
change <- c('A>T|T>A', 'A>G|T>C', 'A>C|T>G', 'G>A|C>T', 'G>T|C>A', 'G>C|C>G')
type <- c('synonymous SNV', 'nonsynonymous SNV')

anno_list <- list()
length(anno_list) <- length(change) * length(type)
l = 0

for (i in change) {
    for (j in type) {
        l = l + 1
        anno_list[[l]] <- anno[which(anno$change == i & anno$type == j), ]
    }
}

##作图
library(circlize)  #圈图绘制
library(ComplexHeatmap)  #这个包绘制图例
library(grid)  #组合圈图和图例

pdf('circlize3.pdf', width = 6, height = 6)
circle_size = unit(1, 'snpc')
circos.par(gap.degree = 3, start.degree = 90)

#染色体区域
circos.genomicInitialize(seq_stat, plotType = c('axis', 'labels'), major.by = 250000, track.height = 0.05)

circos.genomicTrackPlotRegion(
    seq_stat, track.height = 0.05, stack = TRUE, bg.border = NA,
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = '#049a0b', border = NA, ...)
    } )

#SNP 位点
color_assign <- c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3')
pch_assign <- c(16, 1)

circos.genomicTrackPlotRegion(
    anno_list, track.height = 0.2, bg.border = 'black', bg.lwd = 0.4, 
    panel.fun = function(region, value, ...) {
        n = getI(...)
        circos.genomicPoints(region, value, pch = pch_assign[ifelse(n%%2, n%%2, 2)], cex = 0.5, col = color_assign[ifelse(n%%6, n%%6, 6)], ...)
        circos.yaxis(labels.cex = 0.2, lwd = 0.1, tick.length = convert_x(0.15, 'mm'))
        xlim = CELL_META$xlim
        ylim = CELL_META$ylim
        circos.text(mean(xlim), mean(ylim), 'sample', cex = 0.7, col = 'black', facing = 'inside', niceFacing = TRUE)
    } )

#图例
snv_legend <- Legend(
    at = c(1, 2, 3, 4, 5, 6, 7, 8), 
    labels = c(' SNP: A>T|T>A', ' SNP: A>G|T>C', ' SNP: A>C|T>G', ' SNP: G>A|C>T', ' SNP: G>T|C>A', ' SNP: G>C|C>G', 'synonymous SNV', 'nonsynonymous SNV'), 
    labels_gp = gpar(fontsize = 5), title = 'variance type\n', title_gp = gpar(fontsize = 6),  
    grid_height = unit(0.4, 'cm'), grid_width = unit(0.4, 'cm'), type = 'points', background = NA, 
    legend_gp = gpar(col = c('#BC80BD', '#FDB462', '#80B1D3', '#FB8072', '#8DD3C7', '#FFFFB3', 'gray', 'gray')), 
    pch = c(20, 20, 20, 20, 20, 20, 16, 1) )

pushViewport(viewport(x = 0.5, y = 0.5))
grid.draw(snv_legend)
upViewport()

circos.clear()
dev.off()

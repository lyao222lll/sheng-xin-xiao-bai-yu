#安装，需要 python2 环境（python3 不支持）
git clone https://bitbucket.org/charade/elsa.git
cd elsa
python setup.py install

#过程中若有提示缺失的 python 模块，额外手动配置下
#完毕后，正常显示帮助就可以了
lsa_compute -h

#运行 LSA
#查看命令帮助
lsa_compute -h

#一个简单运行示例
lsa_compute test/ARISA20.txt test/ARISA20.lsa.txt \
    -s 127 -r 1 \
    -d 3 -m 0 \
    -p perm -x 1000 \
    -n percentileZ -f none
    

##读取及处理 LSA 结果
lsa <- read.delim('ARISA20.lsa.txt', sep = '\t', stringsAsFactors = FALSE)

#数值筛选，例如去除 p>0.05 的值
lsa <- subset(lsa, P <= 0.05)

#输出邻接矩阵
write.table(lsa, 'ARISA20.lsa.select.txt', row.names = FALSE, sep = '\t', quote = FALSE)

#转化为网络邻接矩阵，值显示为局部相似性（LS）
lsa <- lsa[c('X', 'Y', 'LS')]
lsa <- reshape2::dcast(lsa, X~Y, fill = 0)

#输出邻接矩阵
write.table(data.frame(lsa, check.names = FALSE), 'ARISA20.lsa.select.adj_matrix.txt', 
    row.names = FALSE, sep = '\t', quote = FALSE)

##igraph 包的网络格式转换
library(igraph)

#输入数据，邻接矩阵
network_adj <- read.delim('ARISA20.lsa.select.adj_matrix.txt', row.names = 1, sep = '\t', check.names = FALSE)
head(network_adj)[1:6]    #邻接矩阵类型的网络文件

#邻接矩阵 -> igraph 的邻接列表，获得含权的无向网络
g <- graph_from_adjacency_matrix(as.matrix(network_adj), mode = 'undirected', weighted = TRUE, diag = FALSE)
g    #igraph 的邻接列表

#这种转换模式下，默认的边权重代表了 LSA 的局部相似性（LS） ，会存在负值
#由于边权重通常为正值，因此最好取个绝对值，LS 值重新复制一列作为记录
E(g)$LS <- E(g)$weight
E(g)$weight <- abs(E(g)$weight)

#网络图简图
plot(g)

#不推荐用 R 进行网络可视化，推荐将邻接列表转化为其它类型，并后续使用 Cytoscape、Gephi 等软件可视化网络

#再转为其它类型的网络文件，例如
#再由 igraph 的邻接列表转换回邻接矩阵
adj_matrix <- as.matrix(get.adjacency(g, attr = 'LS'))
write.table(data.frame(adj_matrix, check.names = FALSE), 'network.adj_matrix.txt', col.names = NA, sep = '\t', quote = FALSE)

#graphml 格式，可使用 gephi 软件打开并进行可视化编辑
write.graph(g, 'network.graphml', format = 'graphml')

#gml 格式，可使用 cytoscape 软件打开并进行可视化编辑
write.graph(g, 'network.gml', format = 'gml')

#边列表，也可以直接导入至 gephi 或 cytoscape 等网络可视化软件中进行编辑
edge <- data.frame(as_edgelist(g))

edge_list <- data.frame(
    source = edge[[1]],
    target = edge[[2]],
    weight = E(g)$weight,
    LS = E(g)$LS
)
head(edge_list)

write.table(edge_list, 'network.edge_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#节点属性列表，对应边列表，记录节点属性，例如
node_list <- data.frame(
    id = V(g)$name,    #节点名称
    label = V(g)$name,    #节点名称
    degree = degree(g)    #节点度
)
head(node_list)

write.table(node_list, 'network.node_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)


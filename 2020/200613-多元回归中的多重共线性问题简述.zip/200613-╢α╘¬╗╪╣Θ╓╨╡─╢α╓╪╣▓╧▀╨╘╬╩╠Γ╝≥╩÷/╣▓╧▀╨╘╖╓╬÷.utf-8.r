#鱼类数据
#数据描述及过程详情，见前文“多元线性回归”
#或者见前文“多元回归中常见的变量选择”

#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#使用全部 6 个环境变量拟合与鱼类物种丰度的多元线性回归
fit1 <- lm(fish~acre+do2+depth+no3+so4+temp, data = dat)
summary(fit1)  #展示拟合回归的简单统计

#变量选择后，只保留了 3 个有显著效应的环境变量，改进后的多元线性回归
fit2 <- lm(fish~acre+depth+no3, data = dat)
summary(fit2)  #展示拟合回归的简单统计

#绘制相关图观测各环境变量间的相关性
library(GGally)

ggpairs(dat[which(names(dat) != 'fish')])

#条件图，以鱼类物种丰度、流域面积和水深的关系为例
#详情参考 ?coplot
given <- co.intervals(dat$depth, number = 4, overlap = 0.1)
coplot(fish~acre|depth, data = dat, given.v = given, 
    rows = 1, panel = panel.smooth)

#查看回归模型中各预测变量的方差膨胀因子（VIF）
#前后两个回归模型都来看一下
library(car)

vif(fit1)  #包含全部 6 个环境变量的回归
vif(fit2)  #变量选择优化后，只包含 3 个环境变量回归

#######
#甲虫数据
#数据描述及过程详情，见前文“回归中自变量的交互效应”

#读取示例数据
dat_beetles <- read.delim('beetles.txt', sep = '\t')

#通过二元线性回归拟合甲虫捕食频率与周围猎物数量和气温的关系
#这里先不考虑二者的交互效应
fit3 <- lm(attack_rate~prey_num+temperature, data = dat_beetles)
summary(fit3)  #展示拟合回归的简单统计

#但可以看到猎物数量和气温存在较强共线性问题
plot(dat_beetles$temperature, dat_beetles$prey_num, pch = 20, 
    xlab = 'temperature', ylab = 'prey number')

#单独解释甲虫捕食频率与周围猎物数量关系
fit4 <- lm(attack_rate~prey_num, data = dat_beetles)
summary(fit4)  #展示拟合回归的简单统计

plot(dat_beetles$prey_num, dat_beetles$attack_rate, pch = 20, 
    xlab = 'prey number', ylab = 'attack rates')
abline(fit4)

#单独解释甲虫捕食频率与气温的关系
fit5 <- lm(attack_rate~temperature, data = dat_beetles)
summary(fit5)  #展示拟合回归的简单统计

plot(dat_beetles$temperature, dat_beetles$attack_rate, pch = 20, 
    xlab = 'temperature', ylab = 'attack rates')
abline(fit5)

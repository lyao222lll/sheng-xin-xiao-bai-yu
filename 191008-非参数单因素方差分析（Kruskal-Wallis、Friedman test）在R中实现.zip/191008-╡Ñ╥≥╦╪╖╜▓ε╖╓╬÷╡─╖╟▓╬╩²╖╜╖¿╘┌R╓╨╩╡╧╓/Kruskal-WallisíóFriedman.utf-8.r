#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##单因素方差分析的非参数检验替代方法
#假设样本采自三种土壤环境（A、B、C），我们比较三种土壤环境下的细菌群落的 chao1 指数是否存在显著差异

#以 chao1 指数为例，同时将分组列转换为因子变量
chao1 <- soil[ ,c('sample', 'site', 'chao1')]
chao1$site <- factor(chao1$site)

#当数据不满足单因素方差分析的条件（正态性、方差齐性）时，尝试非参数的方法，例如
#Kruskal-Wallis Test
kruskal.test(chao1~site, data = chao1)

#若想查看各组中位数、极大（小）值、（四）分位数，可使用 aggregate()
aggregate(chao1$chao1, by = list(chao1$site), FUN = max)
aggregate(chao1$chao1, by = list(chao1$site), FUN = function(x) quantile(x, 0.75))
aggregate(chao1$chao1, by = list(chao1$site), FUN = median)
aggregate(chao1$chao1, by = list(chao1$site), FUN = function(x) quantile(x, 0.25))
aggregate(chao1$chao1, by = list(chao1$site), FUN = min)

#如果各组不独立（如重复测量设计或随机区组设计），那么 Friedman Test 可能会更合适
#这里以 ?friedman.test 中的示例为例
wb <- aggregate(warpbreaks$breaks, by = list(w = warpbreaks$wool, t = warpbreaks$tension), FUN = mean)
friedman.test(x ~ w | t, data = wb)

##此时若想继续探寻两两分组间的差异，可使用 Wilcoxon 秩和检验，如果分组较多，可以使用循环来完成
#继续在上述 Kruskal-Wallis 检验的基础上，探究两两分组间差异，一个示例如下
group <- levels(chao1$site)
group1 <- NULL
group2 <- NULL
median1 <- NULL
median2 <- NULL
p <- NULL

for (i in 1:(length(group) - 1)) {
	for (j in (i + 1):length(group)) {
		group1 <- c(group1, group[i])
		group2 <- c(group2, group[j])
		group_ij <- subset(chao1, site %in% c(group[i], group[j]))
		group_ij$site <- factor(group_ij$site, levels = c(group[i], group[j]))
		
		wilcox_test <- wilcox.test(chao1~site, data = group_ij, alternative = 'two.sided', conf.level = 0.95)
		p <- c(p, wilcox_test$p.value)
		median1 <- c(median1, median(subset(group_ij, site == group[i])$chao1))
		median2 <- c(median2, median(subset(group_ij, site == group[j])$chao1))
	}
}

result <- data.frame(group1, group2, median1, median2, p)
result$padj <- p.adjust(result$p, method = 'BH')	#推荐加上 p 值校正，这里使用 Benjamini 方法校正 p 值
result
#write.table(result, 'Wilcoxon.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#使用 ggpubr（ggplot2 的扩展包），作图展示 wilcox 比较的结果
library(ggpubr)

ggboxplot(data = chao1, x = 'site', y = 'chao1', color = 'site') +
stat_compare_means(method = 'wilcox.test', comparisons = list(c('A', 'B'), c('A', 'C'), c('B', 'C')))

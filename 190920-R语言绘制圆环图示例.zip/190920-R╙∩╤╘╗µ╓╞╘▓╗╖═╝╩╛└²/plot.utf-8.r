library(reshape2)
library(ggplot2)

#读取数据，按总丰度大小排序，并重排为便于 ggplot2 识别的样式
phylum <- read.delim('phylum_top10.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
phylum <- phylum[order(rowSums(phylum[-1])), ]
phylum$Taxonomy <- factor(phylum$Taxonomy, levels = c('Others', as.vector(phylum$Taxonomy[-which(phylum$Taxonomy == 'Others')])))
time_all <- melt(phylum, id = 'Taxonomy')

#挑选其中的一个样本，并按丰度大小排序
time1 <- subset(time_all, variable == 'time1')
time1 <- time1[order(time1$value), ]
time1$Taxonomy <- factor(time1$Taxonomy, levels = c('Others', as.vector(time1$Taxonomy[-which(time1$Taxonomy == 'Others')])))

##以 time1 为例作图展示
#先得到柱形图
p <- ggplot(time1, aes(x = Taxonomy, y = value, fill = Taxonomy)) + 
geom_bar(stat = 'identity', width = 1) +
scale_fill_manual(values = c('gray', '#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text = element_blank(), axis.ticks = element_blank(), plot.title = element_text(hjust = 0.5)) +
labs(x = '', y = '', title = 'Time1', fill = 'Top10 Phylum')

#再经坐标系变换得到圆环图
p + coord_polar(theta = 'y')


##以 time_all 为例
#先得到柱形图
p <- ggplot(time_all, aes(variable, value, fill = Taxonomy)) +
geom_bar(stat = 'identity', width = 0.8) +
scale_fill_manual(values = c('gray', '#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5')) +
labs(x = '', y = '', fill = 'Top10 Phylum') +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank())

#再经坐标系变换得到圆环图
p + coord_polar(theta = 'y') 


##绘制饼图时，若展示为空心的“饼环”样式，则也可视为一种圆环图，以 time1 为例作图展示
#饼图
p1 <- ggplot(time1, aes(x = '', y = value, fill = Taxonomy)) + 
geom_bar(stat = 'identity', width = 1) +
coord_polar(theta = 'y') +
scale_fill_manual(values = c('gray', '#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank(), plot.title = element_text(hjust = 0.5)) +
labs(x = '', y = '', title = 'Time1', fill = 'Top10 Phylum')

p1

#可通过设置 geom_bar() 中 width 参数的大小（小于 1 即可，数值越小空心面积越大）后，转化为饼图后即可得到圆环图
p2 <- ggplot(time1, aes(x = '', y = value, fill = Taxonomy)) + 
geom_bar(stat = 'identity', width = 0.3) + 
coord_polar(theta = 'y') +
scale_fill_manual(values = c('gray', '#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank(), plot.title = element_text(hjust = 0.5)) +
labs(x = '', y = '', title = 'Time1', fill = 'Top10 Phylum')

p2
##vegan 包 vegdist() 计算群落相似性/距离，详情 ?vegdist
#以下相似度（S）和距离测度（D）的转换公式，均使用 S = 1-D
library(vegan)

#读入物种数据
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t')
otu <- t(otu)

#jaccard 相异度
jacc_dis <- vegdist(otu, method = 'jaccard', binary = TRUE)
#jaccard 相似度
jacc_sim <- 1 - jacc_dis

#欧几里得距离
eucl_dis <- vegdist(otu, method = 'euclidean')
#这种距离转换为相似性时，需要首先作个标准化，例如
eucl_dis_norm <- eucl_dis/max(eucl_dis)
eucl_sim <- 1 - eucl_dis_norm

#弦距离
otu_chord <- decostand(otu, method = 'normalize')
chord_dis <- vegdist(otu_chord, method = 'euclidean')

#Hellinger 距离
otu_hell <- decostand(otu, method = 'hellinger')
hell_dis <- vegdist(otu_hell, method = 'euclidean')

#卡方距离
#先做卡方标准化，再计算欧几里得距离，即可得
otu_chi <- decostand(otu, method = 'chi.square')
otu_chi_dis <- vegdist(otu_chi, 'euclidean')

#Bray-curtis 距离
bray_dis <- vegdist(otu, method = 'bray')
#Bray-curtis 相似度
bray_sim <- 1 - bray_dis

#更多示例不再展示了
#以上结果均为 dis 类型，若要输出在本地，需要首先转化为 matrix 类型
#以 Bray-curtis 距离为例
bray <- as.matrix(bray_dis)
write.table(bray, 'bray-curtis_distance.txt', col.names = NA, sep = '\t', quote = FALSE)

#距离矩阵热图
heatmap(bray, scale = 'none', RowSideColors = rep(c('red', 'blue'), each = 18), ColSideColors = rep(c('red', 'blue'), each = 18))

##phyloseq 包 distance() 计算群落相似性/距离，详情查看 ?distance
library(phyloseq)

#读入物种数据
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t')
#读入进化树文件（这里为有根树）
tree <- read_tree('otu_tree.tre')
#不过师兄说无根树也可以，只是每次计算的 UUF 和 WUF 会不一样，他会随机指定根

#首先构建 phyloseq 对象
physeq <- phyloseq(otu_table(otu, taxa_are_rows = TRUE), phy_tree(tree))

#计算加权 Unifrac 距离
wei_unif_dis <- distance(physeq, method = 'wunifrac')
#计算非加权 Unifrac 距离
unwei_unif_dis <- distance(physeq, method = 'unifrac')

#也可用其计算其它类型距离，如 Bray-curtis 距离
bray_dis <- distance(physeq, method = 'bray')

#更多示例不再展示了
#注：vegan 包 vegdist() 中的 method 参数同样适用 phyloseq 包 distance() 中的 method 参数

#以上结果均为 dis 类型，若要输出在本地，需要首先转化为 matrix 或类型
#以加权 Unifrac 距离为例
wei_unif <- as.matrix(wei_unif_dis)
write.table(wei_unif, 'weighted-unifrac_distance.txt', col.names = NA, sep = '\t', quote = FALSE)

##GUniFrac 包 GUniFrac() 计算微生物群落的 Unifrac 距离，详情查看 ?GUniFrac
library(GUniFrac)

#读入物种数据
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t')
otu <- data.frame(t(otu))
#读入进化树文件（这个只能使用有根树）
tree <- read.tree('otu_tree.tre')

#计算加权 Unifrac 距离
unifrac <- GUniFrac(otu, tree)$unifracs
wei_unif_dis <- as.dist(unifrac[, , 'd_1'])	
#计算非加权 Unifrac 距离
unwei_unif_dis <- as.dist(unifrac[, , 'd_UW'])

#以上结果均为 dis 类型，若要输出在本地，需要首先转化为 matrix 或类型
#以非加权 Unifrac 距离为例
unwei_unif <- as.matrix(unwei_unif_dis)
write.table(unwei_unif, 'unweighted-unifrac_distance.txt', col.names = NA, sep = '\t', quote = FALSE)

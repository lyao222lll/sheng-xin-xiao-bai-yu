library(ade4)

#查看帮助文档
?dudi.fpca
#或者
?dudi.fca

#二者弹出的是同一篇文档，作者将两个命令放在一起介绍了

data(bsetal97)
w <- prep.fuzzy.var(bsetal97$biol, bsetal97$biol.blo)

#注：FPCA 或 FCA 前，缺失值需要首先全部转为 0
#FPCA
fpca <- dudi.fpca(w, scann = FALSE, nf = 3)
#FCA
fca <- dudi.fca(w, scann = FALSE, nf = 3)

#概要，以 FPCA 为例
fpca
summary(fpca)

##提取主要内容，以 FPCA 为例
#查看特征值（显示前 4 轴）
fpca$eig[1:4]
#查看排序轴解释量（%，显示前 4 轴）
round(fpca$eig / sum(fpca$eig) * 100, 2)[1:4]

#对象和变量坐标
#上述 dudi.fpca() 中，参数 nf = 3，故默认显示了前三个排序轴
head(fpca$li)
head(fpca$co)

#断棍模型评估各轴特征值
fpca_eig <- fpca$eig
n <- length(fpca_eig)
bsm <- data.frame(j=seq(1:n), p = 0)
bsm$p[1] <- 1/n
for (i in 2:n) bsm$p[i] <- bsm$p[i-1] + (1/(n + 1 - i))
bsm$p <- 100*bsm$p/n

barplot(t(cbind(100 * fpca_eig/sum(fpca_eig), bsm$p[n:1])), beside = TRUE, main = '% 变差', col = c('orange', 'bisque'), las = 2)
abline(h = mean(100 * fpca_eig/sum(fpca_eig)), col = 'red')
legend('topright', c('% 特征根', '断棍模型', '平均特征根'), pch = c(15, 15, NA), col = c('orange', 'bisque', 'red'), lwd = c(NA, NA, 1), bty = 'n')

#scatter() 可视化
scatter(fpca, csub = 3, clab.moda = 1.5)
scatter(fca, csub = 3, clab.moda = 1.5)
library(vegan)
library(ade4)

a <- t(read.delim('species.txt', row.names = 1))

# "manhattan", "euclidean", "canberra", "bray", "kulczynski", "jaccard", "gower", "altGower", "morisita", "horn", "mountford", "raup" , "binomial", "chao", "cao" or "mahalanobis"

b <- vegdist(a, 'chi.square')
b <- decostand(a, method = 'chi.square')
vegdist(b, 'euclidean')

a <- data.frame(a=c(0,1,0), b = c(1, 0, 4), c = c(1, 0, 4))

d = 0
for (i in 1:ncol(a)) {
	d = d + (1/(sum(a[ ,i])/sum(a)))*(a[1,i]/sum(a[1, ]) - a[3,i]/sum(a[3, ]))^2
}
d^0.5

a = a/rowSums(a)
q = 0
for (i in 1:10) q = q + (a[1,i] - a[2,i])^2 / (sum(a[ ,i])/sum(a))
q^0.5

##常规 RDA 的变差分解
#数据的网盘链接：https://pan.baidu.com/s/18xTqAZPa2Al2sDQpS1ysFA

#读取物种数据，细菌门水平丰度表
phylum <- read.delim('phylum_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
#推荐在对纯物种多度数据执行 PCA、RDA 等线性排序方法前，执行 Hellinger 转化
phylum_hel <- decostand(phylum, method = 'hellinger')

#读取环境变量
env <- read.delim('env_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

library(vegan)

#运行变差分解，详情 ?vegdist
#以两组（pH 为一组，5 种碳氮磷钾指标为另一组）环境变量为例
rda_vp <- varpart(phylum_hel, env['pH'], env[c('DOC', 'SOM', 'AP', 'AK', 'NH4')])
rda_vp

plot(rda_vp, digits = 2, Xnames = c('pH', 'CNPK'), bg = c('blue', 'red'))

#再以四组为例，碳、氮、磷、钾指标间比较
rda_vp <- varpart(phylum_hel, env[c('DOC', 'SOM')], env['NH4'], env['AP'], env['AK'])
rda_vp

plot(rda_vp, digits = 2, Xnames = c('C', 'N', 'P', 'K'), bg = c('blue', 'red', 'green', 'yellow'))


#结合前文 RDA 中的示例分析
#查看前向选择中被剔除的环境变量“TC”，与这 6 个被保留的环境变量之间解释变差的“共享程度”
rda_vp <- varpart(phylum_hel, env['TC'], env[c('pH', 'DOC', 'SOM', 'AP', 'AK', 'NH4')])
plot(rda_vp, digits = 2, Xnames = c('TC', 'forward_env'), bg = c('blue', 'red'))

##置换检验确定解释变差的显著性
#需结合 RDA 执行式，vegan 中为 rda()

#解释变差的置换检验，以 pH 所能解释的全部变差为例；999 次置换，详情 ?anova.cca
anova.cca(rda(phylum_hel, env['pH']), permutations = 999)

#若考虑 pH 单独解释的变差部分，需将其它变量作为协变量；999 次置换
anova.cca(rda(phylum_hel, env['pH'], env[c('DOC', 'SOM', 'AP', 'AK', 'NH4')]), permutations = 999)

#############################
##db-RDA 的变差分解
#数据的网盘链接：https://pan.baidu.com/s/1itLEWnV_sLpKohHleMwggA

#读入物种数据，以细菌 OTU 水平丰度表为例
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu <- data.frame(t(otu))

#读取环境数据
env <- read.delim('env_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#计算样方距离，以 Bray-curtis 距离为例，详情 ?vegdist
dis_bray <- vegdist(otu, method = 'bray')
#或者直接使用已准备好的距离矩阵，网盘中同样提供了已计算好的 Bray-curtis 距离矩阵
dis_bray <- as.dist(read.delim('bray_distance.txt', row.names = 1, sep = '\t', check.names = FALSE))

library(vegan)

#以两组环境变量（DOC、AP+AK）为例，运行变差分解，详情 ?varpart
#输入 varpart() 的为已经计算好的 Bray-curtis 距离测度
#参数 add=T 意为校正 PCoA 的负特征根，这个最好和 db-RDA 执行式保持一致（即二者要么都校正，要么都不校正）
db_rda_vp <- varpart(dis_bray, env['DOC'], env[c('AP', 'AK')], add = TRUE)
db_rda_vp

plot(db_rda_vp, digits = 2, Xnames = c('DOC', 'AP+AK'), bg = c('blue', 'red'))

##置换检验确定解释变差的显著性
#需结合 db-RDA 执行式，vegan 中提供了 capscale()、dbrda() 等函数可直接执行 db-RDA
#下式均以 capscale() 为例

#解释变差的置换检验，以 DOC 所能解释的全部变差为例；999 次置换
anova.cca(capscale(dis_bray~DOC, env, add = TRUE), permutations = 999)

#若考虑 DOC 单独解释的变差部分，需将其它变量作为协变量；999 次置换
anova.cca(capscale(dis_bray~DOC+Condition(AP+AK), env, add = TRUE), permutations = 999)

#############################
##CCA 的变差分解
#数据的网盘链接：https://pan.baidu.com/s/1UWlvIUWrnl4gyoEhpCGVtw

#读入物种数据，以细菌 OTU 水平丰度表为例
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu <- data.frame(t(otu))

#读取环境数据
env <- read.delim('env_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

library(vegan)

#以两组环境变量（DOC、AP+AK）为例，运行变差分解，详情 ?varpart
#参数 chisquare = TRUE，执行 CCA 的变差分解；默认情况下 chisquare = FALSE，即执行 RDA 的变差分解
#注：如果 varpart() 不支持 CCA，请更新 R 版本（如 R3.6 的 vegan）
cca_vp <- varpart(otu, env['DOC'], env[c('AP', 'AK')], chisquare = TRUE)
cca_vp

plot(cca_vp, digits = 2, Xnames = c('DOC', 'AP+AK'), bg = c('blue', 'red'))

##置换检验确定解释变差的显著性
#需结合 CCA 执行式，vegan 中为 cca()

#解释变差的置换检验，以 DOC 所能解释的全部变差为例；999 次置换
anova.cca(cca(otu~DOC, env), permutations = 999)

#若考虑 DOC 单独解释的变差部分，需将其它变量作为协变量；999 次置换
anova.cca(cca(otu~DOC+Condition(AP+AK), env), permutations = 999)

#bioconductor 安装 omicade4 包
BiocManager::install('omicade4')

#加载 omicade4 包，omicade4 以 ade4 为基础（调用 ade4 的函数）
library(omicade4)

#数据集
#详情 https://www.rdocumentation.org/packages/omicade4/versions/1.12.0/topics/NCI60_4arrays
data(NCI60_4arrays)
sapply(NCI60_4arrays, dim)
summary(NCI60_4arrays)

#行为细胞系名称，列为基因id
head(NCI60_4arrays$agilent[1:6])	#Agilent platform.
head(NCI60_4arrays$hgu133[1:6])	#H-GU133 platform
head(NCI60_4arrays$hgu133p2[1:6])	#H-GU133 plus 2.0 platform
head(NCI60_4arrays$hgu95[1:6])	#H-GU95 platform

#层次聚类分析评估各数据集中的各细胞系基因表达谱的相似性
layout(matrix(1:4, 1, 4))
par(mar = c(2, 1, 0.1, 6))
for (df in NCI60_4arrays) {
	d <- dist(t(df))
	hcl <- hclust(d)
	dend <- as.dendrogram(hcl)
	plot(dend, horiz = TRUE)
}

#执行 MCoIA，详情 ?mcia
mcoin <- mcia(NCI60_4arrays, cia.nf = 4, cia.scan = FALSE, nsc = TRUE)
mcoin

summary(mcoin)
mcoin$mcoa

#提取主要结果，例如
names(mcoin$mcoa)

#MCoIA 的伪特征值，代表了各 MCoIA 轴承载的协惯量
mcoin$mcoa$pseudoeig
#RV 值，代表了各数据集结构的一致性
mcoin$mcoa$RV

#作图观测，以观测 MCoIA 前两轴的特征为例
#图中对象（细胞系样本）的颜色，根据其所属的癌症类型着色
cancer_type <- colnames(NCI60_4arrays$agilent)
cancer_type <- sapply(strsplit(cancer_type, split="\\."), function(x) x[1])
cancer_type

plot(mcoin, axes = 1:2, phenovec = cancer_type, sample.lab = FALSE, df.color = 1:4)

#根据坐标提取变量
#结果中，TRUE 代表数据集中存在该变量，FALSE 则不存在，最后一列为 TRUE 的总数
melan_gene <- selectVar(mcoin, a1.lim = c(2, Inf), a2.lim = c(-Inf, Inf))
melan_gene

#变量在代表各数据集特征轴中的初始投影
#以前两轴为例展示，var 可指定感兴趣的变量特别注明，详情 ?plotVar
geneStat <- plotVar(mcoin, axes = 1:2, var = melan_gene$var, var.lab = TRUE)

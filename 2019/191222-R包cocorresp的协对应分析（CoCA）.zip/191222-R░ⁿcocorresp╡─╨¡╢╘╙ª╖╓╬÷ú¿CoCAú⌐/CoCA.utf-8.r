library(cocorresp)

##数据集。详情 ?beetles、?plants
data(beetles)
data(plants)

#为了使甲虫数据集更加均一并具有稳定的方差，进行对数转换
beetles <- log(beetles + 1)

##对称 CoCA，详情 ?coca

#直接输入两数据矩阵，method = 'symmetric' 意为执行对称 CoCA，此时 y 和 x 的顺序无关紧要
bp.sym <- coca(y = beetles, x = plants, method = 'symmetric')

#或者通过公式指定变量，这里“~.”代表使用 plants 全部的物种变量
bp.sym <- coca(beetles ~ ., data = plants, method = 'symmetric')

bp.sym
summary(bp.sym)

#提取主要信息，例如
#names(bp.sym)
bp.sym$scores$site$X  #数据集 X 的对象在 CoCA 轴上的得分（坐标）
bp.sym$scores$species$X  #据集 X 的变量在 CoCA 轴上的得分（坐标）
bp.sym$scores$site$Y  #数据集 Y 的对象在 CoCA 轴上的得分（坐标）
bp.sym$scores$species$Y  #据集 Y 的变量在 CoCA 轴上的得分（坐标）
bp.sym$lambda  #各 CoCA 轴的特征值

#通过特征值散点图，可以看到前 2-3 轴承载了绝大部分的协惯量
screeplot(bp.sym)

#获取甲虫和植物在 CoCA 轴上得分的相关性，可知它们之间是高度相关的
corAxis(bp.sym)

#绘制双序图，观测前两轴中，两个数据集的对象（样方）和变量（物种）关系
#y1 表示数据集 Y（本示例为 beetles），y2 表示数据集 X（本示例为 plants）
layout(matrix(1:2, ncol = 2))
biplot(bp.sym, which = 'y1', main = 'Beetles', type = 'text', choices = 1:2)
biplot(bp.sym, which = 'y2', main = 'Plants', type = 'text', choices = 1:2)

##非对称 CoCA，详情 ?coca

#直接输入两数据矩阵，method = 'predictive' 意为执行模型 CoCA，此时 y 代表响应变量，x 代表预测变量
#reg.method 参数用于指定使用的模型
bp.pred <- coca(y = beetles, x = plants, method = 'predictive', reg.method = 'simpls')

#或者通过公式指定变量，这里“~.”代表使用 plants 全部的物种变量预测 beetles 的物种
bp.pred <- coca(beetles ~ ., data = plants, method = 'predictive', reg.method = 'simpls')

bp.pred
summary(bp.pred)

#提取主要信息，例如
#names(bp.pred)
bp.pred$scores$site$X  #数据集 X 的对象在 CoCA 轴上的得分（坐标）
bp.pred$scores$species$X  #据集 X 的变量在 CoCA 轴上的得分（坐标）
bp.pred$scores$site$Y  #数据集 Y 的对象在 CoCA 轴上的得分（坐标）
bp.pred$scores$species$Y  #据集 Y 的变量在 CoCA 轴上的得分（坐标）

#交叉验证，详情 ?crossval
crossval(beetles, plants)

#置换检验，999 次置换为例，详情 ?permutest
bp.perm <- permutest(bp.pred, permutations = 999)
bp.perm

#绘制双序图观测前两轴
layout(matrix(1:2, ncol = 2))
biplot(bp.pred, which = 'y1', main = 'Beetles', type = 'text', choices = 1:2)
biplot(bp.pred, which = 'y2', main = 'Plants', type = 'text', choices = 1:2)


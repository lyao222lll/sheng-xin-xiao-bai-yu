library(ade4)

#aravo$env 含定量变量和分类变量的环境测量数据
data(aravo)
head(aravo$env)

#环境数据的 PCA，结果中保留前 4 个排序轴的坐标便于观测数据
pca <- dudi.hillsmith(aravo$env, scannf = FALSE, nf = 4)

#PCA 概要
pca
summary(pca)

#展示前两轴的排序图，以及特征值柱形图
scatter(pca, choices = 1:2)
#或者
biplot(pca, choices = 1:2)

#提取结果，例如
#names(pca)
pca$l1    #标准化后的样方得分（排序坐标）
pca$c1    #标准化后的环境变量得分（排序坐标）
pca$eig    #各 PCA 轴特征值
pca$eig/sum(pca$eig)    #各 PCA 轴的贡献度
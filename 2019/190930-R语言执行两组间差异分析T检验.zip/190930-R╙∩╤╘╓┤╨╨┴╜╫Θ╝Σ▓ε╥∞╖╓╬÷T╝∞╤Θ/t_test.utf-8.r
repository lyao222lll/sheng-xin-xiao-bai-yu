library(reshape2) 

#读入文件，合并分组信息，数据重排
alpha <- read.table('alpha.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE)
alpha <- melt(merge(alpha, group, by = 'sample'), id = c('sample', 'group'))

#我们期望查看 group1 和 group2 的 observed_species 指数是否存在显著差异
#选择要比较的分组
richness_12 <- subset(alpha, variable == 'observed_species' & group %in% c('1', '2'))
richness_12$group <- factor(richness_12$group)

##正态 qq 图验证数据正态性
library(car)

#QQ-plot
qqPlot(lm(value~group, data = richness_12), simulate = TRUE, main = 'QQ Plot', labels = FALSE)

##Shapiro-Wilk 检验，当且仅当两者 p 值均大于 0.05 时表明数据符合正态分布
shapiro <- tapply(richness_12$value, richness_12$group, shapiro.test)
shapiro
shapiro$'1'$p.value
shapiro$'2'$p.value

##独立样本的 t 检验
t_test <- t.test(value~group, richness_12, paired = FALSE, alternative = 'two.sided')
t_test
t_test$p.value

##非独立样本的 t 检验
t_test <- t.test(value~group, richness_12, paired = TRUE, alternative = 'two.sided')
t_test
t_test$p.value

##可视化差异展示
#boxplot() 箱线图示例
boxplot(value~group, data = richness_12, col = c('blue', 'orange'), ylab = 'Observed_species', xlab = 'Group', main = 't-test: p-value < 0.001')

#ggplot2 柱形图示例
#分别计算各组中的均值以及标准差，展示为均值 ± 标准差的柱形图样式

library(doBy)	#使用其中的 summaryBy() 以方便按分组计算
library(ggplot2)	#ggplot2 作图

dat <- summaryBy(value~group, richness_12, FUN = c(mean, sd))

ggplot(dat, aes(group, value.mean, fill = group)) +
geom_col(width = 0.4, show.legend = FALSE) +
geom_errorbar(aes(ymin = value.mean - value.sd, ymax = value.mean + value.sd), width = 0.15, size = 0.5) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), plot.title = element_text(hjust = 0.5)) +
labs(x = 'Group', y = 'Observed_species', title = 't-test: p-value < 0.001')

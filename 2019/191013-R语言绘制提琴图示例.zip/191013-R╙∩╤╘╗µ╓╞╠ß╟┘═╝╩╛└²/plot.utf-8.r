#读取数据
library(reshape2)

alpha <- read.csv('alpha.csv')
alpha$group2 <- factor(alpha$group2)

alpha1 <- melt(alpha, id = c('samples', 'group1', 'group2'))
alpha2 <- subset(alpha1, variable == 'chao1')
alpha3 <- subset(alpha2, group1 == 'c')

##vioplot() 提琴图，详情 ?vioplot 查看帮助
library(vioplot)

c1 <- subset(alpha3, group2 == '1')$value
c2 <- subset(alpha3, group2 == '2')$value
c3 <- subset(alpha3, group2 == '3')$value
c4 <- subset(alpha3, group2 == '4')$value
c5 <- subset(alpha3, group2 == '5')$value

#pdf('vioplot.pdf', width = 6.5, height = 5)
png('vioplot.png', width = 2000, height = 1500, res = 300, units = 'px')
vioplot(c1, c2, c3, c4, c5, col = '#f8766d')
title(ylab = 'Chao1 (group c)')
dev.off()

##ggplot2
library(ggplot2)

#单变量提琴图
p <- ggplot(alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#ggsave('ggplot2.plot.pdf', p, width = 6, height = 4)
ggsave('ggplot2.plot.png', p, width = 6, height = 4)

#添加散点，将各数据值以抖动散点的方式添加在提琴图中
p <- ggplot(alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
geom_jitter(aes(color = group1)) +
scale_color_manual(values = c('red', 'seagreen3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.position = 'none') +
labs(x = '', y = 'Chao1 (group c)')

#ggsave('ggplot2.plot.pdf', p, width = 6, height = 4)
ggsave('ggplot2.plot.png', p, width = 6, height = 4)

#内置箱线图的提琴图
p <- ggplot(alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#ggsave('ggplot2.plot.pdf', p, width = 6, height = 4)
ggsave('ggplot2.plot.png', p, width = 6, height = 4)

#多分组、多变量情况，添加分组信息和分面的提琴图
p <- ggplot(alpha1, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE) +
facet_wrap(~variable, 2, scales = 'free') +
labs(x = '', y = '') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank())

#ggsave('ggplot2.plot.pdf', p, width = 7, height = 5)
ggsave('ggplot2.plot.png', p, width = 7, height = 5)


#带显著性标记“*”的提琴图
#先绘制提琴图主体
p <- ggplot(data = alpha2, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#再手动添加显著性标记
#注意，这里的显著性是提前已经计算好的，我们通过手动输入进来
#本篇只关注作图，不涉及统计分析
library(doBy)

alpha2_stat <- summaryBy(value~group2, alpha2, FUN = max)
names(alpha2_stat) <- c('group2', 'value')
alpha2_stat$group1 <- NA
alpha2_stat$sig <- rep('***', 5)

p <- p +
geom_text(data = alpha2_stat, aes(label = sig), vjust = -0.3) +
annotate('text', x = alpha2_stat$group2, y = alpha2_stat$value, label = '———', vjust = -0.3)

#ggsave('ggplot2.plot.pdf', p, width = 6, height = 4)
ggsave('ggplot2.plot.png', p, width = 6, height = 4)


#带显著性标记“abc”的提琴图
#先绘制提琴图主体
p <- ggplot(data = alpha1, aes(x = group2, y = value, fill = group1)) + 
geom_violin(position = position_dodge(width = 1), scale = 'width') +
geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE) +
facet_wrap(~variable, 2, scales = 'free') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), legend.title = element_blank(), legend.key = element_blank()) +
labs(x = '', y = 'Chao1')

#再手动添加显著性标记
#同上所述，这里的显著性是提前通过差异分析已经计算好的，我们通过手动输入进来
alpha1_stat <- summaryBy(value~group1+group2+variable, alpha1, FUN = max)
names(alpha1_stat) <- c('group1', 'group2', 'variable', 'value')
alpha1_stat$sig <- c('a', 'a', 'a', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'a', 'b', 'b', 'a', 'b', 'c', 'c', 'b', 'a', 'a', 'b', 'a', 'a', 'a', 'b', 'a', 'a', 'a', 'a', 'a')

p <- p +
geom_text(data = alpha1_stat, aes(label = sig, color = group1), position = position_dodge(1), vjust = -0.3)

#ggsave('ggplot2.plot.pdf', p, width = 8, height = 6)
ggsave('ggplot2.plot.png', p, width = 8, height = 6)

library(ade4)

#数据集，详情 ?aravo
data(aravo)
summary(aravo)

head(aravo$env)	#环境数据
head(aravo$spe[1:6])	#物种丰度数据
head(aravo$traits)	#物种性状数据
#head(aravo$spe.names)	#物种名称

##RLQ 分析
#三种数据集各自的排序分析过程

#样方-物种丰度的对应分析（CA），结果中保留两个排序轴，详情 ?dudi.coa
afcL.aravo <- dudi.coa(aravo$spe, scannf = FALSE, nf = 2)

#详情 ?dudi.hillsmith()，如果数据集中的变量全部为定量变量，则等效于 PCA；如果全为因子变量，则等效于 MCA
#行权重根据样方-物种丰度排序结果中的样方权重进行加权，结果中保留两个排序轴
acpR.aravo <- dudi.hillsmith(aravo$env, row.w = afcL.aravo$lw, scannf = FALSE, nf = 2)

#物种性状的主成分分析（PCA），详情 ?dudi.pca
#由于各性状类型的量纲不同，需要对数据集标准化处理
#行权重根据样方-物种丰度排序结果中的物种权重进行加权，结果中保留两个排序轴
acpQ.aravo <- dudi.pca(aravo$traits, row.w = afcL.aravo$cw, center = TRUE, scale = TRUE, scannf = FALSE, nf = 2)

#RLQ 整合上述三步结果，结果中保留两个排序轴，详情 ?rlq
rlq.aravo <- rlq(dudiR = acpR.aravo, dudiL = afcL.aravo, dudiQ = acpQ.aravo, scannf = FALSE, nf = 2)
rlq.aravo

summary(rlq.aravo)

#对于所需结果的提取，如 RLQ 轴的特征值
names(rlq.aravo)
rlq.aravo$eig

#作图，展示前两轴，详情 ?rlq
plot(rlq.aravo, axes = 1:2)

#RLQ 全局检验，999 次置换为例，详情 ?randtest
rlq_rand <- randtest(rlq.aravo, nrepet = 999)
rlq_rand
plot(rlq_rand)

##第四角分析
#第四角分析评估变量间的相关性，999 次置换检验确定显著性，Benjamini 方法校正 p 值，详情 ?fourthcorner
four.comb.aravo <- fourthcorner(tabR = aravo$env, tabL = aravo$spe, tabQ = aravo$traits, 
	modeltype = 6, p.adjust.method.G = 'BH', p.adjust.method.D = 'BH', nrepet = 999)

four.comb.aravo

#综合考虑 D、D2、G 统计量作为相关性的统计值
#显示的图中，显著的相关（默认 p<0.05）使用红色（Obs 正值代表正相关）或蓝色（Obs 负值代表负相关）标注
par(mfrow = c(1, 2))
plot(four.comb.aravo, alpha = 0.05, stat = c('D', 'D2', 'G'))
plot(four.comb.aravo, x.rlq = rlq.aravo, alpha = 0.05, stat = c('D', 'D2', 'G'), type = 'biplot')

#只使用 stat = 'D2' 作为相关性的统计值，详情 ?fourthcorner
par(mfrow = c(1, 2))
plot(four.comb.aravo, alpha = 0.05, stat = 'D2')
plot(four.comb.aravo, x.rlq = rlq.aravo, alpha = 0.05, stat = 'D2', type = 'biplot')

#提取主要结果，如 D2 统计量
names(four.comb.aravo)
four.comb.aravo$tabD2

#评估数据集 R、Q 中的变量与 RLQ 协惯量轴之间关系的显著程度
#999 次置换为例，Benjamini 方法校正 p 值，详情 ?fourthcorner.rlq
testRaxes.comb.aravo <- fourthcorner.rlq(rlq.aravo, type = 'R.axes', 
	modeltype = 6, p.adjust.method.G = 'BH', p.adjust.method.D = 'BH',nrepet = 999)
testQaxes.comb.aravo <- fourthcorner.rlq(rlq.aravo, type = 'Q.axes', 
	modeltype = 6, p.adjust.method.G = 'BH', p.adjust.method.D = 'BH',nrepet = 999)

testRaxes.comb.aravo
testQaxes.comb.aravo

#以 stat = 'D2' 统计量为例展示
#显示的图中，显著的相关（默认 p<0.05）使用红色（Obs 正值代表正相关）或蓝色（Obs 负值代表负相关）标注
par(mfrow = c(2, 2))
plot(testRaxes.comb.aravo, alpha = 0.05, stat = 'D2')
plot(testRaxes.comb.aravo, x.rlq = rlq.aravo, alpha = 0.05, stat = 'D2', type = 'biplot')
plot(testQaxes.comb.aravo, alpha = 0.05, stat = 'D2')
plot(testQaxes.comb.aravo, x.rlq = rlq.aravo, alpha = 0.05, stat = 'D2', type = 'biplot')

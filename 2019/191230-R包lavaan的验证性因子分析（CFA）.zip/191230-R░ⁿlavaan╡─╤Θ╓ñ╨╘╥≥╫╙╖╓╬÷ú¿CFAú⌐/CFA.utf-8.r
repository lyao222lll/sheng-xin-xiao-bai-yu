library(lavaan)

#数据集，详情 ?HolzingerSwineford1939
hz <- HolzingerSwineford1939
head(hz)

#因子和变量关系的书写格式，=~ 表示“由...表示”
hz.model <- '
visual =~ x1 + x2 + x3
writing =~ x4 + x5 + x6
maths =~ x7 + x8 + x9'

#执行 CFA 的一个简单方法，详情 ?cfa
hz.fit <- cfa(model = hz.model, data = hz)

summary(hz.fit, standardized = TRUE)

#可视化因子和变量间的关系，详情 ?semPaths
#例如，边的粗细分别代表参数估计值或标准化的参数估计值
library(semPlot)

par(mfrow = c(1, 2))
semPaths(hz.fit, what = 'est', layout = 'tree')
semPaths(hz.fit, what = 'std', layout = 'tree')

#模型拟合度，详情 ?fitmeasures
fitmeasures(hz.fit, c('cfi', 'rmsea', 'rmsea.ci.upper', 'bic'))

#检查修改索引
mf <- modificationindices(hz.fit)
mf <- mf[order(mf$mi, mf$epc, decreasing = TRUE), ]
mf

#追加 X9 与 visual 的关系
hz.model.2 <- '
visual =~ x1 + x2 + x3 + x9
writing =~ x4 + x5 + x6
maths =~ x7 + x8 + x9'

hz.fit.2 <- cfa(model = hz.model.2, data = hz)
#summary(hz.fit.2, standardized = TRUE)
#semPaths(hz.fit.2, what = 'std', layout = 'tree')

fitmeasures(hz.fit.2, c('cfi', 'rmsea', 'rmsea.ci.upper', 'bic'))

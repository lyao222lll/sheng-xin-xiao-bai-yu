library(vegan)

#读取物种数据
phylum <- read.delim('phylum_table.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)

##CA 排序，详情 ?cca
ca_phylum <- cca(phylum)

#I 型标尺
summary(ca_phylum, scaling = 1)
#II 型标尺
#summary(ca_phylum, scaling = 2)

##重要内容提取
#各 CA 轴的特征根，特征根是固定的，和标尺选择无关
ca_eig <- ca_phylum$CA$eig
#除以特征根总和，即可得各 CA 轴的解释量
ca_exp <- ca_phylum$CA$eig / sum(ca_phylum$CA$eig)

#提取样方得分，以 I 型标尺为例，以前两轴为例
#scores() 提取样方坐标
site.scaling1 <- scores(ca_phylum, choices = 1:2, scaling = 1, display = 'site')
#或者在 summary 中提取
site.scaling1 <- summary(ca_phylum, scaling = 1)$sites[ ,1:2]
site.scaling1
#write.table(site.scaling1, 'site.scaling1.txt', col.names = NA, sep = '\t', quote = FALSE)

#提取物种得分，以 II 型标尺为例，以前两轴为例
#scores() 提取物种坐标
phylum.scaling2 <- scores(ca_phylum, choices = 1:2, scaling = 2, display = 'sp')
#或者 summary 中提取
phylum.scaling2 <- summary(ca_phylum, scaling = 2)$species[ ,1:2]
phylum.scaling2
#write.table(phylum.scaling2, 'phylum.scaling2.txt', col.names = NA, sep = '\t', quote = FALSE)

##CA 作图
#ordiplot() 简洁版作图观测，详情 ?ordiplot
#I 型标尺，样方点是物种点的形心
#II 型标尺，物种点是样方点的形心
ca1 <- paste('CA1:', round(ca_exp[1]*100, 2), '%')
ca2 <- paste('CA2:',round(ca_exp[2]*100, 2), '%')

par(mfrow = c(2, 2))
ordiplot(ca_phylum, display = 'site', type = 'text', choices = c(1, 2), scaling = 1, main = 'I 型标尺，仅样方', xlab = ca1, ylab = ca2)
ordiplot(ca_phylum, display = 'sp', type = 'text', choices = c(1, 2), scaling = 2, main = 'II 型标尺，仅物种', xlab = ca1, ylab = ca2)
ordiplot(ca_phylum, type = 'point', choices = c(1, 2), scaling = 1, main = 'I 型标尺，双序图', xlab = ca1, ylab = ca2)
ordiplot(ca_phylum, type = 'point', choices = c(1, 2), scaling = 2, main = 'II 型标尺，双序图', xlab = ca1, ylab = ca2)

#ordiplot() 作图，可视化调整后，I 型标尺为例，详情 ?ordiplot
#仅样方
png('ca_phylum.png', width = 600, height = 600, res = 100, units = 'px')
ordiplot(ca_phylum, type = 'n', display = 'site', choices = c(1, 2), scaling = 1, main = 'I 型标尺，仅样方', xlab = ca1, ylab = ca2)
points(ca_phylum, display = 'site', choices = c(1, 2), scaling = 1, pch = 21, bg = c(rep('red', 4), rep('orange', 4), rep('green3', 4)), col = NA, cex = 1.2)
dev.off()

#带物种
#ordiplot(ca_phylum, type = 'n', choices = c(1, 2), scaling = 1, main = 'I 型标尺，双序图', xlab = ca1, ylab = ca2)
#points(ca_phylum, display = 'site', choices = c(1, 2), scaling = 1, pch = 21, bg = c(rep('red', 4), rep('orange', 4), rep('green3', 4)), col = NA, cex = 1.2)
#text(ca_phylum, display = 'sp', choices = c(1, 2), scaling = 1, col = 'blue', cex = 0.8)

#ggplot2 作图，I 型标尺为例，展示所有样方以及部分物种（top10 丰度门）
#提取样方和物种排序坐标，前两轴
site.scaling1 <- data.frame(summary(ca_phylum, scaling = 1)$sites[ ,1:2])
phylum.scaling1 <- data.frame(summary(ca_phylum, scaling = 1)$species[ ,1:2])

#添加分组信息
site.scaling1$sample <- rownames(site.scaling1)
site.scaling1$group <- c(rep('A', 4), rep('B', 4), rep('C', 4))
phylum.scaling1$group <- rownames(phylum.scaling1)

#只保留 top10 丰度的细菌门
top10_phylum <- names(colSums(phylum)[order(colSums(phylum), decreasing = TRUE)][1:10])
top10_phylum.scaling1 <- phylum.scaling1[top10_phylum, ]

#ggplot2 作图
library(ggplot2)
library(ggrepel)	#用于 geom_text_repel() 添加标签

p <- ggplot(site.scaling1, aes(CA1, CA2)) +
geom_point(aes(color = group)) +
scale_color_manual(values = c('red', 'orange', 'green3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.key = element_rect(fill = 'transparent'), plot.title = element_text(hjust = 0.5)) + 
geom_vline(xintercept = 0, color = 'gray', size = 0.5) + 
geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
geom_point(data = top10_phylum.scaling1, color = 'blue') +
geom_text_repel(data = top10_phylum.scaling1, aes(label = group), size = 3, box.padding = unit(0.5, 'lines'), color = 'blue') +
labs(x = ca1, y = ca2, title = 'I 型标尺，仅展示 top10 丰度种群', color = NULL)

#ggsave('ca_phylum.pdf', p, width = 5.5, height = 5)
ggsave('ca_phylum.png', p, width = 5.5, height = 5)

##帮助评估有解读价值的 CA 轴
#Kaiser-Guttman 准则
#计算特征值的平均值，可据此保留高于平均值的主成分轴
ca_eig[ca_eig > mean(ca_eig)]

#断棍模型
#将单位长度的“棍子”随机分成与 CA 轴数一样多的几段，由高往低排序
#可据此选取特征根大于所对应断棍长度的轴，或者总和大于所对应断棍长度总和的前几轴
n <- length(ca_eig)
bsm <- data.frame(j = seq(1:n), p = 0)
bsm$p[1] <- 1/n
for (i in 2:n) bsm$p[i] <- bsm$p[i-1] + (1/(n+1-i))
bsm$p <- 100*bsm$p/n
bsm

#绘制每轴的特征根和方差百分比 
par(mfrow = c(2, 1))
barplot(ca_eig, main = '特征根', col = 'bisque', las = 2)
abline(h = mean(ca_eig), col = 'red')
legend('topright', '平均特征根', lwd = 1, col = 2, bty = 'n')
barplot(t(cbind(100 * ca_eig/sum(ca_eig), bsm$p[n:1])), beside = TRUE, main = '% 变差', col = c('bisque', 2), las = 2)
legend('topright', c('% 特征根', '断棍模型'), pch = 15, col = c('bisque', 2), bty = 'n')

################################
#FactoMineR 的 MFA
library(FactoMineR)

#数据集，详情 ?wine
data(wine)
head(wine[1:6])

#执行 MFA，详情 ?MFA
#其中，摇动前后的气味、视觉和味觉作为 active groups，来源和质量作为 supplementary groups
res.mfa <- MFA(wine, group = c(2, 5, 3, 10, 9, 2), type = c('n', 's', 's', 's', 's', 's'),
    name.group = c('origin', 'odor_before_shaking', 'visual', 'odor_after_shaking', 'taste', 'quality'),
    num.group.sup = c(1, 6), graph = TRUE)

summary(res.mfa)

#提取主要信息，例如
res.mfa
res.mfa$eig    #各轴特征值

################################
#借助 factoextra 包更好地提取数据和可视化
library(factoextra)

##提取每个维度（轴）的特征值/承载的方差
eig.val <- get_eigenvalue(res.mfa)
head(eig.val)

#可视化各轴特征值/方差
fviz_screeplot(res.mfa)

##变量集结果，用于反映变量集整体对 MFA 排序空间的贡献
group <- get_mfa_var(res.mfa, 'group')
group

#查看细节部分，例如
#各变量集作为整体，计算了它们与各 MFA 轴的相关性
head(group$correlation)

#排序坐标也可用于反映各变量集与各 MFA 轴的相关程度，前两轴为例展示
head(group$coord)
fviz_mfa_var(res.mfa, 'group', axes = 1:2)

#直接显示了各变量集对各排序轴的贡献度
head(group$contrib)
#可视化各变量集对前两轴的贡献度
fviz_contrib(res.mfa, 'group', axes = 1)
fviz_contrib(res.mfa, 'group', axes = 2)

#变量集之间的相关性通过 RV 系数衡量
#变量集之间的相关性矩阵
res.mfa$group$RV

#相关图
library(corrplot)
corrplot(res.mfa$group$RV, method = 'number', number.cex = 0.8, diag = FALSE, tl.cex = 0.8)
corrplot(res.mfa$group$RV, add = TRUE, type = 'upper', method = 'pie', diag = FALSE, tl.pos = 'n', cl.pos = 'n')

#这种相关性可通过置换检验确定重要性
#例如摇动前的气味（原始数据集的 3-7 行）和摇动后的气味（原始数据集的 11-20 行）之间的相关性的置换检验
#记得执行 Z-scores 标准化变量集
coeffRV(scale(wine[3:7]), scale(wine[11:20]))$p.value

##各具体变量对排序空间的贡献，数据结构同上述“变量集整体”
quanti.var <- get_mfa_var(res.mfa, 'quanti.var')
quanti.var 

#例如同样以排序图可视化各变量与 MFA 轴的关系，前两轴为例展示
head(quanti.var$coord)	#排序坐标
fviz_mfa_var(res.mfa, 'quanti.var', axes = 1:2, palette = 'jco', col.var.sup = 'violet', repel = TRUE)

#直接显示了各变量对各排序轴的贡献度
head(quanti.var$contrib)
#展示 top20 变量对前两轴的贡献度
fviz_contrib(res.mfa, choice = 'quanti.var', axes = 1, top = 20, palette = 'jco')
fviz_contrib(res.mfa, choice = 'quanti.var', axes = 2, top = 20, palette = 'jco')

#可选使用渐变色，在排序图中按变量贡献对 active groups 变量上色
#这里方便观测数据，将所有变量以点展示
fviz_mfa_var(res.mfa, 'quanti.var', axes = 1:2, col.var = 'contrib', geom = c('point', 'text'), 
    gradient.cols = c('#00AFBB', '#E7B800', '#FC4E07'), col.var.sup = 'violet', repel = TRUE)

#变量太多了，评估最具典型的一些变量
select_val <- dimdesc(res.mfa, axes = 1:2, proba = 0.001)
summary(select_val)

#保留最具典型的一些变量的排序图
varsig <- res.mfa$quanti.var$cor
varsig <- subset(varsig, rownames(varsig) %in% unique(c(rownames(select_val$Dim.1$quanti), rownames(select_val$Dim.2$quanti))))

plot(varsig[ ,1:2], asp = 1, type = 'n', xlim = c(-1, 1), ylim = c(-1, 1))
abline(h = 0, lty = 3)
abline(v = 0, lty = 3)
symbols(0, 0, circles = 1, inches = FALSE, add = TRUE)
arrows(0, 0, varsig[,1], varsig[,2], length = 0.08, angle = 20)
for (v in 1:nrow(varsig)) {
    if (abs(varsig[v,1]) > abs(varsig[v,2])) {
        if (varsig[v,1] >= 0) pos <- 4 else pos <- 2
    } else {
        if (varsig[v,2] >= 0) pos <- 3 else pos <- 1
    }
    text(varsig[v,1], varsig[v,2], labels=rownames(varsig)[v], pos = pos)
}

##查看排序对象，数据结构类上上述
ind <- get_mfa_ind(res.mfa)
ind

#例如查看对象排序坐标
head(ind$coord)

##展示对象在前两轴中的排序图
#如果不想在图中展示分类变量，可使用参数 invisible = 'quali.var'
fviz_mfa_ind(res.mfa, axes = 1:2, palette = c('#00AFBB', '#E7B800', '#FC4E07'),
    habillage = 'Label', addEllipses = TRUE, ellipse.type = 'confidence', repel = TRUE) 

#分别按两组分类变量特征，在图中对代表葡萄酒的点标注颜色
fviz_ellipses(res.mfa, axes = 1:2, c('Label', 'Soil'), repel = TRUE)

#MFA 图中对象位置与各组变量集 PCA 中的对象位置，前两轴为例展示
fviz_mfa_ind(res.mfa, axes = 1:2, partial = 'all')
#可选择部分对象展示
fviz_mfa_ind(res.mfa, axes = 1:2, partial = c('1DAM', '1VAU', '2ING'))

##偏轴图，前两轴为例展示
fviz_mfa_axes(res.mfa, axes = 1:2)

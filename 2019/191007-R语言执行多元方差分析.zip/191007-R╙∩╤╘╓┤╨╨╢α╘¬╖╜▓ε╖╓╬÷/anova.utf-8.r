#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##多元方差分析（MANOVA）
#以单因素多元方差分析为例
#假设所有土壤类型均一致，我们在土壤中分别添加了三种化学物质（a、b、c），并将土壤孵育了相同的时间后，探究土壤细菌群落 chao1 指数、土壤 pH、土壤硝酸还原酶（NR）活性是否因所添加化学物质类型不同而显著改变

#选择数据，并将分组列转换为因子变量
muti <- soil[ ,c('sample', 'treat', 'chao1', 'pH', 'NR')]
muti$treat <- factor(muti$treat)

#QQ-plot 检验多元正态性
y <- cbind(muti$NR, muti$pH, muti$chao1)
coord <- qqplot(qchisq(ppoints(nrow(y)), df = ncol(y)), mahalanobis(y, colMeans(y), cov(y)))
abline(a = 0, b = 1)

identify(coord$x, coord$y, labels = muti$sample)	#可以交互式展示样本位置，可用于观测离群点

#Box's M 检验验证方差-协方差矩阵同质性（p 值大于 0.05 即说明各组的协方差矩阵相同）
library(biotools)
boxM(muti[ ,c('chao1', 'pH', 'NR')], muti[ ,'treat'])

#假设通过，执行单因素 MANOVA，详情使用 ?manova 查看帮助。
fit <- manova(cbind(NR, pH, chao1)~treat, data = muti)
summary(fit)	#查看整体结果
summary.aov(fit)	#对每一个变量做单因素方差分析

#假设未通过，可使用稳健单因素 MANOVA
#通过 rrcov 包中的 Wilks.test() 函数实现，详情可使用 ?Wilks.test 查看帮助
library(rrcov)
muti$treat <- factor(muti$treat)
Wilks.test(treat~., data = muti[c('treat', 'NR', 'pH', 'chao1')], method = 'c')

#或者在不满足假设时使用非参数方法，例如置换多元方差分析（PERMANOVA）
#vegan 包 adonis()

library(reshape2)

#读入文件，合并分组信息，数据重排
alpha <- read.table('alpha.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
alpha <- melt(merge(alpha, group, by = 'sample'), id = c('sample', 'group'))

#选择要比较的分组（此处查看 group1 与 group2 在 shannon 指数上是否存在显著差异）
shannon_23 <- subset(alpha, variable == 'shannon' & group %in% c('2', '3'))
shannon_23$group <- factor(shannon_23$group)
head(shannon_23, 10)

#Shapiro-Wilk 检验数据是否符合正态分布（发现不符合正态分布）
tapply(shannon_23$value, shannon_23$group, shapiro.test)

##wilcox 秩和检验，我们执行了一个双侧检验
wilcox_test <- wilcox.test(value~group, shannon_23, paired = FALSE, alternative = 'two.sided')
wilcox_test
wilcox_test$p.value

##wilcox 符号秩和检验，我们执行了一个双侧检验
wilcox_test <- wilcox.test(value~group, shannon_23, paired = TRUE, alternative = 'two.sided')
wilcox_test
wilcox_test$p.value


##wilcox 检验批处理示例
library(doBy)	#使用其中的 summaryBy() 以方便按分组计算均值、中位数

#读取数据
gene <- read.table('gene.txt', sep = '\t', row.names = 1, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
result <- NULL

#使用循环，逐一对各基因进行两组间 wilcox 秩和检验
for (n in 1:nrow(gene)) {
	gene_n <- data.frame(t(gene[n,subset(group, group %in% c(1, 2))$sample]))
	gene_id <- names(gene_n)[1]
	names(gene_n)[1] <- 'gene'
	
	gene_n$sample <- rownames(gene_n)
	gene_n <- merge(gene_n, group, by = 'sample', all.x = TRUE)
	
	gene_n$group <- factor(gene_n$group)
	p_value <- wilcox.test(gene~group, gene_n)$p.value
	if (!is.na(p_value) & p_value < 0.05) {
		stat <- summaryBy(gene~group, gene_n, FUN = c(mean, median))
		result <- rbind(result, c(gene_id, as.character(stat[1,1]), stat[1,2], stat[1,3], as.character(stat[2,1]), stat[2,2], stat[2,3], p_value))
	}
}

#输出统计结果
result <- data.frame(result)
names(result) <- c('gene_id', 'group1', 'mean1', 'median1', 'group2', 'mean2', 'median2', 'p_value')
result$p_adjust <- p.adjust(result$p_value, method = 'BH')	#推荐加个 p 值校正的过程 
write.table(result, 'gene.wilcox.txt', sep = '\t', row.names = FALSE, quote = FALSE)

##作图示例
#boxplot() 箱线图
boxplot(value~group, data = shannon_23, col = c('blue', 'orange'), ylab = 'Shannon', xlab = 'Group', main = 'wilcox test: p-value = 0.00295')

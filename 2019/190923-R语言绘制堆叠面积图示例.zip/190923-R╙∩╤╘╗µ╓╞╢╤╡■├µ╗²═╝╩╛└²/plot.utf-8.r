library(reshape2)
library(ggplot2)

#读取数据
phylum_top10 <- read.csv('phylum_top10.csv', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)

#重排表格为 ggplot2 作图样式，借助 reshape2 包 melt() 实现
phylum_top10$Taxonomy <- factor(rownames(phylum_top10), levels = rev(rownames(phylum_top10)))
phylum_top10 <- melt(phylum_top10, id = 'Taxonomy')
names(phylum_top10)[2] <- 'sample'

#合并分组信息，添加时间序列
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
phylum_top10 <- merge(phylum_top10, group, by = 'sample', all.x = TRUE)

##ggplot2 堆叠面积图
p <- ggplot(phylum_top10, aes(x = times, y = 100 * value, fill = Taxonomy)) +
geom_area(color = 'black') +
scale_fill_manual(values = c('gray', '#CCEBC5', '#BC80BD', '#FCCDE5', '#B3DE69', '#FDB462', '#80B1D3', '#FB8072', '#BEBADA', '#FFFFB3', '#8DD3C7')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
labs(x = 'Times', y = 'Relative Abundance(%)', title = '', fill = 'Top10 Phylum') +
scale_x_continuous(breaks = 1:15, labels = as.character(1:15), expand = c(0, 0)) +
scale_y_continuous(expand = c(0, 0))

#ggsave('ggplot2_area.pdf', p, width = 8, height = 5)
ggsave('ggplot2_area.png', p, width = 8, height = 5)

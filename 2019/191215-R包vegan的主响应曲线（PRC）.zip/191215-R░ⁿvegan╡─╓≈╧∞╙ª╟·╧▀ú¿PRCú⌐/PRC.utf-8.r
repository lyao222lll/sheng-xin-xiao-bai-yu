library(vegan)

##数据集
#详情 https://www.rdocumentation.org/packages/vegan/versions/2.4-2/topics/pyrifos
data(pyrifos)
head(pyrifos[ ,1:10])

#分组信息：沟渠编号
ditch <- gl(12, 1, length = 132)

#分组信息：采样时间，处理前的第 4 周开始，至处理后的第 24 周
week <- gl(11, 12, labels = c(-4, -1, 0.1, 1, 2, 4, 8, 12, 15, 19, 24))

#分组信息：化学剂量浓度
dose <- factor(rep(c(0.1, 0, 0, 0.9, 0, 44, 6, 0.1, 44, 0.9, 0, 6), 11))

#PRC 执行，详情 ?prc
#响应变量为物种丰度数据集，treatment 对应处理，time 对应时间
mod <- prc(response = pyrifos, treatment = dose, time = week)

#这里实质上执行了一种附带偏 RDA 的过程
mod
#对应于 RDA 函数 rda()，则上式 prc() 等同于下式 rda()
#rda(pyrifos ~ dose * week + Condition(week))

#查看 PRC 的物种得分及典范系数，详情 ?prc
#需指定观测的轴（即 RDA 的第几约束轴），以及使用的标尺缩放类型
#这里以 RDA 第 1 主轴为例，'symmetric' 缩放为例
prc_summary <- summary(mod, axis = 1, scaling = 'symmetric')

#提取物种得分
sp <- prc_summary$sp
#提取典范系数
coeff <- prc_summary$coefficients

#物种响应曲线，详情 ?prc
#同样地，需指定观测的轴（即 RDA 的第几约束轴），以及使用的标尺缩放类型
#物种太多时，不妨通过 select 选择特定物种展示，例如这里选择展示一些较高丰度的物种
plot(mod, axis = 1, scaling = 'symmetric', select = colSums(pyrifos) > 100)

#所选观测轴的置换检验，确定显著性，以第 1 轴为例，99 次置换
ctrl <- how(plots = Plots(strata = ditch,type = 'free'), within = Within(type = 'series'), nperm = 99)
anova(mod, permutations = ctrl, first = TRUE)

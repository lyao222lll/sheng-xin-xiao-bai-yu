library(vegan)

##使用 vegan 自带的数据集 BCI，第一种类型的物种累积曲线，也就是稀释曲线
data(BCI)

#展示 5 个样方的物种累积曲线（稀释曲线）
#详情 ?rarecurve
rarecurve(BCI[1:5,], step = 20, col = c('red', 'green', 'blue', 'orange', 'purple', 'black'))

##使用 vegan 自带的数据集 BCI，第二种类型的物种累积曲线
data(BCI)

#函数 specaccum() 可以统计一定数量的采样点的物种数量
#详情 ?specaccum
sp <- specaccum(BCI, method = 'random')
sp
summary(sp)

#作图展示
plot(sp, ci.type = 'poly', col = 'blue', lwd = 2, ci.lty = 0, ci.col = 'lightblue')
boxplot(sp, col = 'yellow', add = TRUE, pch = '+')

#可通过 fitspecaccum() 在其中拟合非线性物种累积模型，例如
mod <- fitspecaccum(sp, model = 'lomolino')	#Fit Lomolino model to the exact accumulation
mod <- fitspecaccum(sp, model = 'arrh')	#Fit Arrhenius models to all random accumulations

#查看拟合模型
coef(mod)
fitted(mod)

#作图展示
plot(mod, col = 'hotpink')
boxplot(sp, col = 'yellow', border = 'blue', lty = 1, cex = 0.3, add = TRUE)

##对于第二种类型的物种累积曲线的其它拓展
#BCI 数据集共计 50 个样方
#specslope() 可在给定数量的样方中评估物种积累曲线的导数，用于表征物种数量的增加率
#可知数值越小，表明曲线越趋饱和
sp <- specaccum(BCI, method = 'exact')
specslope(sp, at = 5)
specslope(sp, at = 25)
specslope(sp, at = 45)

#许多物种在样地集中将始终不可见或未被发现
#poolaccum() 使用一些流行的方法来估计这些未见物种的数量，并将它们添加至观察到的物种丰富度中
#详情 ?poolaccum
pool <- poolaccum(BCI)
summary(pool, display = 'chao')

plot(pool)

#或者直接通过定量模型表征
#即计算 Chao1、ACE 指数，反映这些未见物种的数量
#详情 ?estimateR
estimateR(BCI)


library(ggplot2)

#读取数据
stat <- read.csv('stat.csv', stringsAsFactors = FALSE)

#可以给细菌类群按丰度高低排个序
stat$taxonomy<-factor(stat$taxonomy, levels = c('Alphaproteobacteria', 'Gammaproteobacteria', 'Acidobacteria',
	'Actinobacteria', 'Betaproteobacteria', 'Bacteroidetes'))

#将小数类型的相对丰度乘以 100 方便以百分比展示
stat$mean <- stat$mean * 100
stat$se <- stat$se * 100

#ggplot2 分组柱状图
p <- ggplot(stat, aes(taxonomy, mean, fill = group)) +
geom_col(position = position_dodge(width = 0.9), width = 0.7) +
geom_errorbar(aes(ymin = mean - se, ymax = mean + se), width = 0.25, size = 0.3, position = position_dodge(0.9)) +
scale_fill_manual(values = c('#B3DE69', '#FDB462', '#80B1D3')) +
labs(title = NULL, x = NULL, y = 'Relative abundance (%)', fill = NULL) +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = 'black'), legend.position = c(0.9, 0.85)) +
theme(axis.text.x = element_text(size = 11, angle = 45, hjust = 1)) +
scale_y_continuous(expand = c(0, 0), limit = c(0, 50))

#ggsave('p.pdf', p, width = 8, height = 5)
ggsave('p.png', p, width = 8, height = 5)

#添加显著性标记 abc
p1 <- p + geom_text(aes(label = sign1, y = mean + se + 3), position = position_dodge(0.9))

ggsave('p1.png', p1, width = 8, height = 5)

#添加显著性标记 *
p2 <- p + geom_text(aes(label = sign2, y = mean + se + 6), size = 5)

ggsave('p2.png', p2, width = 8, height = 5)

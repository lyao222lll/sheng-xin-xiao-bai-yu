library(ggplot2)

##一个展示基因差异表达水平的火山图示例
gene <- read.delim('GSE40290_Volcano_data.txt', sep = '\t', stringsAsFactors = FALSE)

#例如这里自定义根据 |log2FC| >= 1 和 adj.P.Val < 0.01 标记差异类型
gene[which(gene$adj.P.Val < 0.01 & gene$logFC <= -1),'sig'] <- 'Down'
gene[which(gene$adj.P.Val < 0.01 & gene$logFC >= 1),'sig'] <- 'Up'
gene[which(gene$adj.P.Val >= 0.01 | abs(gene$logFC) < 1),'sig'] <- 'None'
 
#横轴 log2FC，纵轴 -log10(adj.P.Val)，颜色表示差异
p <- ggplot(gene, aes(x = logFC, y = -log10(adj.P.Val), color = sig)) +
geom_point(alpha = 0.6, size = 1) +
scale_colour_manual(values  = c('red2', 'blue2', 'gray'), limits = c('Up', 'Down', 'None')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), plot.title = element_text(hjust = 0.5)) +
theme(legend.key = element_rect(fill = 'transparent'), legend.background = element_rect(fill = 'transparent'), legend.position = c(0.9, 0.93)) +
geom_vline(xintercept = c(-1, 1), color = 'gray', size = 0.3) +
geom_hline(yintercept = -log(0.01, 10), color = 'gray', size = 0.3) +
xlim(-5, 5) + ylim(0, 6) +
labs(x = '\nLog2 Fold Change', y = 'Log10 Mean of Normalized Count\n', color = '', title = 'Cancer vs Normal\n')

p

#ggsave('gene.pdf', p, width = 5, height = 6)
ggsave('gene.png', p, width = 5, height = 6)

##如果想在图中展示一些基因的名称，例如这里按 p 值把最显著的上调/下调的前 10 个基因标注出
library(ggrepel)

up <- subset(gene, sig == 'Up')
up <- up[order(up$adj.P.Val), ][1:10, ]
down <- subset(gene, sig == 'Down')
down <- down[order(down$adj.P.Val), ][1:10, ]

#一种样式，借助 ggrepel 包中的函数
p1 <- p + theme(legend.position = 'right') +
geom_text_repel(data = rbind(up, down), aes(x = logFC, y = -log10(adj.P.Val), label = gene_name),
	size = 3,box.padding = unit(0.5, 'lines'), segment.color = 'black', show.legend = FALSE)
p1

#ggsave('gene1.pdf', p1, width = 6, height = 6)
ggsave('gene1.png', p1, width = 6, height = 6)

#另一种样式，同样借助 ggrepel 包中的函数，不过点太多时容易遮挡
p2 <- p + theme(legend.position = 'right') +
geom_label_repel(data = rbind(up, down), aes(label = gene_name), show.legend = FALSE)
p2

#ggsave('gene2.pdf', p2, width = 6, height = 6)
ggsave('gene2.png', p2, width = 6, height = 6)

##一个展示细菌群落 OTUs 丰度差异水平的火山图示例
otu <- read.delim('OTUs_diff.txt', sep = '\t', stringsAsFactors = FALSE)

#这里把上述数据框“otu”重复上 3 次，假设当它为 3 个不同分组的比较结果吧，仅用于演示分面图
otu1 <- otu
otu1$group <- 'group1 vs 2'
otu2 <- otu
otu2$group <- 'group2 vs 3'
otu3 <- otu
otu3$group <- 'group1 vs 3'
otu <- rbind(otu1, otu2, otu3)

#例如这里自定义根据 |log2FC| >= 1 和 FDR < 0.05 标记差异类型
otu[which(otu$FDR < 0.05 & otu$log2FC <= -1),'sig'] <- 'depleted'
otu[which(otu$FDR < 0.05 & otu$log2FC >= 1),'sig'] <- 'enriched'
otu[which(otu$FDR >= 0.05 | abs(otu$log2FC) < 1),'sig'] <- 'no diff'

#横轴 log10 转化后的标准化后的 OTUs 平均丰度，纵轴 log2FoldChange，颜色表示差异
p <- ggplot(otu, aes(x = log10(baseMean), y = log2FC, color = sig)) +
geom_point(alpha = 0.6, size = 1) +
scale_colour_manual(values  = c('red2', 'blue2', 'gray'), limits = c('enriched', 'depleted', 'no diff')) +
theme(panel.grid.major = element_line(color = 'gray', size = 0.2), panel.background = element_rect(color = 'black', fill = 'transparent'), legend.key = element_rect(fill = 'transparent'), legend.position = 'top') +
labs(x = '\nLog10 Mean of Normalized Abundance', y = 'Log2 Fold Change\n', color = '') +
facet_wrap(~group, ncol = 3, scale = 'free')

p

#ggsave('otu.pdf', p, width = 10, height = 3.5)
ggsave('otu.png', p, width = 10, height = 3.5)

##带双 logFC 信息的二维散点图示例
#读取另一个作图数据
two <- read.csv('gene_two.csv')

#标记显著性（默认 p < 0.05）
two[which(two$FDR_A < 0.05 & two$FDR_B < 0.05),'type1'] <- 'sign'
two[which(two$FDR_A >= 0.05 | two$FDR_B >= 0.05),'type1'] <- 'no'

#标记差异倍数（默认 |log2FC| >= 1）
two[which(two$logFC_A <= -1 & two$logFC_B <= -1),'type2'] <- 'a_down.b_down'
two[which(two$logFC_A >= 1 & two$logFC_B <= -1),'type2'] <- 'a_up.b_down'
two[which(two$logFC_A <= -1 & two$logFC_B >= 1),'type2'] <- 'a_down.b_up'
two[which(two$logFC_A >= 1 & two$logFC_B >= 1),'type2'] <- 'a_up_b_up'
two[is.na(two$type2),'type2'] <- 'no'

#合并显著性和差异倍数，用于标记差异基因
two$type3 <- paste(two$type1, two$type2, sep = '.')

#排序，为了使作图时显著的点绘制在前方（减少被遮盖）
two$type3 <- factor(two$type3, levels = c('sign.a_down.b_down', 'sign.a_up.b_down', 'sign.a_down.b_up', 'sign.a_up_b_up', 'no.a_down.b_down', 'no.a_up.b_down', 'no.a_down.b_up', 'no.a_up_b_up', 'sign.no', 'no.no'))
two <- two[order(two$type3, decreasing = TRUE), ]

#ggplot2 作图，点颜色定义为基因差异类型，点大小表示基因表达量 CPM 值
p <- ggplot(two, aes(logFC_A, logFC_B)) +
geom_point(aes(color = type3, size = logCPM), alpha = 0.6, show.legend = FALSE) +
scale_size(range = c(0, 4)) +
scale_color_manual(limits = c('sign.a_down.b_down', 'sign.a_up.b_down', 'sign.a_down.b_up', 'sign.a_up_b_up', 'no.a_down.b_down', 'no.a_up.b_down', 'no.a_down.b_up', 'no.a_up_b_up', 'sign.no', 'no.no'), values = c('red', 'orange', 'purple', 'blue', 'gray', 'gray', 'gray', 'gray', 'gray', 'gray')) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
geom_vline(xintercept = c(-1, 1), lty = 2) + 
geom_hline(yintercept = c(-1, 1), lty = 2) +
labs(x = 'log2FC (group A vs C)', y = 'log2FC (group B vs C)')

p

#在合适的位置添加文字标记（当然，选择 AI、PS 后续添加也很方便）
p <- p +
annotate('text', label = 'A Down\nB Down', -7, -9) +
annotate('text', label = 'A Down\nB Up', -7, 12) +
annotate('text', label = 'A Up\nB Down', 9, -9) +
annotate('text', label = 'A Up\nB Up', 9, 12)

p

#ggsave('gene_two.pdf', p, width = 7, height = 7)
ggsave('gene_two.png', p, width = 7, height = 7)

#简单的数据转换直接按数学公式来即可，如
dat <- log(data+1, 2)	#log2
dat <- log(data+1, exp(1))	#ln
dat <- log(data+1, 10)	#log10

dat <- data^2	#平方
dat <- data^0.5	#开方
dat <- data^-1	#倒数

#一些特定分析方法的命令中通常会提供标准化参数
#例如，vegan 包的 PCA/RDA 函数 rda()
rda(dat, scale = TRUE)	#执行变量标准化
rda(dat, scale = FALSE)	#不执行变量标准化

#多种函数可提供数据标准化功能
#例如，vegan包 decostand() 函数的数据标准化方法
dat2 <- decostand(dat, method = 'pa')	#二元 0-1 转化
dat2 <- decostand(dat, method = 'normalize')	#转化后平方和为 1
dat2 <- decostand(dat, method = 'hellinger')	#Hellinger 转化
dat2 <- decostand(dat, method = 'chi.square')	#卡方转化
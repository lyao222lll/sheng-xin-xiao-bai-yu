##模拟数据
library(mvtnorm)

N <- 200
P <- 6
Q <- 2
Lambda <- matrix(c(0.7, -0.4, 0.8, 0, -0.2, 0.9, -0.3, 0.4, 0.3, 0.7, -0.8, 0.1), nrow = P, ncol = Q, byrow = TRUE)

set.seed(123)
Kf <- diag(Q)
mu <- c(5, 15)
FF <- rmvnorm(N, mean = mu, sigma = Kf)
E <- rmvnorm(N, mean = rep(0, P), sigma = diag(P))
X <- FF %*% t(Lambda) + E

#计算变量间的相关矩阵，以 pearson 相关系数为例
corMat <- cor(X, method = 'pearson')
head(corMat)

library(corrplot)
corrplot(corMat, method = 'number', number.cex = 0.8, diag = FALSE, tl.cex = 0.8)
corrplot(corMat, add = TRUE, type = 'upper', method = 'pie', diag = FALSE, tl.pos = 'n', cl.pos = 'n')

##psych 包的 EFA
library(psych)

#确定最佳因子数量，详情 ?fa.parallel
#输入变量间的相关矩阵，并手动输入原始变量集的对象数量（n.obs）
fa.parallel(corMat, n.obs = N, fa = 'both', n.iter = 100)
#或者直接使用原始变量集
fa.parallel(X, fa = 'both', n.iter = 100)

#EFA 分析，详情 ?fa
#输入变量间的相关矩阵，nfactors 指定提取的因子数量，并手动输入原始变量集的对象数量（n.obs）
#rotate 设定旋转的方法，fm 设定因子化方法
fa_varimax <- fa(r = corMat, nfactors = 2, n.obs = N, rotate = 'varimax', fm = 'pa')

#或者也可直接使用原始变量集
fa_varimax <- fa(r = X, nfactors = 2, rotate = 'varimax', fm = 'pa')

fa_varimax

#上述展示了正交旋转，以下是斜交旋转
fa_promax <- fa(r = corMat, nfactors = 2, n.obs = N, rotate = 'promax', fm = 'pa')
fa_promax

#斜交旋转中，因子结构矩阵（载荷阵）使用 F=P*Phi 获得
#F 为因子载荷阵，P 为因子模式矩阵，Phi 为因子关联矩阵
fsm <- function(oblique) {
	P <- unclass(oblique$loading)
	F <- P %*% oblique$Phi
	colnames(F) <- c('PA1', 'PA2')
	F
}

fsm(fa_promax)

#可视化
par(mfrow = c(2, 2))
factor.plot(fa_varimax, title = '正交旋转')
fa.diagram(fa_varimax, simple = TRUE, main = '正交旋转')
factor.plot(fa_promax, title = '斜交旋转')
fa.diagram(fa_promax, simple = FALSE, main = '斜交旋转')

#因子得分，以斜交旋转结果为例
fa_promax <- fa(r = X, nfactors = 2, rotate = 'promax', fm = 'pa', score = 'regression')
head(fa_promax$scores)

#得分系数（标准化的回归权重）
head(fa_promax$weight)

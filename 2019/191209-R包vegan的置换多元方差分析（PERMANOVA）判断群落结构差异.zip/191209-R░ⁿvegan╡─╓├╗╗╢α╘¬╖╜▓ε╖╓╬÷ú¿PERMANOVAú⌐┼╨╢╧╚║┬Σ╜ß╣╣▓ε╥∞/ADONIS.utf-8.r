library(vegan)

##读入文件
#OTU 丰度表
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu <- data.frame(t(otu))

#样本分组文件
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE)

##PERMANOVA 分析（所有分组间比较，即整体差异）
#根据 group$site 这一列分组进行 PERMANOVA 分析检验组间差异，基于 999 次置换，详情 ?adonis

#（1）直接输入 OTU 丰度表，在参数中指定距离类型
#使用 Bray-Curtis 距离测度
adonis_result <- adonis(otu~site, group, distance = 'bray', permutations = 999)

#（2）或者首先根据丰度表计算群落间距离，仍然使用 Bray-Curtis 距离测度，详情 ?vegdist
dis1 <- vegdist(otu, method = 'bray')

#再将所的距离数据作为输入
adonis_result <- adonis(dis1~site, group, permutations = 999)

#（3）若是已经提供好了距离矩阵，则直接使用现有的距离矩阵进行分析即可
#现有的距离矩阵，这里为 Bray-Curtis 距离测度
dis <- read.delim('bray.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result <- adonis(dis1~site, group, permutations = 999)


#查看结果，上述 3 条命令所计算的内容一致，以其中一个为例
adonis_result
#或者
summary(adonis_result)
adonis_result$aov.tab 

#可选输出
otuput <- data.frame(adonis_result$aov.tab, check.names = FALSE, stringsAsFactors = FALSE)
otuput <- cbind(rownames(otuput), otuput)
names(otuput) <- c('', 'Df', 'Sums of squares', 'Mean squares', 'F.Model', 'Variation (R2)', 'Pr (>F)')
write.table(otuput, file = 'PERMANOVA.result_all.txt', row.names = FALSE, sep = '\t', quote = FALSE, na = '')

##PERMANOVA 分析（使用循环处理，进行小分组间比较，如两组间）
#推荐使用 OTU 丰度表作为输入数据，每次筛选分组后重新计算样本距离，避免由于样本数减少可能导致的距离变动而造成误差
group_name <- unique(group$site)

adonis_result_two <- NULL
for (i in 1:(length(group_name) - 1)) {
	for (j in (i + 1):length(group_name)) {
		group_ij <- subset(group, site %in% c(group_name[i], group_name[j]))
		otu_ij <- otu[group_ij$names, ]
		adonis_result_otu_ij <- adonis(otu_ij~site, group_ij, permutations = 999, distance = 'bray')	#Bray-Curtis 距离测度，基于 999 次置换
		adonis_result_two <- rbind(adonis_result_two, c(paste(group_name[i], group_name[j], sep = '/'), 'Bray-Curtis', unlist(data.frame(adonis_result_otu_ij$aov.tab, check.names = FALSE)[1, ])))
	}
}
adonis_result_two <- data.frame(adonis_result_two, stringsAsFactors = FALSE)
names(adonis_result_two) <- c('group', 'distance', 'Df', 'Sums of squares', 'Mean squares', 'F.Model', 'Variation (R2)', 'Pr (>F)')

#可选添加 p 值校正，例如 Benjamini 校正
adonis_result_two$'Pr (>F)' <- as.numeric(adonis_result_two$'Pr (>F)')
adonis_result_two$P_adj_BH <- p.adjust(adonis_result_two$'Pr (>F)', method = 'BH')

#输出
write.table(adonis_result_two, 'PERMANOVA.result_two.txt', row.names = FALSE, sep = '\t', quote = FALSE, na = '')

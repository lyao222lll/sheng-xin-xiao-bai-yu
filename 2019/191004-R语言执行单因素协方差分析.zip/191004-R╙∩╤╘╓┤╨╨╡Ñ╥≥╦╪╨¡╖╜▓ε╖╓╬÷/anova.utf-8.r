#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##单因素协方差分析（ANCOVA）
#假设我们使用同一来源的土壤进行盆栽试验（土壤类型、植物类型一致），分别添加了三种化学物质（a、b、c），探究不同类型的化学物质是如何影响植物根际细菌群落的
#我们在植物花期取样观察，由于各盆栽中植物开花期时间并非一致，所以我们考虑将植物生长时间（days）为协变量

#以 shannon 指数为例，同时将分组列转换为因子变量
shannon <- soil[ ,c('sample', 'treat', 'shannon', 'days')]
shannon$treat <- factor(shannon$treat)

#QQ-plot 检查数据是否符合正态分布
library(car)
qqPlot(lm(shannon~treat, data = shannon), simulate = TRUE, main = 'QQ Plot', labels = FALSE)

#使用 Bartlett 检验进行方差齐性检验（p 值大于 0.05 说明方差齐整）
bartlett.test(shannon~treat, data = shannon)

#检验回归斜率的同质性，交互效应不显著则支持斜率相等的假设（即 p 值大于 0.05 说明回归斜率相等）
summary(aov(shannon~days*treat, data = shannon))

#满足假设，单因素协方差分析，详情使用?aov查看帮助
fit <- aov(shannon~days+treat, data = shannon)
summary(fit)

#不满足假设，可使用非参数方法，例如
#sm 包 sm.ancova()

#查看各组均值及标准差
aggregate(shannon$shannon, by = list(shannon$treat), FUN = mean)
aggregate(shannon$shannon, by = list(shannon$treat), FUN = sd)
#由于使用了协变量，若想获取去除协变量效应后的组均值（调整的组均值）
library(effects)
effect('treat', fit)

#HH 包 ancova() 可绘制因变量、协变量和因子之间的关系图
#详情使用 ?ancova 查看帮助
library(HH)
ancova(shannon~days+treat, data = shannon)
ancova(shannon~days*treat, data = shannon)

library(vegan)

##数据集
#详情 https://www.rdocumentation.org/packages/vegan/versions/2.4-2/topics/mite
data(mite)
head(mite[ ,1:10])

#对土壤地点设置分组（分组参考自 Legendre 2005, Fig. 4 的 PCA）
group.1 <- c(1, 2, 4:8, 10:15, 17, 19:22, 24, 26:30)
group.2 <- c(3, 9, 16, 18, 23, 25, 31:35)

#按分组将物种多度数据拆分为两组数据集
#物种多度数据分析，推荐执行 Hellinger 转化
mite.hel.1 <- decostand(mite[,group.1], 'hel')
mite.hel.2 <- decostand(mite[,group.2], 'hel')

rownames(mite.hel.1) = paste('S', 1:nrow(mite), sep = '')
rownames(mite.hel.2) = paste('S', 1:nrow(mite), sep = '')

#Q-Q 图验证多元正态性
#若数据服从多元正态性，则点将落在直线附近
par(mfrow = c(1, 2))

qqplot(qchisq(ppoints(nrow(mite.hel.1)), df = ncol(mite.hel.1)), mahalanobis(mite.hel.1, colMeans(mite.hel.1), cov(mite.hel.1)))
abline(a = 0, b = 1)

qqplot(qchisq(ppoints(nrow(mite.hel.2)), df = ncol(mite.hel.2)), mahalanobis(mite.hel.2, colMeans(mite.hel.2), cov(mite.hel.2)))
abline(a = 0, b = 1)

#CCorA，详情 ?CCorA
#Y 和 X 地位等同
#这里两组均为物种丰度，量纲一致，且 Hellinger 转化降低了高丰度物种的权重，故无需对两组数据集标准化
#若量纲不同（比如不同的环境变量），则需要将对应的数据集标准化
#999 次置换确定相关性的显著性
out <- CCorA(Y = mite.hel.1, X = mite.hel.2, stand.Y = FALSE, stand.X = FALSE, permutations = 999)
out

#根据 summary() 的提示，提取主要信息
summary(out)

#例如
#Pillai's trace
out$Pillai
#各个轴的典范相关系数
out$Eigenvalues
#校正后的 RDA R2
out$RDA.adj.Rsq
#置换检验 p 值
out$p.perm

#作图观测，如 biplot()，详情 ?CCorA
#“objects”生成两个对象图，第一个表示 Y 矩阵中的对象，第二个表示 X 矩阵中的对象；以展示第 1、2 轴为例
biplot(out, plot.type = 'objects', plot.axes = c(1, 2))

#“variables” 生成两个变量图，第一个表示 Y 矩阵中的变量，第二个表示 X 矩阵中的变量；以展示第 1、2 轴为例
biplot(out, plot.type = 'variables', plot.axes = c(1, 2), cex = c(0.7, 0.6))

#“ov”生成四个图，包含两个对象和两个变量；以展示第 1、2 轴为例
biplot(out, plot.type = 'ov', plot.axes = c(1, 2), cex = c(0.7, 0.6))

#“biplots”产生两个双序图，第一个用于 Y 矩阵，第二个用于 X 矩阵；以展示第 1、2 轴为例
biplot(out, plot.type = 'biplots', plot.axes = c(1, 2), cex = c(0.7, 0.6))


#读取数据
up <- read.delim('GO.MF.up.txt', sep = '\t', stringsAsFactors = FALSE)
down <- read.delim('GO.MF.down.txt', sep = '\t', stringsAsFactors = FALSE)

#按 p 值排序，同时当两数据不等长时补充空白数据（尽可能使蝴蝶图对称）
up <- up[order(up$P_Value, decreasing = TRUE), ]
up$Term <- factor(up$Term, levels = up$Term)
id_up <- levels(up$Term)
down <- down[order(down$P_Value, decreasing = TRUE), ]
down$Term <- factor(down$Term, levels = down$Term)
id_down <- levels(down$Term)

n <- length(up$Term) - length(down$Term)
if (n > 0) {
	down$Term <- as.character(down$Term)
	for (i in paste('nn', as.character(seq(1, n, 1)), sep = '')) down <- rbind(list(i, NA, NA), down)
	down$Term <- factor(down$Term, levels = down$Term)
	id_down <- c(rep('', n), id_down)
} else if (n < 0) {
	up$Term <- as.character(up$Term)
	for (i in paste('nn', as.character(seq(1, abs(n), 1)), sep = '')) up <- rbind(list(i, NA, NA), up)
	up$Term <- factor(up$Term, levels = up$Term)
	id_up <- c(rep('', abs(n)), id_up)
}

##ggplot2 作图
library(ggplot2)

#上调 GO
p_up <- ggplot(up, aes(Term, log(P_Value, 10))) +
geom_col(fill = 'red2', color = 'black', width = 0.6) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent')) +
theme(axis.line.x = element_line(colour = 'black'), axis.line.y = element_line(colour = 'transparent'), axis.ticks.y = element_line(colour = 'transparent')) +
theme(plot.title = element_text(hjust = 0.5, face = 'plain')) +
coord_flip() +
geom_hline(yintercept = 0) +
labs(x = '', y = '', title = 'UP') +
scale_y_continuous(expand = c(0, 0), breaks = c(-12, -8, -4, 0), labels = as.character(abs(c(-12, -8, -4, 0)))) +	#这儿更改间距设置
scale_x_discrete(labels = id_up)


#下调 GO
p_down <- ggplot(down, aes(Term, -log(P_Value, 10))) +
geom_col(fill = 'green4', color = 'black', width = 0.6) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent')) +
theme(axis.line.x = element_line(colour = 'black'), axis.line.y = element_line(colour = 'transparent'), axis.ticks.y = element_line(colour = 'transparent')) +
theme(plot.title = element_text(hjust = 0.5, face = 'plain')) +
geom_hline(yintercept = 0) +
coord_flip() +
labs(x = '', y = '', title = 'DOWN') +
scale_y_continuous(expand = c(0, 0), breaks = c(0, 2, 4, 6), labels = as.character(c(0, 2, 4, 6))) +	#这儿更改间距设置
scale_x_discrete(labels = id_down, position = 'top')

#合并输出pdf
library(cowplot)

pdf('butterfly.pdf', width = 14, height = 5)
plot_grid(p_up, p_down, nrow = 2, ncol = 2, rel_heights = c(9, 1), labels = 'GO_Enrichment Score (-log10(p-value))', label_x = 0.5, label_y = 0, label_fontface = 'plain')
dev.off()

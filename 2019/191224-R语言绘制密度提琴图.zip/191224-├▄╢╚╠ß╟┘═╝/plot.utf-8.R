#“密度提琴图”
library(ggplot2)
library(ggridges)
library(grid)

#计算中位数值
med <- aggregate(lincoln_weather$`Mean Temperature [F]`, by = list(lincoln_weather$`Month`), FUN = median)

#“正方向”
p1 <- ggplot(lincoln_weather, aes(x = `Mean Temperature [F]`, y = `Month`, fill = ..density..)) + 
geom_density_ridges_gradient(scale = 0.3, gradient_lwd = NA, rel_min_height = NA,size = NA) + 
scale_fill_gradientn(colours = colorRampPalette(c('#663490', '#5054A3', '#37A3D2', '#3EB897', '#6EBB46', '#C0D857'))(30)) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'transparent', color = 'black'), plot.background = element_blank()) +
labs(x = 'Mean Temperature', y = 'Month', fill = '')

#“反方向”
p2 <- ggplot(lincoln_weather, aes(x = `Mean Temperature [F]`, y = `Month`, fill = ..density..)) + 
geom_density_ridges_gradient(scale = -0.3, gradient_lwd = NA, rel_min_height = NA,size = NA) + 
scale_fill_gradientn(colours = colorRampPalette(c('#663490', '#5054A3', '#37A3D2', '#3EB897', '#6EBB46', '#C0D857'))(30)) +
theme(panel.grid = element_blank(), panel.background = element_blank(), plot.background = element_blank()) +
labs(x = 'Mean Temperature', y = 'Month', fill = '') +
#把中位数以红点的形式添在图中
annotate('text', label = '.', x = med$x, y = med$Group.1, size = 10, colour = 'red', vjust = -0.02)

grid.newpage()
print(p1, vp = viewport(x = 0.5, y = 0.5))
print(p2, vp = viewport(x = 0.5, y = 0.5))

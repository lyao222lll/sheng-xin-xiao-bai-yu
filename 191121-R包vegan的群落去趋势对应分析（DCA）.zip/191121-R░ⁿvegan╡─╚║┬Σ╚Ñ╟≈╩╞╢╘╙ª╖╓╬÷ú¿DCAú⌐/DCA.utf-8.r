library(vegan)

#######################
#读取 OTU 丰度表
otu <- read.delim('otu_table.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)
otu <- data.frame(t(otu))

#CA 排序
ca_otu <- cca(otu)

ordiplot(ca_otu, display = 'site', type = 'n', choices = c(1, 2), scaling = 1)
points(ca_otu, display = 'site', choices = c(1, 2), scaling = 1, pch = 21, bg = c(rep('red', 10), rep('orange', 10), rep('green3', 10)), col = NA)
text(ca_otu, display = 'site', choices = c(1, 2), scaling = 1, cex = 0.8)

#######################
#DCA 排序，详情 ?decorana
dca_otu <- decorana(otu, ira = 0)	#注，ira = 0 执行 DCA，ira = 1 则执行 CA
dca_otu

summary(dca_otu)
head(summary(dca_otu)$site.scores)
#注，summary() 中默认展示的样方和物种得分，均为标准化后的值

#各 DCA 轴特征值
dca_otu$evals
#各 DCA 轴解释量
dca_otu$evals/sum(dca_otu$evals)

#样方得分
dca_site <- dca_otu$rproj	#原始坐标，不同于 summary() 显示的坐标
head(dca_site)

dca_site_scale <- scale(dca_otu$rproj, scale = FALSE)	#标准化后的坐标，等同于 summary() 显示的坐标
head(dca_site_scale)
#write.table(dca_site_scale, 'dca_site_scale.txt', col.names = NA, sep = '\t', quote = FALSE)

#物种得分
dca_sp <- dca_otu$cproj	#原始坐标，不同于 summary() 显示的坐标
head(dca_sp)

dca_sp_scale <- scale(dca_otu$cproj, scale = FALSE)	#标准化后的坐标，等同于 summary() 显示的坐标
head(dca_sp_scale)
#write.table(dca_sp_scale, 'dca_sp_scale.txt', col.names = NA, sep = '\t', quote = FALSE)

#提取各轴“梯度长度”
#各 DCA 轴的梯度长度，即通过该轴中，所有样方坐标的最大值减去最小值获得
apply(dca_otu$rproj, 2, max) - apply(dca_otu$rproj, 2, min)

#简洁版排序图
par(mfrow = c(1, 2))
plot(dca_otu, display = 'sites', main = '仅样方')
plot(dca_otu, main = '双序图')

##ggplot2 作图
#提取样方坐标，前两轴
dca_site_scale <- data.frame(scale(dca_otu$rproj, scale = FALSE))[1:2]

#添加分组信息
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE)

dca_site_scale$sample <- rownames(dca_site_scale)
dca_site_scale <- merge(dca_site_scale, group, by = 'sample')

#ggplot2 作图
library(ggplot2)
library(ggrepel)	#用于 geom_text_repel() 添加标签

p <- ggplot(dca_site_scale, aes(DCA1, DCA2)) +
geom_point(aes(color = group1)) +
scale_color_manual(values = c('green3', 'red', 'orange')) +
theme(panel.grid.major = element_line(color = 'gray', size = 0.2), panel.background = element_rect(color = 'black', fill = 'transparent'), 
	legend.key = element_rect(fill = 'transparent'), legend.title = element_blank()) + 
geom_vline(xintercept = 0, color = 'gray', size = 0.5) + 
geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
geom_text_repel(aes(label = sample, color = group1), size = 3, box.padding = unit(0.3, 'lines'), show.legend = FALSE)

#ggsave('DCA.pdf', p, width = 6, height = 5)
ggsave('DCA.png', p, width = 6, height = 5)

##比较 CA 和 DCA
#上述已经计算好了 CA 和 DCA，直接做图
par(mfrow = c(1, 2))

#CA
ordiplot(ca_otu, display = 'site', choices = c(1, 2), scaling = 1, type = 'n', main = 'CA')
points(ca_otu, display = 'site', choices = c(1, 2), scaling = 1, pch = 21, bg = c(rep('red', 10), rep('orange', 10), rep('green3', 10)), col = NA)
text(ca_otu, display = 'site', choices = c(1, 2), scaling = 1, cex = 0.8)

#DCA
ordiplot(dca_otu, display = 'sites', choices = c(1, 2), type = 'n', main = 'DCA')
points(dca_otu, display = 'site', choices = c(1, 2), pch = 21, bg = c(rep('red', 10), rep('orange', 10), rep('green3', 10)), col = NA)
text(dca_otu, display = 'site', choices = c(1, 2), cex = 0.8)



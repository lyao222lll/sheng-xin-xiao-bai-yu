#示例数据“data.txt”
#第一列，OTU 名称
#第二、三、四列，OTU 在 3 个样本中的丰度信息
#第五列，标注了这些 OTU 在哪个样本中发生了富集
#第六列，OTU 的门类群

#读取数据
dat <- read.delim('data.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

##ternaryplot() 三元图
library(vcd)

dat1 <- dat

#点的大小用于表示 OTUs 丰度
#由于各 OTUs 丰度差异过大，为了美观，作图时取 3 个样本的平均值的 0.4 次方再除以 10......
dat1$size <- (apply(dat1[2:4], 1, mean))^0.4 / 10

#颜色表示各 OTUs 的富集样本
dat1[which(dat1$rich == 'env1'),'color'] <- 'red'
dat1[which(dat1$rich == 'env2'),'color'] <- 'blue'
dat1[which(dat1$rich == 'env3'),'color'] <- 'green3'
dat1[which(dat1$rich == '0'),'color'] <- 'gray'

#ternaryplot() 示例，按 OTUs 富集区域着色
#pdf('ternaryplot.pdf')
png('ternaryplot.png', width = 2000, height = 2000, res = 300, units = 'px')
ternaryplot(dat1[2:4], scale = NULL, col = dat1$color, prop_size = FALSE, cex = dat1$size, main = 'Enriched OTUs')
grid_legend(x = 0.8, y = 0.7, pch = c(19, 19, 19), col = c('red', 'blue', 'green3'), label = c('env1', 'env2', 'env3'), title = FALSE, frame = FALSE)
dev.off()


##TernaryPlot() 三元图
library(Ternary)

dat2 <- dat

#计算点坐标，根据变量在三个样本中的相对比率，再乘以 100，即可得到
dat2$sum <- apply(dat1[2:4], 1, sum)
dat2$env1 <- 100 * dat2$env1/dat2$sum
dat2$env2 <- 100 * dat2$env2/dat2$sum
dat2$env3 <- 100 * dat2$env3/dat2$sum

otu <- list()
for (i in 1:nrow(dat2)) {
	otu[[i]] <- as.vector(unlist(dat2[i,c(2:4)]))
	names(otu)[i] <- as.vector(dat2[i,1])
}

#赋值点颜色，颜色表示各 OTUs 的富集样本
dat2[which(dat2$rich == 'env1'),'color'] <- 'red'
dat2[which(dat2$rich == 'env2'),'color'] <- 'blue'
dat2[which(dat2$rich == 'env3'),'color'] <- 'green3'
dat2[which(dat2$rich == '0'),'color'] <- 'gray'

color <- c()
for (i in 1:nrow(dat2)) {
	color[i] <- dat2[i,'color']
	names(color)[i] <- as.vector(dat2[i,1])
}

#赋值点大小
#由于各 OTUs 丰度差异过大，为了美观，作图时取 3 个样本的平均值的 0.4 次方再除以 5......
size = c()
for (i in 1:nrow(dat2)) {
	size[i] <- (apply(dat1[i,2:4], 1, mean))^0.4 / 5
	names(size)[i] <- as.vector(dat2[i,1])
}

#作图
#pdf('TernaryPlot.pdf')
png('TernaryPlot.png', width = 2000, height = 2000, res = 300, units = 'px')
TernaryPlot(atip = 'env1', btip = 'env2', ctip = 'env3', col = NA, grid.col = 'gray', grid.minor.col = NA, axis.col = 'black')
AddToTernary(points, otu, col = color, cex = size, pch = 20)
dev.off()

##ggtern 三元图
library(ggtern)

dat3 <- dat

#点的大小用于表示 OTUs 丰度
#由于各 OTUs 丰度差异过大，为了美观，作图时取 3 个样本的平均值的 0.5 次方......
dat3$size <- (apply(dat3[2:4], 1, mean))^0.5

#ggtern，作图时按 OTUs 富集区域对点着色
p_rich <- ggtern(dat3, aes(env1, env2, env3)) +
geom_mask() +
geom_point(aes(color = rich, size = size), alpha = 0.8, show.legend = FALSE) +
scale_size(range = c(0, 6)) +
scale_colour_manual(values  = c('red', 'blue', 'green3', 'gray'), limits = c('env1', 'env2', 'env3', '0')) +
theme_bw() +
theme(axis.text = element_blank(), axis.ticks = element_blank())

#ggsave('ggtern.pdf', p_rich, width = 6, height = 6)
ggsave('ggtern.png', p_rich, width = 6, height = 6)

#ggtern，按 OTUs 所属门类群对点着色
#由于 OTUs 所属的门类群较多，此处不再单独定义每一类细菌门的颜色，使用 ggtern 的默认颜色
p_taxonomy <- ggtern(dat3, aes(env1, env2, env3)) +
geom_mask() +
geom_point(aes(color = taxonomy, size = size), alpha = 0.8) +
scale_size(range = c(0, 6)) +
theme_bw() +
theme(axis.text = element_blank(), axis.ticks = element_blank(), legend.title = element_blank()) +
guides(size = 'none')

#密度图举例
dens <- ggtern(dat3, aes(env1, env2, env3)) +
stat_density_tern()

dens

library(circlize)

##单个节点绘制
#读取数据
edge <- read.csv('edge.csv')
#edge <- edge[order(edge$phylum_source, edge$phylum_target), ]
edge1 <- edge[3:4]
edge1$value <- 1

#作图，详情 ?chordDiagram
#或者参阅文档 https://jokergoo.github.io/circlize_book/book/the-chorddiagram-function.html
color = c(Acidobacteria = 'green', Actinobacteria = 'red', Bacteroidetes = 'orange', Firmicutes = 'purple', Gemmatimonadetes = 'skyblue', Proteobacteria = 'blue')

#png('edge1.png', width = 2000, height = 2000, res = 300, units = 'px')
pdf('edge1.pdf', height = 6, width = 6)

chordDiagram(edge1, 
	annotationTrack = c('grid', 'name'),	#绘制外周圆弧区，显示名称，但隐藏刻度轴；显示刻度可使用 c('grid', 'name', 'axis')
	grid.col = color,	#颜色设置
	annotationTrackHeight = c(0.035, 0.015),	#名称离圆弧的距离，以及圆弧的宽度
	directional = 1	#“方向缩进”
)

dev.off()

##合并节点绘制
#统计
library(doBy)
edge2 <- summaryBy(value~phylum_source+phylum_target, edge1, FUN = sum)

#作图，详情 ?chordDiagram
#png('edge2.png', width = 2000, height = 2000, res = 300, units = 'px')
pdf('edge2.pdf', height = 6, width = 6)

chordDiagram(edge2, 
	annotationTrack = c('grid', 'name'),
	grid.col = color,
	annotationTrackHeight = c(0.035, 0.015),
	directional = 1
)

dev.off()

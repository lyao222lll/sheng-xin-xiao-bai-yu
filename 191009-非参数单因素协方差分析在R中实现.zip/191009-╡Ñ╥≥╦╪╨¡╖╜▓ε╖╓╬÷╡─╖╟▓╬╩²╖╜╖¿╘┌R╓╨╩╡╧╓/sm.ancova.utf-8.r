#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##单因素协方差分析的非参数检验替代方法
#假设我们使用同一来源的土壤进行盆栽试验（土壤类型、植物类型一致），分别添加了三种化学物质（a、b、c），探究不同类型的化学物质是如何影响植物根际细菌群落的
#我们在植物花期取样观察，由于各盆栽中植物开花期时间并非一致，所以我们考虑将植物生长时间（days）为协变量

#以 shannon 指数为例，同时将分组列转换为因子变量
shannon <- soil[ ,c('sample', 'treat', 'shannon', 'days')]
shannon$treat <- factor(shannon$treat)

#当数据不满足单因素协方差分析的条件（正态性、方差齐性、回归斜率的同质性）时，尝试非参数的方法，例如
#sm 包 sm.ancova()，详情使用 ?sm.ancova 查看详情
library(sm)
sm.ancova(x = shannon$days, y = shannon$shannon, group = shannon$treat, model = 'equal')

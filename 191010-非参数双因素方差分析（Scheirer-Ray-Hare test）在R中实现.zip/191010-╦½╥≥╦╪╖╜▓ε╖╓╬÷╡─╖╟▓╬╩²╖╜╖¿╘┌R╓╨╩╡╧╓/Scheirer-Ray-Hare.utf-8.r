#读入文件
soil <- read.table('soil.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

##双因素方差分析的非参数检验替代方法
#假设所有土壤类型均一致，我们在土壤中分别添加了三种化学物质（a、b、c），并将土壤孵育了不同的时间（10、15、20、25 天），同时关注化学物质类型以及处理时间对土壤细菌群落的影响（关注交互作用）
#同样以 chao1 指数为例，同时将分组列转换为因子变量
chao1 <- soil[ ,c('sample', 'treat', 'times', 'chao1')]
chao1$treat <- factor(chao1$treat)
chao1$times <- factor(chao1$times)

#当数据不满足双因素方差分析的条件（正态性、方差齐性）时，尝试非参数的方法，例如
#Scheirer-Ray-Hare Test，rcompanion 包 scheirerRayHare()，详情使用 ?scheirerRayHare 查看帮助说明
library(rcompanion)
scheirerRayHare(chao1~treat*times, data = chao1)

##多元方差分析（MANOVA）
#以单因素多元方差分析为例
#假设所有土壤类型均一致，我们在土壤中分别添加了三种化学物质（a、b、c），并将土壤孵育了相同的时间后，探究土壤细菌群落 chao1 指数、土壤 pH、土壤硝酸还原酶（NR）活性是否因所添加化学物质类型不同而显著改变

#选择数据，并将分组列转换为因子变量
muti <- soil[ ,c('sample', 'treat', 'chao1', 'pH', 'NR')]
muti$treat <- factor(muti$treat)

#当数据不满足单因素 MANOVA 的条件（多元正态性、方差-协方差矩阵同质性）时，尝试非参数的方法，例如
#置换多元方差分析（PERMANOVA），vegan 包 adonis()
library(vegan)

rownames(muti) <- muti$sample
muti_dat <- muti[ ,c('chao1', 'pH', 'NR')]
#muti_dat <- decostand(muti_dat, 'standardize')	#可选 z-score 标准化，消除量纲差异
dis <- vegdist(muti_dat, method = 'euclidean')	#获取欧式距离矩阵（这里以欧式距离为例，实际分析中视情况选择合适的距离测度）
adonis(dis~treat, muti, permutations = 999)  #999 次置换获得 p 值（结合了置换检验）

#多因素下，在 ~ 后面添加分组因子即可
#例如 A 为协变量，B 为自变量时
adonis(y~A+B, data, permutations = 999) 
#例如考虑 A、B 双因素及交互作用时
adonis(y~A*B, data, permutations = 999) 
##韦恩图（UpSetR 包，不受样本数限制）
library(UpSetR)

#读入作图文件，根据 OTU 丰度存在与否，转为 0-1 类型的数据矩阵
otu <- read.delim('otu_table.txt', header = TRUE, row.names = 1, sep = '\t')
otu1 <- otu
otu1[otu1 > 0] <- 1

#作图
upset(otu1)

#默认最多展示 5 组数据（nset = 5）的 40 种交集（nintersects = 40）
#我们期望将所有子集展示出来，nintersects 设置大一些
upset(otu1, nset = 6, nintersects = 100)
#也可自定义指定数据集名称
upset(otu1, sets = c('c1', 'c2', 'c3', 'c4', 'c5', 'c6'), nintersects = 100)

#添加排序
upset(otu1, nset = 6, nintersects = 100, order.by = c('freq', 'degree'), decreasing = c(TRUE, TRUE))

#关注特定的交集，或者某特定元素的分布，通过 queries 参数指定
#例如我们关注所有分组的交集、c1 分组的特有集，以及 Proteobacteria 在各交集中所含 OTUs 的种类数量
upset(otu1, nset = 6, nintersects = 100, order.by = c('freq', 'degree'), decreasing = c(TRUE, TRUE), 
	queries = list(list(query = intersects, params = 'c1', color = 'red'),
			list(query = intersects, params = c('c1', 'c2', 'c3', 'c4', 'c5', 'c6'), color = 'blue'),
			list(query = elements, params = c('taxonomy', 'Proteobacteria'), color = 'orange', active = TRUE)))


##复杂样式示例
#我们选择 6 组数据的共有 OTUs，并根据这些 OTUs 的所属分类统计相对丰度，绘制饼图和柱状图
#之后通过 UpSetR 将它们和韦恩图组合在一起
library(reshape2)
library(doBy)
library(ggplot2)

#获取 6 组共有 OTUs
select_otu <- rownames(otu1[rowSums(otu1[1:6]) == 6, ])
otu_select <- otu[select_otu, ]

#根据 taxonomy，计算这些共有 OTUs 的总丰度
phylum <- summaryBy(c1+c2+c3+c4+c5+c6~taxonomy, otu_select, FUN = sum)
names(phylum) <- c('taxonomy', 'c1', 'c2', 'c3', 'c4', 'c5', 'c6')

phylum_melt <- melt(phylum, id = 'taxonomy')
phylum_melt$value <- phylum_melt$value * 100
phylum_melt_stat <- summaryBy(value~taxonomy, phylum_melt, FUN = mean)

#按 taxonomy 丰度大小降序排序，便于作图
phylum_melt_stat <- phylum_melt_stat[order(phylum_melt_stat$value.mean), ]
phylum_melt_stat$taxonomy <- factor(phylum_melt_stat$taxonomy, levels = c('Others', as.vector(phylum_melt_stat$taxonomy[-which(phylum_melt_stat$taxonomy == 'Others')])))

#taxonomy 丰度饼图
color = c('gray', '#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5')

plot1 <- function(mydata, x, y) {
	ggplot(phylum_melt_stat, aes(x = '', y = value.mean, fill = taxonomy)) +
	geom_bar(stat = 'identity', show.legend = FALSE) +
	coord_polar(theta = 'y') +
	scale_fill_manual(values = color) +
	theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.x = element_blank(), plot.background = element_blank()) +
	labs(x = NULL, y = 'Number of all shared OTUs: 1628\nAverage abundance of main phylum')
}

#taxonomy 丰度柱状图
phylum_melt$taxonomy <- factor(phylum_melt$taxonomy, levels = levels(phylum_melt_stat$taxonomy))

plot2 <- function(mydata, x, y) {
	ggplot(phylum_melt, aes(x = variable, y = value, fill = taxonomy)) +
	geom_col(position = 'stack', width = 0.6) +
	scale_fill_manual(values = color) +
	theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
	labs(x = '', y = 'Relative abundance (%)', fill = NULL)
}

#组合样式，通过 attribute.plots 参数指定额外的图形
upset(otu1, nset = 6, nintersects = 100, order.by = c('freq', 'degree'), decreasing = c(TRUE, TRUE), 
	queries = list(list(query = intersects, params = c('c1', 'c2', 'c3', 'c4', 'c5', 'c6'), color = 'blue', active = TRUE)),
	attribute.plots = list(gridrows = 80, ncols = 2,
		plots = list(list(plot = plot1, mydata = NA, x = NA, y = NA, queries = FALSE),
			list(plot = plot2, mydata = NA, x = NA, y = NA, queries = FALSE))))

#注：
#这里额外添加的柱状图和饼图，使用了原始的 OTU 丰度数据，独立于 UpSet 图的 0-1 类型的 OTU 数据本身
#构建外部 ggplot2 命令时直接打包在 plot1、plot2 函数内部
#尽管如此，plot1、plot2 仍需要添加“mydata, x, y”三个参数，不能空着，否则无法被 upset() 识别
#但可以通过将参数传递为空值解决

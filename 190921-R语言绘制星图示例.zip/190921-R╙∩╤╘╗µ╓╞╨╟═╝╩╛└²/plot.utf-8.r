#stars() 作图，可使用 ?stars 查看该命令详情
phylum_top10 <- read.csv('phylum_top10.csv', row.names = 1)
t_phylum_top10 <- data.frame(t(phylum_top10))

color <- c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray') 
stars(t_phylum_top10, scale = FALSE, draw.segments = TRUE, col.segments = color, nrow = 2, ylim = c(1, 2), key.loc = c(6, -1) , frame.plot = FALSE, main = 'Top10 Phylum')


##ggplot2 作图（一个简单示例）
library(reshape2)
library(ggplot2)

#调整数据布局
phylum_top10$Taxonomy <- factor(rownames(phylum_top10), levels = rownames(phylum_top10))
phylum_top10_melt <- melt(phylum_top10, id = 'Taxonomy')

#以样本 c1 为例的星图，单一柱形图的坐标转换
phylum_top10_c1 <- subset(phylum_top10_melt, variable == 'c1')

p_c1 <- ggplot(phylum_top10_c1, aes(Taxonomy, value, fill = Taxonomy)) +
geom_bar(stat = 'identity', width = 1) +
coord_polar(theta = 'x') +
scale_fill_manual(values = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray')) +
labs(x = '', y = '', title = 'Sample: c1', fill = 'Top10 Phylum') +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text = element_blank(), axis.ticks = element_blank(), plot.title = element_text(hjust = 0.5))

p_c1

#所有样本，堆叠柱形图的坐标转换
p_all <- ggplot(phylum_top10_melt, aes(variable, value, fill = Taxonomy)) +
geom_bar(stat = 'identity', width = 0.6) +
coord_polar(theta = 'x') +
scale_fill_manual(values = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray')) +
labs(x = '', y = '', fill = 'Top10 Phylum') +
theme(panel.grid = element_blank(), panel.background = element_blank(), axis.text.y = element_blank(), axis.ticks = element_blank())

p_all

##一个 ggplot2 的多图组合样式，借助 grid 包完成
library(grid)

#获取所有样本名称
sample_name <- levels(phylum_top10_melt$variable)

#创建画板，根据样本数（此处为 8 个）预设图片位置
#pdf('grid_plot.pdf', width = 9, height = 5)
png('grid_plot.png', width = 3000, height = 1500, res = 300, units = 'px')
grid.newpage()

n <- 8
split_x <- c(0.1, 0.3, 0.5, 0.7, 0.1, 0.3, 0.5, 0.7)	#预设 8 张子图的横坐标
split_y <- c(0.6, 0.6, 0.6, 0.6, 0.1, 0.1, 0.1, 0.1)	#预设 8 张子图的纵坐标

#使用循环，使用 ggplot2 分别绘制 8 个样本的物种丰度星图，并放置在画板对应的位置中
for (i in 1:n) {
	p_i <- ggplot(subset(phylum_top10_melt, variable == sample_name[i]), aes(Taxonomy, value, fill = Taxonomy)) +
		geom_bar(stat = 'identity', width = 1) +
		coord_polar(theta = 'x') +
		scale_fill_manual(values = c('#8DD3C7', '#FFFFB3', '#BEBADA', '#FB8072', '#80B1D3', '#FDB462', '#B3DE69', '#FCCDE5', '#BC80BD', '#CCEBC5', 'gray')) +
		labs(title = paste('Sample:', sample_name[i]), y = '', x = '', fill = 'Top10 Phylum') +
		theme(plot.background = element_blank(), panel.grid = element_blank(), panel.background = element_blank(), axis.text = element_blank(), axis.ticks = element_blank(), plot.title = element_text(hjust = 0.5))
	
	print(p_i + theme(legend.position = 'none'), vp = viewport(x = split_x[i], y = split_y[i], width = 1, height = 0.8))
}

#该函数用于在 ggplot2 中提取图例，参考自 https://stackoverflow.com/questions/13712574/how-to-change-position-of-grid-draw
g_legend <- function(gg_plot) {
	tmp <- ggplot_gtable(ggplot_build(gg_plot))
	leg <- which(sapply(tmp$grobs, function(x) x$name) == 'guide-box')
	leg <- tmp$grobs[[leg]]
	leg
}

#截取图例添加至组合图中
phylum_legend <- g_legend(p_i)
phylum_legend$vp$x <- unit(0.92, 'npc')	#指定图例在 grid 画板中的横坐标位置
phylum_legend$vp$y <- unit(0.5, 'npc')	#指定图例在 grid 画板中的纵坐标位置
grid.draw(phylum_legend)

dev.off()
